import javafx.util.Pair;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/21 16:29
 */
/*
* 现有N个任务需要处理，同一时间只能处理一个任务，处理每个任务所需要的时间固定为1。

每个任务都有最晚处理时间限制和积分值，在最晚处理时间点之前处理完成任务才可获得对应的积分奖励。

可用于处理任务的时间有限，请问在有限的时间内，可获得的最多积分。

输入描述
第一行为一个数 N，表示有 N 个任务

1 ≤ N ≤ 100
第二行为一个数 T，表示可用于处理任务的时间

1 ≤ T ≤ 100
接下来 N 行，每行两个空格分隔的整数（SLA 和 V），SLA 表示任务的最晚处理时间，V 表示任务对应的积分。

1 ≤ SLA ≤ 100
0 ≤ V ≤ 100000
输出描述
可获得的最多积分

用例1
输入
4
3
1 2
1 3
1 4
1 5
输出
5
说明
虽然有3个单位的时间用于处理任务，可是所有任务在时刻1之后都无效。
所以在第1个时间单位内，选择处理有5个积分的任务。1-3时无任务处理。

用例2
输入
4
3
1 2
1 3
1 4
3 5
输出
9
说明
第1个时间单位内，处理任务3，获得4个积分

第2个时间单位内，处理任务4，获得5个积分

第3个时间单位内，无任务可处理

共获得9个积分

题解
思路：贪心算法，优先做获得积分多的工作。

将工作首先按照结束时间升序排序。这样做的原因是，当遍历到后面遇到积分高的任务时可以非常方便替换掉前面已选择的任务中积分小的任务。搭配使用了优先队列，方便取出最小值。
使用currentTime变量来处理示例1情况，当多个任务结束时间为一天的情况，并且数量大于结束时间的情况。
维持优先队列大小为t。
最后输出优先队列中的求和值就是答案。
*/
import java.util.*;
import java.util.stream.Collectors;

public class SimExecuteTask {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int t = sc.nextInt();
        List<Pair<Integer, Integer>> ans = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            int dielineTime = sc.nextInt();
            int score = sc.nextInt();
            ans.add(new Pair<>(dielineTime, score));
        }

        // 可以按照积分大小降序 最晚时间升序排序
        // 每次取出积分最大的任务,安排在最晚的时间进行,如果时间被占,那就任务执行时间往前推一个 直到任务被安排,或者执行时间为0,说明没办法安排这个任务


        ans=ans.stream().sorted((e1,e2)->{
            if(e1.getValue()!=e2.getValue()){
                return e2.getValue()-e1.getValue();
            }
            return e1.getKey()-e2.getKey();
        }).collect(Collectors.toList());
        boolean[] load=new boolean[t];
        int result=0;
        for (Pair<Integer, Integer> pair : ans) {
            // pair.getkey()存的是结束时间 每个任务的执行时间为1 因此开始执行时间应该是pair.getKey()-1
            Integer startTime = Math.min(pair.getKey()-1,t-1);
            while(startTime>=0&&load[startTime]){
                startTime--;
            }
            if(startTime>=0){
                load[startTime]=true;
                result+=pair.getValue();
            }
        }
        System.out.println(result);
        // 按照结束时间排序
        ans.sort(Comparator.comparing(Pair::getKey));

        int res = 0;
        int currentTime = 0;
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();

        for (Pair<Integer, Integer> ele : ans) {
            int endTime = ele.getKey();
            int score = ele.getValue();

            // 当前时间小于结束时间时，可以直接进行判断
            if (endTime > currentTime) {
                // t个工作时间限制
                if (minHeap.size() < t) {
                    minHeap.offer(score);
                } else {
                    // 替换之前获得积分少的工作
                    int minValue = minHeap.peek();
                    if (minValue < score) {
                        minHeap.poll();
                        minHeap.offer(score);
                    }
                }
                currentTime++;
            } else {
                if (minHeap.isEmpty()) {
                    continue;
                }
                // 尝试替换之前工作积分少的
                int minValue = minHeap.peek();
                if (score > minValue) {
                    minHeap.poll();
                    minHeap.offer(score);
                }
            }
        }

        while (!minHeap.isEmpty()) {
            res += minHeap.poll();
        }
        System.out.println(res);
    }

    static class Pair<K, V> {
        K key;
        V value;

        Pair(K key, V value) {
            this.key = key;
            this.value = value;
        }

        K getKey() { return key; }
        V getValue() { return value; }
    }
}
