import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/21 14:47
 */
/*
* 项目组共有N个开发人员，项目经理接到了M个独立的需求，每个需求的工作量不同，且每个需求只能由一个开发人员独立完成，不能多人合作。

假定各个需求直接无任何先后依赖关系，请设计算法帮助项目经理进行工作安排，使整个项目能用最少的时间交付。

输入描述
第一行输入为M个需求的工作量，单位为天，用逗号隔开。 例如：X1 X2 X3 … Xm 表示共有M个需求，每个需求的工作量分别为X1天，X2天…Xm天。其中0<M<30；0<Xm<200 第二行输入为项目组人员数量N 例如： 5 表示共有5名员工，其中0<N<10.

输出描述
最快完成所有工作的天数 例如： 25 表示最短需要25天能完成所有工作。

用例1
输入
8 8 8 8 8 1
3
输出
16
用例2
输入
10 10 10 10
2
输出
20
*/
public class BSMinWorkTime {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] demands = Arrays.stream(sc.nextLine().split(",")).mapToInt(Integer::parseInt).toArray();
        int personNumber=sc.nextInt();
        int min= Arrays.stream(demands).min().getAsInt();
        int max=Arrays.stream(demands).sum();
        int res=0;
        // Java 原生的 Arrays.sort() 不支持直接对 int[] 使用降序比较器，因此需要先转为升序再反转，或者借助流操作或包装类型来实现。
        demands = Arrays.stream(demands)
                .boxed()
                .sorted(Comparator.reverseOrder())
                .mapToInt(Integer::intValue)
                .toArray();
        while(min<=max){
            int mid=(min+max)/2;
            int[] workLoad=new int[personNumber];
            if(dfs(mid,demands,personNumber,workLoad,0)){
                res=mid;
                max=mid-1;
            }else{
                min=mid+1;
            }
        }
        System.out.println(res);

    }

    // 错误解法 它采用的是贪心策略：一旦任务分配给第一个合适的员工，就不会再尝试其他员工。这可能导致无法找到正确解。
    private static boolean check(int days, int[] demands, int personNumber) {
        int[] workLoad=new int[personNumber];
        for (int i = 0; i < demands.length; i++) {
            boolean flag = false;
            for (int j = 0; j < personNumber; j++) {
                if(workLoad[j]+demands[i]<=days){
                    workLoad[j]+=demands[i];
                    flag = true;
                    break;
                }
            }
            if(!flag){
                return false;
            }
        }
        return true;
    }

    // dfs解法相比较上面的解法少了一层for循环 最大的好处就是可以递归回溯
    // 递归尝试将当前index任务分配给每位员工；每层递归处理一个任务 demands[index]，尝试分配给某个员工，再递归处理下一个任务。
    // 若无法分配则回溯；当某条路径不能完成所有任务时，撤销当前操作并尝试其他可能性
    // 剪枝优化：相同负载员工不再重复尝试、某员工未分配任务则直接返回 false；
    /*
    * 搜索树的构建逻辑如下：
根节点：没有任何任务被分配；
每一层代表处理一个任务（即 demands[index]）；
每个子节点代表将当前任务分配给某一个开发人员；
叶子节点：当所有任务都分配完毕，或者某个任务无法分配时终止。*/
    private static boolean dfs(int days, int[] demands, int personNumber,int[] workLoad,int index) {
        if(index==demands.length){
            return true;
        }
        for (int i = 0; i < personNumber; i++) {
            if(i>0&&workLoad[i]==workLoad[i-1]){
                continue;
            }
            if(workLoad[i]+demands[index]<=days){
                workLoad[i]+=demands[index];
                if(dfs(days,demands,personNumber,workLoad,index+1)){
                    return true;
                }
                workLoad[i]-=demands[index];
            }
            if(workLoad[i]==0){
                return false;
            }
        }
        return false;
    }
}
