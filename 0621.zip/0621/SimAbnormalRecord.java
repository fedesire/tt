import java.util.*;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/21 9:53
 */
// 定义Record类，用于存储打卡记录
class Record {
    String id;
    int time;
    int distance;
    String actualDeviceNumber;
    String registeredDeviceNumber;
    int idx;

    public Record(String id, int time, int distance, String actualDeviceNumber, String registeredDeviceNumber, int idx) {
        this.id = id;
        this.time = time;
        this.distance = distance;
        this.actualDeviceNumber = actualDeviceNumber;
        this.registeredDeviceNumber = registeredDeviceNumber;
        this.idx = idx;
    }
}

public class SimAbnormalRecord {
    // 通用split函数
    public static List<String> split(String str, String delimiter) {
        List<String> result = new ArrayList<>();
        int start = 0;
        int end = str.indexOf(delimiter);
        while (end != -1) {
            result.add(str.substring(start, end));
            start = end + delimiter.length();
            end = str.indexOf(delimiter, start);
        }
        result.add(str.substring(start)); // 添加最后一个部分
        return result;
    }

    // 判断是否异常打卡
    public static boolean isNormal(Record r1, Record r2) {
        // 时间间隔少于60s且距离相隔大于5
        return Math.abs(r1.time - r2.time) < 60 && Math.abs(r1.distance - r2.distance) > 5;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine()); // 读取记录数
        Set<Integer> normaIndex = new TreeSet<>(); // 保存异常打卡的下标
        Map<String, List<Record>> idRecordMp = new HashMap<>(); // 按id分组存储打卡记录
        List<String> ans = new ArrayList<>(n); // 存储原始输入
        List<Record> records = new ArrayList<>(n); // 存储所有记录

        for (int i = 0; i < n; i++) {
            String s = scanner.nextLine();
            ans.add(s);
            List<String> tmp = split(s, ",");
            String id = tmp.get(0);
            int time = Integer.parseInt(tmp.get(1));
            int distance = Integer.parseInt(tmp.get(2));
            String actualDeviceNumber = tmp.get(3);
            String registeredDeviceNumber = tmp.get(4);
            Record record = new Record(id, time, distance, actualDeviceNumber, registeredDeviceNumber, i);
            idRecordMp.computeIfAbsent(id, k -> new ArrayList<>()).add(record);
            records.add(record);
        }

        // 检查异常打卡
        for (int i = 0; i < n; i++) {
            Record record = records.get(i);
            // 设备编号异常
            if (!record.actualDeviceNumber.equals(record.registeredDeviceNumber)) {
                normaIndex.add(i);
            }
            // 时间距离打卡异常
            for (Record r1 : idRecordMp.get(record.id)) {
                if (isNormal(record, r1)) {
                    normaIndex.add(r1.idx);
                    normaIndex.add(i);
                }
            }
        }

        // 输出结果
        if (normaIndex.isEmpty()) {
            System.out.println("null");
        } else {
            boolean flag = false;
            for (int x : normaIndex) {
                if (flag) {
                    System.out.print(";");
                }
                System.out.print(ans.get(x));
                flag = true;
            }
        }
    }
}
