import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/21 11:23
 */
/*
* 给定一个矩阵，包含 N * M 个整数，和一个包含 K 个整数的数组。
现在要求在这个矩阵中找一个宽度最小的子矩阵，要求子矩阵包含数组中所有的整数。
输入描述
第一行输入两个正整数 N，M，表示矩阵大小。
接下来 N 行 M 列表示矩阵内容。
下一行包含一个正整数 K。
下一行包含 K 个整数，表示所需包含的数组，K 个整数可能存在重复数字。
所有输入数据小于1000。
输出描述
输出包含一个整数，表示满足要求子矩阵的最小宽度，若找不到，输出-1。
用例1
输入
2 5
1 2 2 3 1
2 3 2 3 2
3
1 2 3
输出
2
说明
矩阵第0、1列包含了1，2，3，矩阵第3，4列包含了1，2，3
用例2
输入
2 5
1 2 2 3 1
1 3 2 3 4
3
1 1 4
输出
5
说明
矩阵第1、2、3、4、5列包含了1、1、4*/
public class PoiMinMatrixWidth {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int rows = scanner.nextInt();
        int cols = scanner.nextInt();
        int[][] matrix=new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j]=scanner.nextInt();
            }
        }
        int n=scanner.nextInt();
        HashMap<Integer,Integer> countMap=new HashMap<>();
        for (int i = 0; i < n; i++) {
            int num=scanner.nextInt();
            countMap.putIfAbsent(num,0);
            countMap.put(num,countMap.get(num)+1);
        }
        int l=0;
        int r=0;
        HashMap<Integer,Integer> currentMap=new HashMap<>();
        int res=Integer.MAX_VALUE;
        boolean flag=false;
        while(r<cols){
            for (int i = 0; i < rows; i++) {
                currentMap.putIfAbsent(matrix[i][r],0);
                currentMap.put(matrix[i][r],currentMap.get(matrix[i][r])+1);
            }

            while(l<=r&&checkIfMatch(currentMap,countMap)){
                flag=true;
                res=Math.min(res,r-l+1);
                // 移除l列
                for (int i = 0; i < rows; i++) {
                    currentMap.put(matrix[i][l],currentMap.get(matrix[i][l])-1);
                }
                l++;
            }
            r++;
        }
        System.out.println(flag?res:-1);
    }

    private static boolean checkIfMatch(HashMap<Integer, Integer> currentMap, HashMap<Integer, Integer> countMap) {
        for (Map.Entry<Integer, Integer> e : countMap.entrySet()) {
            if(currentMap.getOrDefault(e.getKey(),0)<e.getValue()){
                return false;
            }
        }
        return true;
    }
}
