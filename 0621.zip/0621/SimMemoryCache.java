import java.util.ArrayList;
import java.util.List;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/21 10:48
 */
/*
* 请实现一个简易内存池,根据请求命令完成内存分配和释放。

内存池支持两种操作命令，REQUEST和RELEASE，其格式为：
REQUEST=请求的内存大小 表示请求分配指定大小内存，如果分配成功，返回分配到的内存首地址；如果内存不足，或指定的大小为0，则输出error。
RELEASE=释放的内存首地址 表示释放掉之前分配的内存，释放成功无需输出，如果释放不存在的首地址则输出error。
注意：

内存池总大小为100字节。
内存池地址分配必须是连续内存，并优先从低地址分配。
内存释放后可被再次分配，已释放的内存在空闲时不能被二次释放。
不会释放已申请的内存块的中间地址。
释放操作只是针对首地址所对应的单个内存块进行操作，不会影响其它内存块。
输入描述
首行为整数 N , 表示操作命令的个数，取值范围：0 < N <= 100。

接下来的N行, 每行将给出一个操作命令，操作命令和参数之间用 “=”分割。

输出描述
请求分配指定大小内存时，如果分配成功，返回分配到的内存首地址；如果内存不足，或指定的大小为0，则输出error

释放掉之前分配的内存时，释放成功无需输出，如果释放不存在的首地址则输出error。

用例1
输入
2
REQUEST=10
REQUEST=20
1
2
3
输出
0
10
1
2
说明
用例2
输入
5
REQUEST=10
REQUEST=20
RELEASE=0
REQUEST=20
REQUEST=10
1
2
3
4
5
6
输出
0
10
30
0
1
2
3
4
说明
第一条指令，申请地址0~9的10个字节内存，返回首地址0

第二条指令，申请地址10~29的20字节内存，返回首地址10

第三条指令，释放首地址为0的内存申请，0~9地址内存被释放，变为空闲，释放成功，无需输出

第四条指令，申请20字节内存，09地址内存连续空间不足20字节，往后查找到30-49地址，返回首地址30

第五条指令，申请10字节，0~9地址内存空间足够，返回首地址0
* */
import java.util.*;
public class SimMemoryCache{
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        int n=scanner.nextInt();
        scanner.nextLine();
        String[][] commands=new String[n][2];
        for(int i=0;i<n;i++){
            commands[i]=scanner.nextLine().split("=");
        }
        List<int[]> usedMemory=new ArrayList<>();
        usedMemory.add(new int[]{100,101});
        for(int i=0;i<n;i++){
            if(commands[i][0].equals("REQUEST")){
                int requestedSize=Integer.parseInt(commands[i][1]);
                if(requestedSize==0){
                    System.out.println("error");
                    continue;
                }
                int startIndex=0;
                int j=0;
                boolean flag=false;
                while(j<usedMemory.size()){
                    int end=startIndex+requestedSize-1;
                    if(end>=100){
                        System.out.println("error");
                        break;
                    }
                    int[] cur=new int[]{startIndex,end};
                    if(hasInterval(cur,usedMemory.get(j))){
                        startIndex=usedMemory.get(j)[1]+1;
                        j++;
                    }else{
                        usedMemory.add(j,cur);
                        System.out.println(startIndex);
                        flag=true;
                        break;
                    }
                }
                if(!flag){
                    System.out.println("error");
                }
            }else{
                int startAddress=Integer.parseInt(commands[i][1]);
                boolean result = usedMemory.removeIf(ele -> ele[0] == startAddress);
                if(!result){
                    System.out.println("error");
                }
                // 不能直接在遍历集合的过程中修改集合的结构（如添加或删除元素），否则会抛出 ConcurrentModificationException 异常。
                // 使用增强型 for 循环（for-each）时,底层就是使用迭代器实现， 使用 Iterator 迭代器遍历时，但调用集合自身的 remove 方法
                // 会抛出异常 正确做法是使用 Iterator 提供的 remove() 方法 或使用 Java 8+ 的 removeIf 方法
                boolean flag=false;
                for(int[] ele:usedMemory){
                    if(ele[0]==startAddress){
                        usedMemory.remove(ele);
                        flag=true;
                        break;
                    }
                }
                if(!flag){
                    System.out.println("error");
                }
            }
        }
    }
    public static boolean hasInterval(int[] x ,int[] y){
        int start = Math.max(x[0], y[0]);
        int end = Math.min(x[1], y[1]);
        return start<=end;
    }

    // 判断两个区间是否有交集
    private static boolean isIntersection(int start1, int end1, int start2, int end2) {
        if (start1 == start2) {
            return true;
        } else if (start1 < start2) {
            return end1 >= start2;
        } else {
            return end2 >= start1;
        }
    }
}

