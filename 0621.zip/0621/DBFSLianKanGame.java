import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/21 15:53
 */
/*
* 连连看游戏，第一行输入一个[[4,5,4][5,4,5]]字符串代表连连看的地图，第一行输入n，表示操作步骤，接下来n行，每行输入四个数字y1 x1 y2 x2代表此次操作的两个位置。题目要求判断按照操作步骤执行，是否每一步都能进行消除，可以的话输出OK,否则输出NO.

输入描述
第一行输入 一个字符串，代表 连连看的地图。

第二行输出一个 n， 代表操作步骤数

接下来的n行，每一行输入y1 x2 y2 x2代表此次操作的两个表格位置

备注
不必考虑输入不合法的情况

输出描述
输入步骤能全部正常消除则输出OK。否则输出NO

用例1
输入
[[4,5,4],[5,4,5]]
2
0 0 2 0
1 0 0 1
1
2
3
4
输出
YES
1
题解
处理逻辑和：华为OD机试 - 上班之路非常相似，可相互进行借鉴。

思路：BFS + 记忆化搜索

接收输入的地图。可以使用字符串切割实现。
由于连连看规则是可以利用边界进行连接，人为给接受的地图增加四周的边界。降低之后的处理难度。
连连看可以消除的规则是连接两个点不超过三条直线，可以转换为从起点到终点出发拐弯不超过两次。
明白第3的规律之后，我们直接采用BFS +记忆化搜索的方式进行判断两个点是否可以进行消除。基本逻辑如下：
判断输入两个点的位置是否相同，相等则说明不能消除。
判断两个点位置的值是否相同，不相同则说明不能消除。
方向定义：上0，下1，左2，右3， 将方向定义为转换为对应数字。
定义visited[][]数组，其中表示到达该处指定方向的最小拐弯数 用于后续剪枝。此处已经对位置进行压缩pos = x* m + y. 初始数组所有值设置为大值。
接下来使用BFS遍历，判断是否能在两次拐弯的前提下到达终点。每一次移动都具备方向性、已拐弯数量的状态，所以在进行BFS遍历过程中要记录这些状态。
* 使用队列模拟BFS过程中，列中存储int x, y, dir, usedT的类似结构可以定义类或者使用数组保存， 分别表示当前x坐标，当前y坐标，行走的方向，
* 已经使用的拐弯数. 初始往队列中插入起点的四个方向状态(起点可以以任意方向开始)
循环迭代进行队列中元素的四方向探寻，尝试方向currentDir != lastDir时usedT + 1
探寻方向坐标越界剪枝。
到达探寻方向需要拐弯的次数大于2剪枝
探寻位置不是空白区域或者终点结束
利用visisted数组剪枝逻辑，你已这个方向到达过这个位置，如果需要重新探寻需要，拐弯数小于之前到达的位置。
循环迭代完成条件，1迭代到终点，说明可以消除，此时需要把起点和终点设置为空白区域。 2队列为空说明，说明无法连接，返回false。
接受多组消除点，如果按照顺序根据4的逻辑能全部消除则输出OK,反之输出NO
*/
public class DBFSLianKanGame {

    // 状态结构体，记录坐标x,y，方向dir，已用转弯数usedT
    static class State {
        int x, y, dir, usedT;
        State(int x, int y, int dir, int usedT) {
            this.x = x;
            this.y = y;
            this.dir = dir;
            this.usedT = usedT;
        }
    }

    // 方向定义：上0，下1，左2，右3
    static int[] dx = {-1, 1, 0, 0};
    static int[] dy = {0, 0, -1, 1};

    // 拆分字符串，根据分隔符delimiter，delimiter中如果含正则特殊字符需转义
    static List<String> split(String str, String delimiter) {
        // 针对本题，delimiter为"],["，转义为"\],\["用于split
        String regex = delimiter.replace("[", "\\[").replace("]", "\\]");
        return Arrays.asList(str.split(regex));
    }

    // 三条直线内，拐弯不超过两次，判断两个点是否可连通
    static boolean check(List<List<String>> grid, int x1, int y1, int x2, int y2) {
        if (!grid.get(x1).get(y1).equals(grid.get(x2).get(y2))) {
            return false;
        }
        // 同一个点不能连接
        if (x1 == x2 && y1 == y2) {
            return false;
        }
        int n = grid.size();
        int m = grid.get(0).size();

        // visited[pos][dir]表示到达该点方向dir时的最小拐弯数
        int[][] visited = new int[n * m][4];
        for (int i = 0; i < n * m; i++) {
            Arrays.fill(visited[i], Integer.MAX_VALUE);
        }

        Queue<State> q = new LinkedList<>();

        // 起点四个方向均可，拐弯数0
        for (int dir = 0; dir < 4; dir++) {
            visited[x1 * m + y1][dir] = 0;
            q.offer(new State(x1, y1, dir, 0));
        }

        while (!q.isEmpty()) {
            State s = q.poll();
            int x = s.x, y = s.y, dir = s.dir, usedT = s.usedT;
            if (x == x2 && y == y2) {
                // 连通成功，标记消除
                grid.get(x1).set(y1, "*");
                grid.get(x2).set(y2, "*");
                return true;
            }
            for (int ndir = 0; ndir < 4; ndir++) {
                int nx = x + dx[ndir];
                int ny = y + dy[ndir];
                // 边界判断
                if (nx < 0 || ny < 0 || nx >= n || ny >= m) continue;
                // 不是空白且不是目标点，跳过 连连看游戏规定：路径必须经过已经消除的位置（空格），不能穿过其他未被消除的方块。
                if (!(nx == x2 && ny == y2) && !grid.get(nx).get(ny).equals("*")) continue;
                int nUsedT = usedT;
                // 如果方向改变，拐弯数+1
                if (ndir != dir) nUsedT++;
                if (nUsedT > 2) continue;
                int pos = nx * m + ny;
                // 剪枝
                if (nUsedT >= visited[pos][ndir]) continue;
                visited[pos][ndir] = nUsedT;
                q.offer(new State(nx, ny, ndir, nUsedT));
            }
        }
        return false;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        // 输入格式如：[[4,5,4],[5,4,5]]
        String input = br.readLine();

        // 去掉最外层的[[ ]]，变成"4,5,4],[5,4,5"
        input = input.substring(2, input.length() - 2);

        // 分割成每行字符串
        List<String> tmp = split(input, "],[");

        // 解析成二维数组
        int n = tmp.size();
        List<List<String>> tmpGrid = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            List<String> row = Arrays.asList(tmp.get(i).split(","));
            tmpGrid.add(new ArrayList<>(row));
        }

        int m = tmpGrid.get(0).size();

        // 加边界行列，边界填"*"
        List<List<String>> grid = new ArrayList<>();
        // 第一行边界
        List<String> borderRow = new ArrayList<>();
        for (int i = 0; i < m + 2; i++) borderRow.add("*");
        grid.add(borderRow);
        // 中间行
        for (int i = 0; i < n; i++) {
            List<String> row = new ArrayList<>();
            row.add("*");
            row.addAll(tmpGrid.get(i));
            row.add("*");
            grid.add(row);
        }
        // 最后一行边界
        grid.add(new ArrayList<>(borderRow));

        int count = Integer.parseInt(br.readLine());
        while (count-- > 0) {
            String line = br.readLine();
            String[] parts = line.split(" ");
            // 输入坐标是 y1 x1 y2 x2（x对应行，y对应列），+1是因为grid加了边界
            int y1 = Integer.parseInt(parts[0]) + 1;
            int x1 = Integer.parseInt(parts[1]) + 1;
            int y2 = Integer.parseInt(parts[2]) + 1;
            int x2 = Integer.parseInt(parts[3]) + 1;

            if (!check(grid, x1, y1, x2, y2)) {
                System.out.println("NO");
                return;
            }
        }
        System.out.println("OK");
    }
}

