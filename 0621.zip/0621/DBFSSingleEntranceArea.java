/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/21 10:03
 */
import java.util.*;
public class DBFSSingleEntranceArea {
    static int rows, cols; // 矩阵的行数和列数
    static String[][] matrix = new String[200][200]; // 存储矩阵
    static int[][] offset = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}}; // 上下左右四个方向的偏移量
    static boolean[][] checked = new boolean[200][200]; // 存储已访问的位置
    static int maxArea = 0; // 最大单入口区域大小
    static int[] maxEntry = null; // 最大区域的入口

    // DFS搜索连通块
    public static int dfs(int i, int j, int[] entry, int count) {
        // 如果位置非法或已经访问或不是空闲区域，则退出
        if (i < 0 || i >= rows || j < 0 || j >= cols || checked[i][j] || matrix[i][j].equals("X")) {
            return 0;
        }

        checked[i][j] = true; // 标记该位置已访问
        count=1; // 连通块大小加1

        // 如果是边界上的'O'，记录为可能的入口
        if ((i == 0 || i == rows - 1 || j == 0 || j == cols - 1)) {
            entry[0]++; // 增加入口计数
            entry[1] = i; // 记录入口的行号
            entry[2] = j; // 记录入口的列号
        }

        // 在上下左右四个方向继续搜索
        for (int[] dir : offset) {
            count= count+dfs(i + dir[0], j + dir[1], entry, count);
        }

        return count;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        rows = scanner.nextInt();
        cols = scanner.nextInt();

        // 读入矩阵
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = scanner.next();
            }
        }

        int maxSize = 0; // 最大区域大小
        int[] maxRegionEntry = null; // 最大区域的入口坐标

        // 遍历矩阵，对每个未访问的空闲位置进行DFS
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (matrix[i][j].equals("O") && !checked[i][j]) {
                    int[] entry = new int[3]; // 用于记录入口：entry[0]=入口数, entry[1]=行, entry[2]=列
                    int area = dfs(i, j, entry, 0); // 计算区域大小

                    // 如果是单入口区域，更新最大值
                    if (entry[0] == 1) {
                        if (area > maxSize) {
                            maxSize = area;
                            maxRegionEntry = new int[]{entry[1], entry[2], area};
                        } else if (area == maxSize) {
                            maxRegionEntry = null; // 存在多个最大区域
                        }
                    }
                }
            }
        }

        // 输出结果
        if (maxSize == 0) { // 没有单入口区域
            System.out.println("NULL");
        } else if (maxRegionEntry != null) { // 唯一的最大单入口区域
            System.out.println(maxRegionEntry[0] + " " + maxRegionEntry[1] + " " + maxRegionEntry[2]);
        } else { // 存在多个最大单入口区域
            System.out.println(maxSize);
        }
    }


}

