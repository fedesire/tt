import java.util.*;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/12 14:05
 */

/*
* 模拟一套简化的序列化传输方式，请实现下面的数据编码与解码过程

编码前数据格式为 [位置,类型,值]，多个数据的时候用逗号分隔，位置仅支持数字，不考虑重复等场景；类型仅支持：Integer / String / Compose（Compose的数据类型表示该存储的数据也需要编码）。

编码后数据参考图示，数据区的格式是：位置#类型#长度#数据，类型存储需要编码，Integer->0；String->1；Compose->2，长度是指数据的字符长度；数据仅允许数字、大小写字母、空格。



输入的编码字符长度不能超过1000，一个数据的格式错误，则解析剩下数据，其他错误输出ENCODE_ERROR。

输入的解码字符不能超过1000，数据区异常则跳过继续解析剩余数据区，其他异常输出DECODE_ERROR。

输入描述
输入有两行：

第一行是命令，1表示编码，2表示解码, 第二行输入待编码、解码的字符

数据最多嵌套10层，[1,Compose,[1,String,Second]] 为2层嵌套

输出描述
如果输入要求是编码，则输出编码结果；如果输入要求是解码，则输出解码结果；当异常时输出对应的错误字符

用例1
输入
1
[1,String,I am Mary],[2,Integer,23],[3,Long,1000000],[4,Compose,[1,String,I am Kitty],[2,Integer,44]]
1
2
输出
1#1#9#I am Mary2#0#2#234#2#25#1#1#10#I am Kitty2#0#2#44
1
说明
由于Long型未不支持类型，所以数据[3,Long,1000000]自动被过滤

用例2
输入
2
1#1#9#I am Mary2#0#2#233#0#3#8794#2#25#1#1#10#I am Kitty2#0#2#44
1
2
输出
[1,String,I am Mary],[2,Integer,23],[3,Integer,879],[4,Compose,[1,String,I am Kitty],[2,Integer,44]]
1
用例3
输入
2
xxx
1
2
输出
DECODE_ERROR
1
说明
输入待解码数据不满足格式要求

用例4
输入
1
[1,String,I am Marry],[2,Integer,23]],
1
2
输出
ENCODE_ERROR
1
说明
输入格式不满足输入格式要求

题解
思路：字符串处理 + 递归

此题考察字符串处理，以及考察处理嵌套类型时递归的应用。
编码和解码的情况分别定义一个函数去进行处理。在编码和解码两种情况下对于嵌套类型的处理都可以使用递归去进行处理。
编码和解码具体逻辑可以参照下面对应代码实现。
*/

public class SimDataTransport {
    // 类型长度映射
    static Map<String, Integer> typeLength = new HashMap<String, Integer>() {{
        put("0", 7);
        put("1", 6);
        put("2", 7);
    }};
    // 类型字符串映射
    static Map<String, String> typeToStringMp = new HashMap<String,String>() {{
        put("0", "Integer");
        put("1", "String");
        put("2", "Compose");
    }};
    // 标志是否出现格式错误
    static boolean flag = false;

    static class Item {
        // 位置
        String pos;
        // 长度
        int count;
        // 类型 数字形式
        String type;
        // 值类型的值
        String value;
        // 复合类型的子数据
        List<Item> children;

        Item(String pos, String type, int count, String value) {
            this.pos = pos;
            this.type = type;
            this.count = count;
            this.value = value;
            this.children = new ArrayList<>();
        }
    }

    // 最顶层按照括号进行切割
    static List<String> splitTopLevelItem(String input) {
        List<String> res = new ArrayList<>();
        int depth = 0;
        int start = 0;
        int n = input.length();
        for (int i = 0; i < n; i++) {
            char c = input.charAt(i);
            if (c == '[') {
                if (depth == 0) {
                    start = i;
                }
                depth++;
            } else if (c == ']') {
                depth--;
                if (depth == 0) {
                    String tmp = input.substring(start, i + 1);
                    res.add(tmp);
                }
            }
            // 出现括号乱序问题 右括号大于左括号数量
            if (depth < 0) {
                flag = true;
                break;
            }
        }

        // 括号左右对数不匹配
        if (depth != 0) {
            flag = true;
        }
        return res;
    }

    // 编码
    static List<Item> encode(String input) {
        List<Item> res = new ArrayList<>();
        if (input.isEmpty()) {
            return res;
        }

        // 解析输入是否已[ 开头 以 ] 结尾
        if (input.charAt(0) != '[' || input.charAt(input.length() - 1) != ']') {
            flag = true;
            return res;
        }

        List<String> ans = splitTopLevelItem(input);
        // 处理字符串过程中括号对数不匹配,出现异常情况,结束
        if (flag) {
            return res;
        }
        int n = ans.size();

        for (int i = 0; i < n; i++) {
            String itemStr = ans.get(i);
            // 去除左右边界括号
            itemStr = itemStr.substring(1, itemStr.length() - 1);

            List<String> currentAns = new ArrayList<>();
            StringBuilder tmp = new StringBuilder();
            int m = itemStr.length();
            int j = 0;
            // 只为了取出位置和类型
            for (; j < m; j++) {
                char c = itemStr.charAt(j);
                if (c != ',') {
                    tmp.append(c);
                } else {
                    currentAns.add(tmp.toString());
                    tmp.setLength(0);
                    if (currentAns.size() == 2) {
                        break;
                    }
                }
            }
            // 根据类型进行不同处理
            String type = currentAns.get(currentAns.size() - 1);
            // 值类型
            if (type.equals("Integer") || type.equals("String")) {
                String value = itemStr.substring(j + 1);
                int count = value.length();
                String typeStr = currentAns.get(1).equals("Integer") ? "0" : "1";
                res.add(new Item(currentAns.get(0), typeStr, count, value));
                // 复合类型
            } else if (type.equals("Compose")) {
                // 下一层嵌套的内容
                String childrenItemStr = itemStr.substring(j + 1);
                // 递归处理 获得子元素
                List<Item> children = encode(childrenItemStr);
                // 计算长度
                int m2 = children.size();
                // 计算长度 嵌套类型的总长度 = 各子片段的长度 + 各子长度类型字符串的长度
                int count = 0;
                String typeStr = "2";
                for (int k = 0; k < m2; k++) {
                    Item item = children.get(k);
                    count += item.count;
                    // 不懂这里为什么加
                    count += typeLength.get(item.type);
                }
                // 添加一个复合类型
                Item composeItem = new Item(currentAns.get(0), typeStr, count, "");
                composeItem.children = children;
                res.add(composeItem);
            }
        }
        return res;
    }

    // 递归格式化输出编码结果
    static void formatEncodePrint(List<Item> items) {
        for (Item item : items) {
            if (item.type.equals("0") || item.type.equals("1")) {
                System.out.print(item.pos + "#" + item.type + "#" + item.count + "#" + item.value);
            } else {
                System.out.print(item.pos + "#" + item.type + "#" + item.count + "#");
                formatEncodePrint(item.children);
            }
        }
    }

    // 递归格式化输出解码结果
    static void formatDecodePrint(List<Item> items) {
        int n = items.size();
        for (int i = 0; i < n; i++) {
            Item item = items.get(i);
            if (item.type.equals("0") || item.type.equals("1")) {
                System.out.print("[" + item.pos + "," + typeToStringMp.get(item.type) + "," + item.value + "]");
            } else {
                System.out.print("[" + item.pos + "," + typeToStringMp.get(item.type) + ",");
                formatDecodePrint(item.children);
                System.out.print("]");
            }
            if (i != n - 1) {
                System.out.print(",");
            }
        }
    }

    // 通用 split 函数
    static List<String> split(String str, String delimiter) {
        List<String> result = new ArrayList<>();
        int start = 0;
        int end = str.indexOf(delimiter);
        while (end != -1) {
            result.add(str.substring(start, end));
            start = end + delimiter.length();
            end = str.indexOf(delimiter, start);
        }
        // 添加最后一个部分
        result.add(str.substring(start));
        return result;
    }

    // 关键：获取子复合类型的字符串内容
    static String getChildrenInput(List<String> parts, int[] index, int count) {
        String pos = "";
        String type = "";
        String value = "";
        int subCount = -1;

        StringBuilder res = new StringBuilder();

        int n = parts.size();
        int tmpCount = 0;

        while (index[0] < n && tmpCount < count) {
            if (pos.equals("")) {
                pos = parts.get(index[0]);
            } else if (type.equals("")) {
                type = parts.get(index[0]);
            } else if (subCount == -1) {
                subCount = Integer.parseInt(parts.get(index[0]));
            } else {
                // 累计长度：类型长度 + 数据长度
                tmpCount += typeLength.get(type) + subCount;

                if (type.equals("0") || type.equals("1")) {
                    value = parts.get(index[0]);
                    if (value.length() < subCount) {
                        // 数据不足，格式错误
                        flag = true;
                        break;
                    }
                    String valuePart = value.substring(0, subCount);
                    String remainngStr = value.substring(subCount);
                    parts.set(index[0], remainngStr);

                    res.append(pos).append("#").append(type).append("#").append(subCount).append("#").append(valuePart);
                    // 因为下一条数据被拼接到当前字符串中，所以退回一步，让decode处理
                    index[0]--;
                } else {
                    // Compose 类型递归处理
                    res.append(pos).append("#").append(type).append("#").append(subCount).append("#");

                    res.append(getChildrenInput(parts, index, subCount));
                    // 递归结束后回退一位，
                    index[0]--;
                }
                // 重置
                pos = "";
                type = "";
                value = "";
                subCount = -1;
            }
            index[0]++;
        }

        // 最后长度没对上则标记错误
        if (tmpCount != count) {
            flag = true;
        }
        return res.toString();
    }

    // 解码
    static List<Item> decode(String input) {
        List<Item> res = new ArrayList<>();
        List<String> parts = split(input, "#");
        int m = parts.size();
        String pos = "";
        String type = "";
        String value = "";
        int count = -1;
        for (int i = 0; i < m; i++) {
            if (pos.equals("")) {
                pos = parts.get(i);
            } else if (type.equals("")) {
                type = parts.get(i);
            } else if (count == -1) {
                count = Integer.parseInt(parts.get(i));
            } else {
                if (type.equals("1") || type.equals("0")) {
                    value = parts.get(i);
                    // 两种情况:
                    // 1. 最后一个数据,长度应该等于count
                    // 2. 不是最后一个数组,长度应该大于count , 由 内容 + 下一个数据的位置编号
                    if ((i != m - 1 && value.length() <= count) || (i == m - 1 && value.length() != count)) {
                        flag = true;
                        break;
                    }
                    String remainngStr = value.substring(count);
                    value = value.substring(0, count);
                    res.add(new Item(pos, type, count, value));
                    parts.set(i, remainngStr);
                    i--;
                } else {
                    int[] j = new int[]{i};
                    String childrenInput = getChildrenInput(parts, j, count);
                    if (flag) {
                        break;
                    }
                    res.add(new Item(pos, type, count, ""));
                    List<Item> childrenItem = decode(childrenInput);
                    res.get(res.size() - 1).children = childrenItem;
                    i = j[0] - 1;
                }
                pos = "";
                type = "";
                count = -1;
                value = "";
            }
        }
        if (!pos.equals("") || !type.equals("") || count != -1 || !value.equals("")) {
            flag = true;
        }
        return res;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int command = sc.nextInt();
        sc.nextLine();
        String input = sc.nextLine();

        if (command == 1) {
            List<Item> items = encode(input);
            if (flag) System.out.println("ENCODE_ERROR");
            else formatEncodePrint(items);
        } else if (command == 2) {
            List<Item> items = decode(input);
            if (flag) System.out.println("DECODE_ERROR");
            else formatDecodePrint(items);
        }
    }
}
