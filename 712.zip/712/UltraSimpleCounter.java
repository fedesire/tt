 import java.util.HashMap;
 import java.util.Map;
 import java.util.Scanner;
/*
* 构造数列，第一个数为n，后面的数不大于前一个的一半，数列奇偶相间或许全为奇数或者全为偶数，数列的元素都是正整数，能构造多少数列。

输入描述
输入一个n

备注
1 <= n < 10000
输出描述
输出可以构造的序列个数

用例1
输入
7

输出
6

说明
可以构成 [7], [7,3], [7,2], [7, 1], [7,3,1],[7,2,1]

用例2
输入
4
1
输出
3
1
说明
可以构成 [4],[4,2],[4,1]
这是一个动态规划问题，目标是计算满足特定条件的递增序列数量。从代码分析，题目要求：

序列必须以数字 n 结尾
序列是严格递增的
相邻元素需要满足：后一个元素 > 前一个元素的2倍（即 a[i+1] > 2 * a[i]）
核心思路
1. 状态分类
代码将所有可能的序列分为4类：

纯奇数序列：所有元素都是奇数
纯偶数序列：所有元素都是偶数
交替序列（末尾奇数）：相邻元素奇偶性交替，最后一个是奇数
交替序列（末尾偶数）：相邻元素奇偶性交替，最后一个是偶数
2. 动态规划状态定义
odd[i]：以位置i结尾的纯奇数序列数量
even[i]：以位置i结尾的纯偶数序列数量
altOdd[i]：以位置i结尾且最后是奇数的交替序列数量
altEven[i]：以位置i结尾且最后是偶数的交替序列数量
3. 状态转移逻辑
对于每个数字 x（从1到n）：

如果 x 是奇数：

- 可以接在纯奇数序列后 → odd[x] = sum(odd[1..x/2]) + 1
- 可以接在交替序列（末尾为奇数）后 → altEven[x] = sum(altOdd[1..x/2]) + 1
如果 x 是偶数：

- 可以接在纯偶数序列后 → even[x] = sum(even[1..x/2]) + 1
- 可以接在交替序列（末尾为偶数）后 → altOdd[x] = sum(altEven[1..x/2]) + 1
4. 关键约束条件
由于题目要求 a[i+1] > 2 * a[i]，所以：

如果当前数字是 x，那么能接在 x 前面的数字最大只能是 x/2
这就是代码中 half = x // 2 的含义*/
public class UltraSimpleCounter {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(); // 读入序列的最大值n
        System.out.println(countSequences(n));
        /**
         * 定义4个数组来存储不同类型序列的状态：
         * - odd[i]: 以位置i结尾的纯奇数递增序列的数量
         * - even[i]: 以位置i结尾的纯偶数递增序列的数量  
         * - altOdd[i]: 以位置i结尾的交替序列且最后是奇数的数量
         * - altEven[i]: 以位置i结尾的交替序列且最后是偶数的数量
         * 
         * 交替序列定义：相邻元素的奇偶性不同（奇-偶-奇或偶-奇-偶）
         */
        long[] odd = new long[n + 1];      // 纯奇数序列状态数组
        long[] even = new long[n + 1];     // 纯偶数序列状态数组
        long[] altOdd = new long[n + 1];   // 交替序列到奇数状态数组
        long[] altEven = new long[n + 1];  // 交替序列到偶数状态数组
        
        long result = 1; // 初始结果为1，表示单元素序列{n}
        
        // 动态规划：从1到n逐个处理每个数字
        for (int x = 1; x <= n; x++) {
            int half = x / 2; // 计算x的一半，用于确定可以接在x后面的数字范围
            
            // 如果当前数字x是奇数
            if (x % 2 == 1) {
                long oddSum = 0, altSum = 0; // 累计计数器
                
                // 遍历所有小于等于x/2的位置，统计可以扩展的序列数量
                // 这里利用了题目的递增性质：后面的数字必须大于前面数字的2倍
                for (int i = 1; i <= half; i++) {
                    oddSum += odd[i];     // 累加所有能接奇数x的纯奇数序列
                    altSum += altEven[i];  // 累加所有能接奇数x的交替序列（当前末尾为偶数）
                }
                
                // 状态转移：
                // 1. 奇数x可以接在纯奇数序列后，形成新的纯奇数序列，+1表示单独的{x}
                odd[x] = oddSum + 1;
                
                // 2. 奇数x可以接在交替序列（末尾为偶数）后，形成交替序列（末尾为奇数）
                // 这里必须要有+1 否则遍历结束后所有altOdd[x]都=0
                altOdd[x] = altSum +1;
                
                // 如果x等于n，说明这些序列都是以n结尾的有效序列，加入最终结果
                if (x == n) {
                    result += oddSum + altSum;
                }
            } 
            // 如果当前数字x是偶数
            else {
                long evenSum = 0, altSum = 0; // 累计计数器
                
                // 遍历所有小于等于x/2的位置，统计可以扩展的序列数量
                for (int i = 1; i <= half; i++) {
                    evenSum += even[i];    // 累加所有能接偶数x的纯偶数序列
                    altSum += altOdd[i];  // 累加所有能接偶数x的交替序列（当前末尾为奇数）
                }
                
                // 状态转移：
                // 1. 偶数x可以接在纯偶数序列后，形成新的纯偶数序列，+1表示单独的{x}
                even[x] = evenSum + 1;
                
                // 2. 偶数x可以接在交替序列（末尾为奇数）后，形成交替序列（末尾为偶数）
                altEven[x] = altSum +1;
                
                // 如果x等于n，说明这些序列都是以n结尾的有效序列，加入最终结果
                if (x == n) {
                    result += evenSum + altSum;
                }
            }
        }
        
        // 输出最终结果：所有以n结尾的有效递增序列数量
        System.out.println(result);
        sc.close();
    }
    private static Map<String, Long> memo = new HashMap<>();

    public static long countSequences(int n) {
        return dfs(n, -1); // 初始状态，未确定模式
    }

    // 必须要用long保存 否则大数会超了
    // 遇到示例可以AC 但提交WA时 除了是代码逻辑错误外 还有可能是由于输入数据量的原因 要用Long  BigInteger来保存数据
    // 很多用DP求解的题 也可以用DFS结合记忆化数组求解 因为本身DP就是自底向上一步步递推得到答案的 而dfs是自顶向下 不断递归求解 这个过程中会有重叠子问题 所以可以通过记忆化数组的方式减少一些分支
    private static long dfs(int current, int mode) {
        String key = current + "," + mode;
        if (memo.containsKey(key)) {
            return memo.get(key);
        }

        long count = 1; // 当前数本身可以作为一个有效序列

        int nextMax = current / 2;
        for (int next = 1; next <= nextMax; next++) {
            int curParity = current % 2;
            int nextParity = next % 2;

            if (mode == -1) {
                // 初始状态，尝试进入三种模式
                // 模式0: 全奇
                if (curParity == 1 && nextParity == 1) {
                    count += dfs(next, 0);
                }
                // 模式1: 全偶
                if (curParity == 0 && nextParity == 0) {
                    count += dfs(next, 1);
                }
                // 模式2: 奇偶交替
                if (nextParity != curParity) {
                    count += dfs(next, 2);
                }
            } else if (mode == 0) {
                // 全奇
                if (nextParity == 1) {
                    count += dfs(next, 0);
                }
            } else if (mode == 1) {
                // 全偶
                if (nextParity == 0) {
                    count += dfs(next, 1);
                }
            } else if (mode == 2) {
                // 奇偶交替
                if (nextParity != curParity) {
                    count += dfs(next, 2);
                }
            }
        }

        memo.put(key, count);
        return count;
    }
}


