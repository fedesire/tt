/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/12 9:32
 */

import java.util.*;
/*
* 竖直四子棋的棋盘是竖立起来的，双方轮流选择棋盘的一列下子，棋子因重力落到棋盘底部或者其他棋子之上，当一列的棋子放满时，无法再在这列上下子。一方的4个棋子横、竖或者斜方向连成一线时获胜。

现给定一个棋盘和红蓝对弈双方的下子步骤，判断红方或蓝方是否在某一步获胜。

下面以一个6×5的棋盘图示说明落子过程：



下面给出横、竖和斜方向四子连线的图示：

输入描述
输入为2行，第一行指定棋盘的宽和高，为空格分隔的两个数字；

第二行依次间隔指定红蓝双方的落子步骤，第1步为红方的落子，第2步为蓝方的落子，第3步为红方的落子，以此类推。

步骤由空格分隔的一组数字表示，每个数字为落子的列的编号（最左边的列编号为1，往右递增）。用例保证数字均为32位有符号数。

输出描述
如果落子过程中红方获胜，输出 N,red ；

如果落子过程中蓝方获胜，输出 N,blue ；

如果出现非法的落子步骤，输出 N,error。

N为落子步骤的序号，从1开始。如果双方都没有获胜，输出 0,draw 。

非法落子步骤有两种，一是列的编号超过棋盘范围，二是在一个已经落满子的列上落子。

N和单词red、blue、draw、error之间是英文逗号连接。

用例1
输入
5 5
1 1 2 2 3 3 4 4
Copy
输出
7,red
Copy
说明
在第7步，红方在第4列落下一子后，红方的四个子在第一行连成一线，故红方获胜，输出 7,red。

用例2
输入
5 5
0 1 2 2 3 3 4 4
Copy
输出
1,error
Copy
说明
第1步的列序号为0，超出有效列编号的范围，故输出 1,error。*/
public class DBFSChess {
    // 判断是否有连续 >=4 的相同棋子（上下、左右、两对角）
    static boolean judge(int x, int y, int play, int[][] grid, int n, int m) {
        int[][] directions = {{-1, 0}, {0, -1}, {-1, -1}, {-1, 1}}; // 上、左、对角线、反对角线

        for (int[] dir : directions) {
            int count = 1;
            int cx = x, cy = y;

            // 正方向
            while (true) {
                cx += dir[0];
                cy += dir[1];
                if (cx >= 1 && cx <= n && cy >= 1 && cy <= m && grid[cx][cy] == play) {
                    count++;
                } else {
                    break;
                }
            }
            if (count >= 4) return true;
            // 反方向
            cx = x; cy = y;
            while (true) {
                cx -= dir[0];
                cy -= dir[1];
                if (cx >= 1 && cx <= n && cy >= 1 && cy <= m && grid[cx][cy] == play) {
                    count++;
                } else {
                    break;
                }
            }

            if (count >= 4) return true;
        }
        return false;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int m = sc.nextInt(), n = sc.nextInt(); // 宽、高
        sc.nextLine();
        String[] moves = sc.nextLine().trim().split(" ");

        // 改成int[n + 1][m + 1]; 也AC了
        int[][] grid = new int[n + 2][m + 2]; // 多加一层防止越界

        for (int i = 0; i < moves.length; i++) {
            int y = Integer.parseInt(moves[i]);

            // 非法列
            if (y <= 0 || y > m) {
                System.out.println((i + 1) + ",error");
                return;
            }

            int x = n + 1;
            while (x > 1 && grid[x - 1][y] == 0) {
                x--;
            }

            // 列满了
            if (x == n + 1) {
                System.out.println((i + 1) + ",error");
                return;
            }

            int play = (i % 2 == 0) ? 1 : 2; // 红蓝交替
            grid[x][y] = play;

            // 从第 7 步开始判断是否成线
            if (i >= 6 && judge(x, y, play, grid, n, m)) {
                System.out.println((i + 1) + "," + (play == 1 ? "red" : "blue"));
                return;
            }
        }

        System.out.println("0,draw"); // 无赢家
    }
}

