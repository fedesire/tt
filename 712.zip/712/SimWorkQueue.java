import java.util.*;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/12 11:01
 */
/*
* 让我们来模拟一个工作队列的运作，有一个任务提交者和若干任务执行者，执行者从1开始编号。

提交者会在给定的时刻向工作队列提交任务，任务有执行所需的时间， 执行者取出任务的时刻加上执行时间即为任务完成的时刻，执行者完成任务变为空闲的时刻会从工作队列中取最老的任务执行，若这一时刻有多个空闲的执行者， 其中优先级最高的会执行这个任务。编号小的执行者优先级高，初始状态下所有执行者都空闲。

工作队列有最大长度限制，当工作队列满有新的任务加入队列时，队列中最老的任务会被丢弃。

在工作队列满的情况下，当执行者变为空闲的时刻和新的任务提交的时刻相同时，队列中最老的任务被取出执行，新的任务加入队列。

输入描述
输入为两行。

第一行为 2N 个正整数，代表提交者提交的N个任务的时刻和执行时间。第一个数字是第一个任务的提交时刻，第二个数字是第一个任务的执行时间，以此类推。用例保证提交时刻不会重复，任务按提交时刻升序排列。

第二行为两个数字，分别为工作队列的最大长度和执行者的数量。

两行的数字都由空格分割。N不超过20，数字为不超过1000的正整数。

输出描述
输出两个数字，分别为最后一个任务执行完成的时刻和被丢弃的任务的数量，数字由空格分隔。

用例1
输入
1 3 2 2 3 3
3 2
1
2
输出
7 0
1
说明
两个执行者，队列最大长度3，所有任务均能正常加入并执行，无任务丢弃。

用例2
输入
1 6 2 4 4 3 6 3
1 2
1
2
输出
10 0
1
说明
队列最大长度1较小，但任务提交和执行顺序使得没有任务丢弃。
*/
public class SimWorkQueue {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String[] input = scanner.nextLine().split(" ");
        int n=input.length/2;
        int[][] tasks = new int[n][2];
        for (int i = 0; i < n; i++) {
            tasks[i][0]=Integer.parseInt(input[i*2]);
            tasks[i][1]=Integer.parseInt(input[i*2+1]);
        }
        int maxQueueSize = scanner.nextInt();
        int executorNumber = scanner.nextInt();
        // 存储执行者完成任务的时间
        PriorityQueue<Integer> executor = new PriorityQueue<>();
        PriorityQueue<int[]> workQueue = new PriorityQueue<>((e1,e2)-> e1[0]-e2[0]);
        // 任务提交 有执行者为空就交给最小编号的执行者执行 否则如果队列没满 加入队列 队列满了任务丢弃 执行者空闲了从队列取最老的任务
        int time=1;
        int taskIndex=0;
        int disCardCount=0;
        int  maxTaskEndTime=0;
        while(taskIndex<n||!executor.isEmpty()){
            // 释放当前时间结束的执行者
            while(!executor.isEmpty() &&executor.peek()<=time){
                maxTaskEndTime=Math.max(maxTaskEndTime,executor.poll());
            }
            // 空闲执行者取工作队列任务执行
            while(executor.size()<executorNumber&&!workQueue.isEmpty()){
                executor.add(workQueue.poll()[1]+time);
            }
            // 处理新到达的任务
            if(taskIndex<n&&time>=tasks[taskIndex][0]){
                if(executor.size()<executorNumber){
                    executor.add(time+tasks[taskIndex][1]);
                }else if(workQueue.size() < maxQueueSize){
                    workQueue.add(tasks[taskIndex]);
                }else{
                    disCardCount++;
                }
                taskIndex++;

            }
            // while(executor.size()<executorNumber&&!workQueue.isEmpty()){
            //     executor.add(workQueue.poll()[1]+time);
            // }
            time++;
        }
        System.out.println(maxTaskEndTime+" "+disCardCount);
    }

    public static void getResult() {
        Scanner scanner = new Scanner(System.in);

        // 读取任务信息
        String[] taskInput = scanner.nextLine().split(" ");
        int n = taskInput.length / 2;
        List<int[]> taskList = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            taskList.add(new int[]{Integer.parseInt(taskInput[2 * i]), Integer.parseInt(taskInput[2 * i + 1])});
        }

        // 读取容量和执行者数量
        String[] config = scanner.nextLine().split(" ");
        int capacity = Integer.parseInt(config[0]);
        int executorCount = Integer.parseInt(config[1]);

        // 任务队列
        Queue<int[]> taskQueue = new LinkedList<>();
        // 忙碌执行者队列（根据任务结束时间排序）
        PriorityQueue<int[]> busyExecutor = new PriorityQueue<>(Comparator.comparingInt(a -> a[1]));
        // 空闲执行者队列（存储执行者 ID，按升序排序）
        PriorityQueue<Integer> freeExecutor = new PriorityQueue<>();
        for (int i = 1; i <= executorCount; i++) {
            freeExecutor.add(i);
        }

        int currentTime = 1, dropOutCount = 0, pos = 0, lastFinishTime = -1;

        while (pos < n || !taskQueue.isEmpty()) {
            // 释放当前时间结束的执行者
            while (!busyExecutor.isEmpty() && busyExecutor.peek()[1] <= currentTime) {
                freeExecutor.add(busyExecutor.poll()[0]);
            }

            // 空闲执行者取任务执行
            while (!freeExecutor.isEmpty() && !taskQueue.isEmpty()) {
                int executorId = freeExecutor.poll();
                int[] task = taskQueue.poll();
                busyExecutor.add(new int[]{executorId, currentTime + task[1]});
                lastFinishTime = Math.max(lastFinishTime, currentTime + task[1]);
            }

            // 处理新到达的任务
            if (pos < n && currentTime >= taskList.get(pos)[0]) {
                taskQueue.add(taskList.get(pos));
                pos++;

                // 任务队列超出容量则丢弃任务
                while (taskQueue.size() > capacity) {
                    taskQueue.poll();
                    dropOutCount++;
                }

                // 任务投递后再次尝试分配给空闲执行者
                while (!freeExecutor.isEmpty() && !taskQueue.isEmpty()) {
                    int executorId = freeExecutor.poll();
                    int[] task = taskQueue.poll();
                    busyExecutor.add(new int[]{executorId, currentTime + task[1]});
                    lastFinishTime = Math.max(lastFinishTime, currentTime + task[1]);
                }
            }

            currentTime++;
        }

        System.out.println(lastFinishTime + " " + dropOutCount);
    }
}

