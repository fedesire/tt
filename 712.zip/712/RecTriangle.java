import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/12 9:40
 */
/*
* 最多几个直角三角形
华为OD机试真题目录点击查看: 华为OD机试2025B卷真题题库目录｜机考题库 + 算法考点详解

华为OD机试2025B卷 200分题型

题目描述
有N条线段，长度分别为a[1]-a[n]。

现要求你计算这N条线段最多可以组合成几个直角三角形。

每条线段只能使用一次，每个三角形包含三条线段。

输入描述
第一行输入一个正整数T（1<＝T<＝100），表示有T组测试数据.

对于每组测试数据，接下来有T行，

每行第一个正整数N，表示线段个数（3<＝N<＝20），接着是N个正整数，表示每条线段长度，（0<a[i]<100）。

输出描述
对于每组测试数据输出一行，每行包括一个整数，表示最多能组合的直角三角形个数

用例1
输入
1
7 3 4 5 6 5 12 13
1
2
输出
2
1
说明
可以组成2个直角三角形（3，4，5）、（5，12，13）

题解
思路：递归回溯 + 剪枝处理

对于每组输入使用递归回溯 + 剪枝进行求解可组成三角形最大个数。每组数据处理逻辑如下：

数据预处理: 边长存储转换至边长的平方,因为判断直角三角形的公式为a^ 2 + b ^2 = c ^2,减少后续平方计算，使用side[]存储。使用sideLengthSet集合记录出现过的边的平方，用于后续剪枝。将side进行升序排序。
通过递归回溯求解最多能组成多少直角三角形。定义used[]记录某条边是否被使用过。递归每一层基本逻辑如下：
通过第一层循环枚举第一条边 i，如果used[i] == true,直接跳过。
通过第二层循环枚举第二层边j，如果used[j] == true，直接跳过。此时通过两条边可以确定第三条边长度side[i] + side[j] == c,可以通过sideLengthSet判断c是否存在来进行剪枝。
通过第三层循环第三条边 m,如果used[m] == true or used[m] != c直接跳过。如果side[m] > c直接结束循环，因为side[]是递增的。如果存在side[m] == c将对应三条边标记为已访问，继续下一层递归。
通过2递归回溯逻辑可以计算出每一组输入数据的结果，换行输出即可。
*/
public class RecTriangle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int t = scanner.nextInt();
        while(t-->0){
            int n = scanner.nextInt();
            int[] arr=new int[n];
            Set<Integer> set=new HashSet<>();
            for (int i = 0; i < n; i++) {
                int temp=scanner.nextInt();
                arr[i]=temp*temp;
                set.add(arr[i]);
            }
            Arrays.sort(arr);
            boolean[] visited = new boolean[n];
            int res=getTriangleCount(arr,n,visited,set);
            System.out.println(res);

        }
    }

    private static int getTriangleCount(int[] arr,int n,boolean[] visited,Set<Integer> set) {
        int res=0;
        for (int i = 0; i <n-2 ; i++) {
            if(visited[i]){
                continue;
            }
            for (int j = i+1; j < n-1; j++) {
                if(visited[j]){
                    continue;
                }
                if(!set.contains(arr[i]+arr[j])){
                    continue;
                }
                for (int k = j+1; k < n; k++) {
                    if(arr[i]+arr[j]<arr[k]){
                        break;
                    }
                    if(visited[k]){
                        continue;
                    }
                    if(arr[i]+arr[j]!=arr[k]){
                        continue;
                    }

                    visited[i]=visited[j]=visited[k]=true;
                    res=Math.max(res,getTriangleCount(arr,n,visited,set)+1);
                    visited[i]=visited[j]=visited[k]=false;
                }
            }
        }
        return res;
    }
}
