import java.util.Arrays;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/7 11:13
 */
import java.util.*;
/*从一个 N * M（N ≤ M）的矩阵中选出 N 个数，任意两个数字不能在同一行或同一列，求选出来的 N 个数中第 K 大的数字的最小值是多少。

输入描述
输入矩阵要求：1 ≤ K ≤ N ≤ M ≤ 150
输入格式：

N M K
N*M矩阵
1
2
输出描述
N*M 的矩阵中可以选出 M! / N! 种组合数组，每个组合数组种第 K 大的数中的最小值。无需考虑重复数字，直接取字典排序结果即可。

注意：结果是第 K 大的数字的最小值

示例1
输入
3 4 2
1 5 6 6
8 3 4 3
6 8 6 3
1
2
3
4
输出
3
1
说明
N*M的矩阵中可以选出 M！/ N！种组合数组，每个组合数组种第 K 大的数中的最小值；
上述输入中选出数组组合为：
1,3,6;
1,3,3;
1,4,8;
1,4,3;
…
上述输入样例中选出的组合数组有24种，最小数组为1,3,3，则第2大的最小值为3

题解
思路：二分 + 深度优先遍历，二分枚举可能结果值，初始设置left = 1, right = 矩阵最大值 mid = (left+ right ) / 2。采用深度优先遍历判断满足条件任意两个数字不能在同一行或同一列下，结合的数小于等于mid的数量是否大于 k.

满足：right= mid - 1;
不满足： left= mid + 1;
直到left > right结束，这时候的left就是结果值。
*/
public class DBFSMatrix {
    static int n, m, k;
    static int[][] matrix;
    static int[] match;
    static boolean[] visited;

    // 深度优先搜索寻找增广路径 在当前行 row 上寻找可以匹配的列
    static boolean dfs(int row, int threshold) {
        for (int col = 0; col < m; col++) {
            if (!visited[col] && matrix[row][col] <= threshold) {
                visited[col] = true;
                // 当前列 col 已经被 match[col] 行占用,尝试从 match[col] 行出发，寻找其他列的匹配,因为visited[col]已经设为true 所以寻找到的一定是其他列的匹配
                if (match[col] == -1 || dfs(match[col], threshold)) {
                    match[col] = row;
                    return true;
                }
            }
        }
        return false;
    }

    // 检查是否能找到至少 (n - k + 1) 对匹配
    static boolean isValid(int threshold) {
        Arrays.fill(match, -1);
        int matchCount = 0;
        // 每一行 row尝试找一个合适的列进行匹配,每次必须要重新设置visited为false,因为每一次 DFS 是一个独立的探索路径，不能受到上一次搜索的影响。
        // 如果不重新设置为false 可能第一行进行dfs时就已经把很多列都访问过了，下次第二行再进行dfs时这些列就无法访问了
        for (int row = 0; row < n; row++) {
            Arrays.fill(visited, false);
            if (dfs(row, threshold)) {
                matchCount++;
            }
        }
        // 可以选出matchCount个满足任意两个数字不能在同一行或同一列的数<=threshold
        return matchCount >= n - k + 1;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        n = scanner.nextInt();
        m = scanner.nextInt();
        k = scanner.nextInt();

        matrix = new int[n][m];
        match = new int[m];
        visited = new boolean[m];

        int minValue = 1, maxValue = Integer.MIN_VALUE;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                matrix[i][j] = scanner.nextInt();
                maxValue = Math.max(maxValue, matrix[i][j]);
            }
        }

        // 二分查找
        while (minValue <= maxValue) {
            int mid = (minValue + maxValue) / 2;
            if (isValid(mid)) {
                maxValue = mid - 1;
            } else {
                minValue = mid + 1;
            }
        }

        System.out.println(minValue);
        scanner.close();
    }
}


