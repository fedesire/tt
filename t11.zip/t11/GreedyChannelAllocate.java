import java.util.ArrayList;
import java.util.List;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/7 15:03
 */
import java.util.*;
/*
* 算法工程师小明面对着这样一个问题 ，需要将通信用的信道分配给尽量多的用户:

信道的条件及分配规则如下:

所有信道都有属性:”阶”。阶为 r的信道的容量为 2^r比特;
所有用户需要传输的数据量都一样:D比特;
一个用户可以分配多个信道，但每个信道只能分配给一个用户;
只有当分配给一个用户的所有信道的容量和>=D，用户才能传输数据;
给出一组信道资源，最多可以为多少用户传输数据?

输入描述
第一行，一个数字 R。R为最大阶数。0<=R<20

第二行，R+1个数字，用空格隔开。代表每种信道的数量 Ni。按照阶的值从小到大排列。0<=i<=R,0<=Ni<1000.

第三行，一个数字 D。D为单个用户需要传输的数据量。0<D<1000000

输出描述
一个数字（代表最多可以供多少用户传输数据）

用例1
输入
5
10 5 0 1 3 2
30
输出
4

题解
思路：数学 + 贪心

将这道题转换为二进制减法进行操作。将D转换成二进制形式,例如D等于5的时候为101, 对应就是需要一个零阶 和 2阶的信道。
如果将D的二进制转换为数组并且反序变成了[1,0,1]和输入的R数组之间[10,5,0,1,3,2] 你发现没有就可以将这个题目转换为减法。数组中左边为低位右边为高位。
题目结果就转变为R数组 可以减去多少次 D数组 。
接下来开始模拟减法计算，优先从高位进行相减。注意一个特殊情况，当R[j] < D[j]时此时需要进行借位，这里和日常中从小到大进行相减不同，我们既可以高位又可以从低位借位。对于这种情况我们优先从低位借位，因为高位借位就过多增加损耗。低位不能借的时候再考虑从高位借。重点说说怎么借位这个操作：
怎么判断不能从低位借呢？只需要R[0:j]的和 sumB和D[0:j]的和sumD,如果sumB < sumD则不能从高位借位。
借位操作， 从高位借位和日常情况我们进行减法操作差不多，不多加说明了。从低位借位，就是将当前位设置为R[j] - D[j](会变为负数), 然后向下位借位设置R[j-1] += R[j] * 2，然后设置R[j] = 0
重复4的操作，直到不能再减，这时候的结果就是最大分配次数。*/
public class GreedyChannelAllocate {
    // 获取数的反转二进制表现形式
    public static List<Integer> getReversedBinaryArray(int D) {
        List<Integer> bits = new ArrayList<>();
        // 提取 D 的二进制位（低位到高位）
        while (D > 0) {
            bits.add(D % 2);
            D /= 2;
        }
        return bits;
    }

    // 二进制位加法
    public static int calculate(List<Integer> num, int n) {
        int res = 0;
        for (int i = 0; i <= n; i++) {
            res += num.get(i) * (1 << i);
        }
        return res;
    }

    public static boolean binSub(List<Integer> nums, List<Integer> subNum) {
        // 从高位开始进行减
        for (int i = subNum.size() - 1; i >= 0; i--) {
            // 对应阶信道足够直接减去
            if (nums.get(i) >= subNum.get(i)) {
                nums.set(i, nums.get(i) - subNum.get(i));
                continue;
            }
            // 接下来是处理不够的情况下 优先选择从低阶补
            // calculate(nums, i)：计算当前阶及以下阶的信道总容量
            // calculate(subNum, i)：计算目标需求中当前阶及以下阶的需求量
            // nums.set(i, nums.get(i) - subNum.get(i))：从当前阶减去需求量 会是一个负数
            // nums.get(i) << 1：将当前阶剩余的信道数乘以2（相当于二进制左移）
            // nums.set(i - 1, nums.get(i - 1) + ...)：将乘以2后的值加到下一阶上
            // nums.set(i, 0)：将当前阶设置为0（因为已经转移到下一阶）
            if (calculate(nums, i) > calculate(subNum, i)) {
                nums.set(i, nums.get(i) - subNum.get(i));
                // 向下一位借，进行转移 需要*2
                nums.set(i - 1, nums.get(i - 1) + (nums.get(i) << 1));
                // 转移后变为0
                nums.set(i, 0);
            } else {
                int j = i + 1;
                boolean flag = false;
                // j只能到sumNum.size 不能到nums.size
                while (j < subNum.size()) {
                    // 有高位可借
                    if (nums.get(j) > 0) {
                        nums.set(j, nums.get(j) - 1);
                        flag = true;
                        break;
                    }
                    j++;
                }
                if (flag) {
                    // i+1 - j-1之间之前减的值按理应该还回去 不过不还也没问题
                    // for (int k = i+1; k < j; j++) {
                    //     nums[k] += subNum[k];
                    // }
                    return true;
                }
                // 无法满足分配了
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int R = sc.nextInt();
        List<Integer> nums = new ArrayList<>();
        for (int i = 0; i <= R; i++) {
            nums.add(sc.nextInt());
        }
        int D = sc.nextInt();
        int res = 0;
        List<Integer> binFormat = getReversedBinaryArray(D);
        // 单独一个信道就能满足传输的情况 处理玩这个之后不必考虑 大于等于 binFormat.size() 阶的信道了
        for (int i = R; i >= binFormat.size(); i--) {
            res += nums.get(i);
        }
        // 保证num数组长度不少于被减数长度 方便后续计算
        while (nums.size() < binFormat.size()) {
            nums.add(0);
        }
        while (binSub(nums, binFormat)) {
            res++;
        }
        System.out.println(res);
    }
}

