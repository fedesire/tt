import java.util.*;
import java.util.stream.Collectors;
/*
* 题目描述
幼儿园两个班的小朋友在排队时混在了一起，每位小朋友都知道自己是否与前面一位小朋友同班，请你帮忙把同班的小朋友找出来。
小朋友的编号是整数，与前一位小朋友同班用Y表示，不同班用N表示。

输入描述
输入为空格分开的小朋友编号和是否同班标志。

比如：6/N 2/Y 3/N 4/Y，表示4位小朋友，2和6同班，3和2不同班，4和3同班。

其中，小朋友总数不超过999，每个小朋友编号大于0，小于等于999。

不考虑输入格式错误问题。

输出描述
输出为两行，每一行记录一个班小朋友的编号，编号用空格分开，且：

编号需按照大小升序排列，分班记录中第一个编号小的排在第一行。
若只有一个班的小朋友，第二行为空行。
若输入不符合要求，则直接输出字符串ERROR。
示例1
输入
1/N 2/Y 3/N 4/Y
1
输出
1 2
3 4
1
2
说明
2的同班标记为Y，因此和1同班。
3的同班标记为N，因此和1、2不同班。
4的同班标记为Y，因此和3同班。
所以1、2同班，3、4同班，输出为
1 2
3 4
1
2
3
4
5
6
示例2
输入
1/N 2/Y 3/N 4/Y 5/Y
1
输出
1 2
3 4 5
*/

public class LogicSplitClass {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<Integer, Integer> mp = new TreeMap<>(); // 自动排序
        int last = -1;
        int count = 0;
        while (scanner.hasNext()) {
            String tmp = scanner.next();
            String[] ans = tmp.split("/");
            count++;
            int id = Integer.parseInt(ans[0]);
            // 输入数据合法性检查
            if (id <= 0 || id > 999 || count > 999) {
                System.out.println("ERROR");
                return;
            }
            // 处理关系
            if (last == -1) {
                mp.put(id, 0);
            } else {
                if (ans[1].equals("N")) {
                    mp.put(id, 1 - mp.get(last));
                } else {
                    mp.put(id, mp.get(last));
                }
            }
            last = id;
        }
        Integer firstClassId = null;
        Integer secondClassId = null;
        for (Map.Entry<Integer, Integer> entry : mp.entrySet()) {
            if(firstClassId==null){
                firstClassId=entry.getValue();
            }
            if(!Objects.equals(entry.getValue(), firstClassId)){
                secondClassId = entry.getValue();
                break;
            }
        }
        Integer finalFirstClassId = firstClassId;
        System.out.println(mp.entrySet().stream().filter(e -> e.getValue().equals(finalFirstClassId)).map(e -> e.getKey().toString()).collect(Collectors.joining(" ")));
        Integer finalSecondClassId = secondClassId;
        System.out.println(mp.entrySet().stream().filter(e -> e.getValue().equals(finalSecondClassId)).map(e -> e.getKey().toString()).collect(Collectors.joining(" ")));

        int classId = -1;
        for (int i = 0; i < 2; i++) {
            boolean flag = false;
            for (Map.Entry<Integer, Integer> entry : mp.entrySet()) {
                int first = entry.getKey();
                int second = entry.getValue();
                if (!flag) {
                    flag = true;
                    if (classId == -1) {
                        classId = second;
                    } else {
                        classId = 1 - classId;
                    }
                }
                if (second == classId) {
                    System.out.print(first + " ");
                }
            }
            System.out.println();
        }
    }
}

