import java.util.HashMap;
import java.util.Map;
/*
* 在第一人称射击游戏中，玩家通过键盘的A、S、D、W四个按键控制游戏人物分别向左、向后、向右、向前进行移动，从而完成走位。

假设玩家每按动一次键盘，游戏任务会向某个方向移动一步，如果玩家在操作一定次数的键盘并且各个方向的步数相同时，此时游戏任务必定会回到原点，则称此次走位为完美走位。

现给定玩家的走位（例如：ASDA），请通过更换其中一段连续走位的方式使得原走位能够变成一个完美走位。其中待更换的连续走位可以是相同长度的任何走位。

请返回待更换的连续走位的最小可能长度。

如果原走位本身是一个完美走位，则返回0。

输入描述
输入为由键盘字母表示的走位s，例如：ASDA

输出描述
输出为待更换的连续走位的最小可能长度。
* 输入
WASDAASD
1
输出
1
*/
/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/7 16:10
 */
import java.util.*;
/*
* 题目要求的完美走位修改之后的字符串AWSD数量相同。
接收输入的字符串，统计每种字符的数量，如果每种字符(AWSD)的数量相同,直接返回0即可，因为它已经是完美走位了。
数量不相同的情况下，就是需要把某些多余平均值字符的多余部分转换给小的。对应找到最小更换长度其实就是找到一段最短区间里面包含所有多于
* 平均值的字符，并且每种字符数量大于等于多余部分数量。可能有点抽象，举个例子，例如现在A多两个，B多一个。你要找的区间就是最短长度并且
* 这段区间至少包含两个A和一个B。
具体的使用代码处理使用双指针进行处理，定义left = 0, right = 0, right开始不断右移，直到区间内满足3的要求时，这时候要寻求最短区间，
* 尝试左边界右移，缩小边界，直到不满足3的要求时。继续尝试right右移。
重复4的操作，直到right超过字符串最后一个位置。期间会记录满足要求的最短区间长度就是结果。*/
public class PoiPefectMove {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        Map<Character, Integer> mp = new HashMap<>();

        // 判断是否能够均分
        if (s.length() % 4 != 0) {
            System.out.println(-1);
            return;
        }

        // 统计字符数量
        for (int i = 0; i < s.length(); i++) {
            mp.put(s.charAt(i), mp.getOrDefault(s.charAt(i), 0) + 1);
        }

        boolean flag = true;
        int subSum = s.length() / 4;
        int total = 0;

        // 根据字符频率计算需要的操作
        for (char c : mp.keySet()) {
            int count = mp.get(c);
            if (count > subSum) {
                mp.put(c, count - subSum);
                flag = false;
                total += mp.get(c);
            } else {
                mp.put(c, 0);
            }
        }

        Map<Character, Integer> mpBack = new HashMap<>(mp);

        if (flag) {
            System.out.println(0);
        } else {
            int res = s.length() + 1;
            int left = 0, right = 0;
            // mpBack上面初始化后下面就不会变了 mp下面会变
            while (right < s.length()) {
                char c = s.charAt(right);
                if (mpBack.get(c) > 0) {
                    if (mp.get(c) > 0) {
                        total--;
                    }
                    mp.put(c, mp.get(c) - 1);
                }
                // total == 0 表示当前窗口包含了所有必须替换的多余字符
                while (total == 0) {
                    res = Math.min(res, right - left + 1);
                    if (mpBack.get(s.charAt(left)) > 0) {
                        mp.put(s.charAt(left), mp.get(s.charAt(left)) + 1);
                        if(mp.get(s.charAt(left))>0){
                            total++;
                        }
                        // total++;
                    }
                    left++;
                }
                right++;
            }
            System.out.println(res);
        }
        sc.close();
    }
}

