import java.util.List;
import java.util.Stack;

// 19. Remove Nth Node From End of List
// https://leetcode.com/problems/remove-nth-node-from-end-of-list/description/
//
// 使用双指针, 对链表只遍历了一遍
// 时间复杂度: O(n) 空间复杂度: O(1)
public class Solution2 {
//删除倒数第n个节点 只要找到他前面即倒数第n+1个节点p即可 该节点p在哪儿不知道 但能知道的是该节点往后走
//    n+1次就是null了 所以可以通过设立两个指针p q来解决 q本来是之后要多走n+1次 改成提前先走n+1步
    public ListNode removeNthFromEnd(ListNode head, int n) {
//删除链表中的节点是要找到节点之前的节点 对于头结点没有前节点 所以设置一个虚拟节点dummyhead
        ListNode dummyHead = new ListNode(0);
        dummyHead.next = head;

        ListNode p = dummyHead;
        ListNode q = dummyHead;
        for( int i = 0 ; i < n + 1 ; i ++ ){
            assert q != null;
            q = q.next;
        }

        while(q != null){
            p = p.next;
            q = q.next;
        }
        p.next = p.next.next;
        return dummyHead.next;
    }
    /*用栈的方法先依次将节点入栈 之后从栈顶弹出 弹出的第n个节点就是需要删除的倒数第Nge节点 且当前栈顶元素就是倒数n+1 将他的next
    * 指向n的next就达到了删除的目的*/
    public ListNode removeNthFromEnd1(ListNode head, int n) {
        ListNode dummy=new ListNode(0,head);
        ListNode cur=dummy;
        Stack<ListNode> stack=new Stack<>();
        while(cur!=null){
            stack.push(cur);
            cur=cur.next;
        }
        for (int i = 0; i < n; i++) {
            stack.pop();
        }
        ListNode pre=stack.peek();
        pre.next=pre.next.next;
        return dummy.next;
    }


        public static void main(String[] args) {

        int arr[] = {1, 2, 3, 4, 5};
        ListNode head = new ListNode(arr);
        System.out.println(head);

        head = (new Solution2()).removeNthFromEnd(head, 2);
        System.out.println(head);
    }
}
