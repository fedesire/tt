// 237. Delete Node in a Linked List
// https://leetcode.com/problems/delete-node-in-a-linked-list/description/
// 时间复杂度: O(1)
// 空间复杂度: O(1)
public class Solution {

    public void deleteNode(ListNode node) {

        // 注意: 这个方法对尾节点不适用。题目中要求了给定的node不是尾节点
        // 我们检查node.next, 如果为null则抛出异常, 确保了node不是尾节点
        //删除节点正常情况必须是能找到该节点的前驱节点改变其next指向就能达到将节点删除的目的 本题给的不是head 而是
        //直接给的要删除的node节点 所以无法找到其前驱 那只能转变思路通过改变node.next的指向达到删除node节点的目的
        //所以先将node的val变成其下一个节点的val 这样看起来node节点没了 多了一个node.next 所以再删掉一个节点就可以
        if(node == null || node.next == null)
            throw new IllegalArgumentException("node should be valid and can not be the tail node.");
        //其实删除的是node.next节点 只是效果是仿佛删除了node节点
        node.val = node.next.val;
        node.next = node.next.next;
    }

    public static void main(String[] args) {

        int[] arr = {1, 2, 3, 4};

        ListNode head = new ListNode(arr);
        System.out.println(head);

        ListNode node2 = head.findNode(2);
        (new Solution()).deleteNode(node2);
        System.out.println(head);
    }
}
