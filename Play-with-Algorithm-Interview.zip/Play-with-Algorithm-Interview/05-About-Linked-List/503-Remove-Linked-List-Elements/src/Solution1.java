// 203. Remove Linked List Elements
// https://leetcode.com/problems/remove-linked-list-elements/description/
// 不使用虚拟头结点
// 时间复杂度: O(n)
// 空间复杂度: O(1)
public class Solution1 {

    public ListNode removeElements(ListNode head, int val) {
        // 需要对头结点进行特殊处理 头结点处理不仅仅是对第一个节点处理 而是要一直处理直到找到val不相等的节点才行
        //因为主要的删除逻辑即第二个while下面的代码上来访问的就是cur.next 判断cur.next是否值为val 这样会漏掉
        // 第一个节点 只判断了从第二个节点开始后面的所有节点是否值为val
        while(head != null && head.val == val){
            ListNode node = head;
            head = head.next;
        }

        if(head == null)
            return head;
        ListNode cur = head;
        while(cur.next != null){ //首先一上来就访问cur.next 假如cur是空就会报错 所以前面if语句就要要有判断
            if(cur.next.val == val){
                ListNode delNode = cur.next;
                cur.next = delNode.next;
            }
            else
                cur = cur.next;
        }
        return head;
    }

    public static void main(String[] args) {

        int[] arr = {1, 2, 6, 3, 4, 5, 6};
        int val = 6;

        ListNode head = new ListNode(arr);
        System.out.println(head);

        (new Solution1()).removeElements(head, val);
        System.out.println(head);
    }
}
