import java.util.TreeSet;

// 349. Intersection of Two Arrays
// https://leetcode.com/problems/intersection-of-two-arrays/description/
// 时间复杂度: O(nlogn)
// 空间复杂度: O(n)
//给定两个数组 求两个数组的公共元素  无需记录元素的出现次数 所以只要记录元素的有和无 用Set
public class Solution {

    public int[] intersection(int[] nums1, int[] nums2) {
        //用到的就是当往set里add的元素是重复元素时会自动过滤掉不加入这个特性
        TreeSet<Integer> record = new TreeSet<Integer>();
        for(int num: nums1)
            record.add(num);
        TreeSet<Integer> resultSet = new TreeSet<Integer>();
        for(int num: nums2) //遍历一次nums2 看其中的元素是否在record中
            if(record.contains(num))
                resultSet.add(num);//不能到这里判断包含之后就加入res[]了 因为这样可能会包含重复的元素
        int[] res = new int[resultSet.size()];
        int index = 0;
        for(Integer num: resultSet)
            res[index++] = num;
        return res;
    }

    private static void printArr(int[] arr){
        for(int e: arr)
            System.out.print(e + " ");
        System.out.println();
    }

    public static void main(String[] args) {

        int[] nums1 = {1, 2, 2, 1};
        int[] nums2 = {2, 2};
        int[] res = (new Solution()).intersection(nums1, nums2);
        printArr(res);
    }
}
