import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;

// 219. Contains Duplicate II
// 给你一个整数数组 nums 和一个整数 k ，判断数组中是否存在两个 不同的索引 i 和 j ，满足 nums[i] == nums[j]
// 且 abs(i - j) <= k 。如果存在，返回 true ；否则，返回 false 。
// 时间复杂度: O(n)
// 空间复杂度: O(k)
public class Solution {

    public boolean containsNearbyDuplicate(int[] nums, int k) {

        if(nums == null || nums.length <= 1)
            return false;

        if(k <= 0)
            return false;

        HashSet<Integer> record = new HashSet<Integer>();
//        滑动窗口长度是固定的
        for(int i = 0 ; i < nums.length; i ++){
            if(record.contains(nums[i]))
                return true;

            record.add(nums[i]);
            if(record.size() == k + 1)

                record.remove(nums[i-k]);

        }

        return false;
    }

    private static void printBool(boolean b){
        System.out.println(b ? "True" : "False");
    }

    public boolean containsNearbyDuplicate1(int[] nums, int k) {
        if(nums==null||nums.length<=1)
            return false;
        if(k<=0)
            return false;
        HashMap<Integer,Integer> record=new HashMap<>();
        for(int i=0;i<nums.length;i++){
            if(record.containsKey(nums[i])&&i-record.get(nums[i])<=k){
                return true;
            }
            record.put(nums[i],i);

        }
        return false;

    }

    public static void main(String[] args) {

        int[] nums = {1, 2, 1};
        int k = 1;
        printBool((new Solution()).containsNearbyDuplicate(nums, k));
    }
}
