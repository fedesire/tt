import java.util.HashMap;

// 447. Number of Boomerangs
// 给定平面上 n 对 互不相同 的点 points ，其中 points[i] = [xi, yi] 。回旋镖 是由点 (i, j, k) 表示的元组 ，
// 其中 i 和 j 之间的距离和 i 和 k 之间的欧式距离相等（需要考虑元组的顺序）。返回平面上所有回旋镖的数量。
// 时间复杂度: O(n^2)
// 空间复杂度: O(n)
public class Solution {

    public int numberOfBoomerangs(int[][] points) {

        int res = 0;
        //注意这里hm是定义在循环里每次都要重新初始化一次的 并不是定义在循环外面 因为以每个点为基准 计算完和其他所有点
        //的距离频次后就要立马统计加入结果res的 如果定义在循环外面然后到最后才统计 那就会多了很多不应该加入的
        //(其实hm定义在循环外面也可以 只是每次进入里面的循环之前都要调用clear()清空一次）
        for( int i = 0 ; i < points.length ; i ++ ){ //length是二维数组的行数 也就是点的个数

            // record中存储 点i 到所有其他点的距离出现的频次
            HashMap<Integer, Integer> record = new HashMap<Integer, Integer>();
            for(int j = 0 ; j < points.length ; j ++)
                if(j != i){
                    // 计算距离时不进行开根运算, 以保证精度
                    int dis = dis(points[i], points[j]);
                    if(record.containsKey(dis))
                        record.put(dis, record.get(dis) + 1);
                    else
                        record.put(dis, 1);
            }

            for(Integer dis: record.keySet())
                res += record.get(dis) * (record.get(dis) - 1);
        }

        return res;
    }

    private int dis(int[] pa, int pb[]){
        return (pa[0] - pb[0]) * (pa[0] - pb[0]) +
               (pa[1] - pb[1]) * (pa[1] - pb[1]);
    }

    public static int numberOfBoomerangs1(int[][] points){
        int res=0;
        //注意这里hm是定义在循环里每次都要重新初始化一次的 并不是定义在循环外面 因为以每个点为基准 计算完和其他所有点
        //的距离频次后就要立马统计加入结果res的 如果定义在循环外面然后到最后才统计 那就会多了很多不应该加入的
        for (int[] p : points) {
            // disCount中存储点p到所有其他点的距离出现的频次
            HashMap<Integer,Integer> disCount=new HashMap<>();
            for (int[] q : points) {
                int dis=(p[0]-q[0])*(p[0]-q[0])+(p[1]-q[1])*(p[1]-q[1]);
                disCount.put(dis,disCount.getOrDefault(dis,0)+1);
            }
            for (Integer dis : disCount.values()) {
                res+=dis*(dis-1);
            }
        }
        return res;
    }

    public static void main(String[] args) {

        int[][] points = {{0, 0}, {1, 0}, {2, 0}};
        System.out.println((new Solution()).numberOfBoomerangs(points));
    }
}
