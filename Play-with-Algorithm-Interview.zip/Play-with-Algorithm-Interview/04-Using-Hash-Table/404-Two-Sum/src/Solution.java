import java.util.HashMap;

// 1. Two Sum
// 给定一个整数数组 nums 和一个整数目标值 target，请你在该数组中找出 和为目标值 target  的那 两个 整数，
// 并返回它们的数组下标。
// 时间复杂度：O(n)
// 空间复杂度：O(n)
public class Solution {

    public int[] twoSum(int[] nums, int target) {
//不能一次性把所有元素放到查找表中然后再依次查找 因为这样会导致相等的元素相互覆盖
       /*在遍历数组的过程中 当遍历到元素v时 只查找v前面的元素看是否有target-v
       即只将v前面的元素放入查找表中 如果v前面的某个元素和v相等 那么这种情况下v就还没有覆盖
       和它相等的元素 此时如果查找成功 就退出 如果失败就将v纳入查找表中 此时虽然已经覆盖了之前的
       v 但已经对问题没有影响了*/

        HashMap<Integer, Integer> record = new HashMap<Integer, Integer>();
        for(int i = 0 ; i < nums.length; i ++){

            int complement = target - nums[i];
            if(record.containsKey(complement)){
                int[] res = {i, record.get(complement)};
                return res;
            }

            record.put(nums[i], i);
        }

        throw new IllegalStateException("the input has no solution");
        //return new int[]{-1,-1}; //throw和return必须二选一 否则编译不通过
    }

    private static void printArr(int[] nums){
        for(int num: nums)
            System.out.print(num + " ");
        System.out.println();
    }

    public static void main(String[] args) {

        int[] nums = {0,4,3,0};
        int target = 0;
        printArr((new Solution()).twoSum(nums, target));
    }
}
