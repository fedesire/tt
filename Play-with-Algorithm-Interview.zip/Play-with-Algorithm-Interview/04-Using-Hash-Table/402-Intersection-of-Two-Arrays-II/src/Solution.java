import java.util.*;

//求两个数组的元素交集 当一个数字在两个数组中都出现了多次 则返回结果中也要出现多次 且是较小的次数
// 350. Intersection of Two Arrays II
// https://leetcode.com/problems/intersection-of-two-arrays-ii/description/
// 时间复杂度: O(nlogn)
// 空间复杂度: O(n)
public class Solution {

    public int[] intersect(int[] nums1, int[] nums2) {
        TreeMap<Integer, Integer> record = new TreeMap<Integer, Integer>();
        for(int num: nums1)
        //必须要先判断是否存在 不判断直接+1不行 因为java里treemap中元素如果不存在时没有默认值比如0的 c++可以
            if(!record.containsKey(num))
                record.put(num, 1);
            else
                record.put(num, record.get(num) + 1);

        ArrayList<Integer> result = new ArrayList<Integer>();
        for(int num: nums2)
            if(record.containsKey(num) && record.get(num) > 0){
                //如果不加getnum>0的条件 当num1有1个2 nums2有两个2这种情况下 result就会多了
                result.add(num);
                record.put(num, record.get(num) - 1);
            }
//        Integer[] ret=(Integer[])result.toArray(); toArray返回的是object[] 不可以这种方法强转为Integer[]
        // 可以是result.toArray(new Integer[]) 但是不能直接传int[]
        int[] ret = new int[result.size()];
        int index = 0;
        for(Integer num: result)
            ret[index++] = num;

        return ret;
    }

    //用int[]直接代替arrayList存放中间的结果
   public int[] intersect1(int[] nums1, int[] nums2) {
        HashMap<Integer, Integer> record = new HashMap<Integer, Integer>();
        for(int num: nums1)
            record.put(num, record.getOrDefault(num,0) + 1);

        int[] result = new int[nums1.length];
        int index=0;
        for(int num: nums2)
            if(record.containsKey(num) && record.get(num) > 0){
                //如果不加getnum>0的条件 当num1有1个2 nums2有两个2这种情况下 result就会多了
                result[index++]=num;
                record.put(num, record.get(num) - 1);
            }

        return Arrays.copyOf(result,index);
    }

    //排序+双指针解法
    public static int[] intersection1(int[] nums1, int[] nums2) {
        Arrays.sort(nums1);
        Arrays.sort(nums2);
        int i=0,j=0;
        int n1=nums1.length,n2=nums2.length;
        int[] res=new int[n1];
        int index=0;
        while(i<n1&&j<n2){
            if(nums1[i]==nums2[j]){
                res[index++]=nums1[i];
                i++;
                j++;
            }
            else if(nums1[i]<nums2[j])
                i++;
            else j++;

        }
        return Arrays.copyOf(res,index);
    }

    private static void printArr(int[] arr){
        for(int e: arr)
            System.out.print(e + " ");
        System.out.println();
    }

    public static void main(String[] args) {

        int[] nums1 = {1, 2, 2, 1};
        int[] nums2 = {2, 2};
        int[] res = (new Solution()).intersect(nums1, nums2);
        printArr(res);
    }
}
