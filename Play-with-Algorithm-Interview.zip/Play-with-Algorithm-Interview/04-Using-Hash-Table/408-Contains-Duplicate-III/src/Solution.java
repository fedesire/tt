import java.util.TreeMap;
import java.util.TreeSet;

// 220. Contains Duplicate III
// 给你一个整数数组 nums 和两个整数 indexDiff 和 valueDiff 。找出满足下述条件的下标对 (i, j)：i != j,
//abs(i - j) <= indexDiff abs(nums[i] - nums[j]) <= valueDiff 如果存在，返回 true ；否则，返回 false
// 时间复杂度: O(nlogk)
// 空间复杂度: O(k)
public class Solution {

    //滑动窗口+有序集合
    public boolean containsNearbyAlmostDuplicate(int[] nums, int k, int t) {

        // 这个问题的测试数据在使用int进行加减运算时会溢出
        // 所以使用long long
        //具体而言，对于元素 x，当我们希望判断滑动窗口中是否存在某个数 y 落在区间 [x−t,x+t]中，只需要判断滑动窗口中
        // 所有大于等于 x−t的元素中的最小元素是否小于等于 x+t 即可。所以使用有序集合来支持这些操作。
        TreeSet<Long> record = new TreeSet<Long>();
        for(int i = 0 ; i < nums.length ; i ++){

            if(record.ceiling((long)nums[i] - (long)t) != null &&
                    record.ceiling((long)nums[i] - (long)t) <= (long)nums[i] + (long)t)
            return true;

            record.add((long)nums[i]);

            if(record.size() == k + 1)
                record.remove((long)nums[i-k]);
        }

        return false;
    }

    private static void printBool(boolean b){
        System.out.println(b ? "True" : "False");
    }

    //错的 明天看这种是逻辑错了不能这样实现 还是更改一下也能行
    //就是错的 用treeset可以 因为滑动窗口限制是k 且里面的元素时有序的 如果存在大于等于 x−t的元素中的最小元素是
    // 小于等于 x+t的 那就是找到结果了 如果不存在 一定能说明他从他前面的元素里都找不到结果 所以此时当元素到达k要移除出去
    // 时 一定是可以的 即每次当一个元素被remove出去时 一定能保证他所有可能存在结果的情况都已经考虑过了
    //但是用treemap 比如测试案例{3,6,0,4}返回结果应该是true 但是当遍历到4时 record.ceilingkey(4-2)先找到的是3 但是不满足
    //下标小于等于2 此时其实6是满足的 但是就已经循环结束了 说明只判断一次是不够的 用ceilingkey的话必须是先保证满足是
    //在下标小于等于k的前提下找到了 如果找不到就可以不考虑其他元素了 否则像这样先不考虑下标的情况下找到然后再由于
    // 下标不满足条件就不考虑其他情况 其实是不符合条件的 用ceilingkey其实没起到作用
    public boolean containsNearbyAlmostDuplicate1(int[] nums, int k, int t) {

        // 这个问题的测试数据在使用int进行加减运算时会溢出
        // 所以使用long long
        TreeMap<Long,Integer> record = new TreeMap<>();
        for(int i = 0 ; i < nums.length ; i ++){
            Long key=record.ceilingKey((long)nums[i] - (long)t);

            if( key!= null && key <= (long)nums[i] + (long)t&&
                    i-record.get(key)<=k)
                return true;

            record.put((long)nums[i],i);

        }
        System.out.println(record);

        return false;
    }

    public static void main(String[] args) {

        int[] nums = {3,6,0,4};
        int k = 2;
        int t = 2;
        printBool((new Solution()).containsNearbyAlmostDuplicate1(nums, k, t));
    }
}
