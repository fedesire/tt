/// 343. Integer Break
/// https://leetcode.com/problems/integer-break/description/
/// 动态规划
/// 时间复杂度: O(n^2)
/// 空间复杂度: O(n)
public class Solution3 {

    public int integerBreak(int n) {

        if(n < 1)
            throw new IllegalArgumentException("n should be greater than zero");

        //memo【i]表示将数字i分割（至少分割成两部分）后得到的最大乘积
        int[] memo = new int[n+1];
        memo[1] = 1;
        for(int i = 2 ; i <= n ; i ++)
            // 求解memo[i]
            for(int j = 1 ; j <= i - 1 ; j ++)
                //i*(i-j)表示刚好分割成i i-j两部分 不再对i-j再分割了 这里很容易漏写 这里不能是memo[j]*memo[i-j]
                memo[i] = max3(memo[i], j * (i - j), j *memo[i-j] );

        return memo[n];
    }

    private int max3(int a, int b, int c){
        return Math.max(a, Math.max(b, c));
    }

    public static void main(String[] args) {

        System.out.println((new Solution3()).integerBreak(8));
        System.out.println((new Solution3()).integerBreak(10));
    }
}
