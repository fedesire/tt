import java.util.LinkedList;
import java.util.Queue;

import javafx.util.Pair;

import javax.swing.tree.TreeNode;


// 279. Perfect Squares
// https://leetcode.com/problems/perfect-squares/description/
// 进一步优化
//
// 时间复杂度: O(n)
// 空间复杂度: O(n)
public class Solution3 {

/*完全平方数问题 建模成无权图的最小路径然后通过BFS用队列解决或者用dp的方式都能解决
* 这道题不要纠结于想他怎么想到要用队列解决的 而是这道题是用BFS搜索到答案的 队列只是实现BFS的辅助结构*/
    public int numSquares(int n) {

        if(n == 0)
            return 0;

        LinkedList<Pair<Integer, Integer>> queue = new LinkedList<Pair<Integer, Integer>>();
        queue.addLast(new Pair<Integer, Integer>(n, 0));

        boolean[] visited = new boolean[n+1];
        visited[n] = true;

        while(!queue.isEmpty()){
            Pair<Integer, Integer> front = queue.removeFirst();//接收的变量必须写出泛型类型 否则下面就得转
            int num = front.getKey();
            int step = front.getValue();

            if(num == 0)
                return step;

            for(int i = 1 ; num - i*i >= 0 ; i ++){
                int a = num - i*i;
                if(!visited[a]){
                    if(a == 0) return step + 1;
                    queue.addLast(new Pair(num - i * i, step + 1));
                    visited[num - i * i] = true;
                }
            }
        }

        throw new IllegalStateException("No Solution.");
    }

    public int numSquares1(int num){
        Queue<Pair<Integer,Integer>> queue=new LinkedList<>();
        queue.add(new Pair<>(num,0));
        boolean[] visited=new boolean[num+1];
        visited[num]=true;
        while(!queue.isEmpty()){
            Pair<Integer, Integer> pair = queue.remove();
            int n=pair.getKey();
            int step=pair.getValue();
            if(n==0)
                return step;
            for(int i=1;i*i<=n;i++){
                int temp=n-i*i;
                if(temp==0)
                    return step+1;
                if(!visited[temp]){
                queue.add(new Pair<>(temp,step+1));
                visited[temp]=true;
                }
            }
        }
        return -1;
    }

    public static void main(String[] args) {

        System.out.println((new Solution3()).numSquares(12));
        System.out.println((new Solution3()).numSquares(13));
    }
}
