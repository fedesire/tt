import java.util.ArrayList;
import java.util.List;
import java.util.LinkedList;
import javafx.util.Pair;

/// 102. Binary Tree Level Order Traversal
/// https://leetcode.com/problems/binary-tree-level-order-traversal/description/
/// 二叉树的层序遍历
/// 时间复杂度: O(n), n为树的节点个数
/// 空间复杂度: O(n)
class Solution {

    // Definition for a binary tree node.
    public class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;
        TreeNode(int x) { val = x; }
    }

    public List<List<Integer>> levelOrder(TreeNode root) {
//返回结果中不同层的节点在不同的list中 所以res是ArrayList<List<>>
        ArrayList<List<Integer>> res = new ArrayList<List<Integer>>();
        if(root == null) //必须要有 否则当root为空时 会报错
            return res;

        // 我们使用LinkedList来做为我们的先入先出的队列
        //linkdedlist继承list接口 deque接口 deque是double ended queue双端队列 即两端都可以插入删除的队列
        //普通的队列只能是一端插入另一端删除 stack的插入删除是push pop queue插入是add offer删除是remove poll
        //deque分为addFirst offerFirst addLast offerLast removeFirst pollFirst removeLast removeFirst
        //queue的add相当于deque的addLast remove相当于removeFirst
        LinkedList<Pair<TreeNode, Integer>> queue = new LinkedList<Pair<TreeNode, Integer>>();

        //访问节点是在该节点出队的时候 在循环前就要将根节点入队 然后循环里就可以按照将节点出队访问即保存值到res中
        // 将左孩子右孩子入队的顺序循环下去 主要也是进入循环的条件就是队列非空
        queue.addLast(new Pair<TreeNode, Integer>(root, 0));//把节点和其所在的层封装在一起入队列 之所以在入队前能很方便的得知其所在层数
        //是因为每个节点入队前都是其父亲节点出队 父节点出队的时候查看到的其层数+1就是子节点的层数
        while(!queue.isEmpty()){

            Pair<TreeNode, Integer> front = queue.removeFirst();
            TreeNode node = front.getKey();
            int level = front.getValue();
            //判断当前节点的层是否是res中已包含的层 相等就说明当前节点肯定在新的层res中还没有 所以要add new
            //因为最开始加入queue的节点层数设的是0 是以0开始的 而size()是从1开始的 res只能取到res[size-1]而现在level=size
            // 所以需要放到res[size]的位置
            //如果最初加入的节点层数设为1 则此时条件就变成level==res.size()+1 因为需要放在res[level-1]的位置 下面也要
            //改成res.get(level-1)
            if(level == res.size())
                res.add(new ArrayList<Integer>());

            assert level < res.size();
            res.get(level).add(node.val); //把当前节点的值加入到该层的结果中

            if(node.left != null)
                queue.addLast(new Pair<TreeNode, Integer>(node.left, level + 1));
            if(node.right != null)
                queue.addLast(new Pair<TreeNode, Integer>(node.right, level + 1));
        }

            //加上下面的代码就可以解决生成二叉树的右视图问题 lc199
//        List<Integer> ans=new ArrayList<>();
//        for (int i = 0; i < res.size(); i++) {
//            List<Integer> temp=res.get(i);
//            ans.add(temp.get(temp.size()-1));
//        }
//        return ans;

        return res;
    }
}
