import javafx.util.Pair;

import java.util.*;

/// 144. Binary Tree Preorder Traversal
/// https://leetcode.com/problems/binary-tree-preorder-traversal/description/
/// 非递归二叉树的前序遍历
/// 时间复杂度: O(n), n为树的节点个数
/// 空间复杂度: O(h), h为树的高度
public class Solution144 {

    // Definition for a binary tree node.
    public class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;
        TreeNode(int x) { val = x; }
    }

    private class Command{
        String s; // go, print go访问 访问某个节点代表包含打印当前节点和访问存在的左右孩子 打印操作在print命令里完成
        TreeNode node;
        Command(String s, TreeNode node){
            this.s = s;
            this.node = node;
        }
    };

    //出栈遇到的命令如果是go 代表访问该节点 则将根据前序遍历的顺序印左右 按照右左印的顺序入栈 因为入栈不代表执行命令
    //命令是只在出栈的时候执行 要想出栈的时候最先执行打印所以入栈的时候打印在最后

    //这种写法前中后序遍历都是同样的在遇到出栈的命令是print命令就将绑定的节点val加入结果集 不同点只在else分支里那三条命令入栈的顺序不同
    //使用Command命令的方法栈中存放的不是节点 而是将节点和相关操作封装在一起的Command 可以很容易的改变成中序后序遍历算法
    // 代码逻辑一样顺序改一下就行 因为这是真正模拟系统栈的方法
    public List<Integer> preorderTraversal(TreeNode root) {
        ArrayList<Integer> res = new ArrayList<Integer>();
        if(root == null)
            return res;
        Stack<Command> stack = new Stack<Command>();
        stack.push(new Command("go", root)); //在进入while循环前就将根节点的go命令入栈 因为while循环进入的条件就是栈非空
        while(!stack.empty()){
            Command command = stack.pop();
//命令只在出栈的时候执行 所以如果出栈遇到的是节点的go命令 就将其对应的左右节点go命令和打印自身的命令入栈
            if(command.s.equals("print"))
                res.add(command.node.val);
            else{
                assert command.s.equals("go");
                //入栈的顺序和实际执行的顺序相反 因为执行是只有出栈的时候才执行
                if(command.node.right != null)
                    stack.push(new Command("go",command.node.right));
                if(command.node.left != null)
                    stack.push(new Command("go",command.node.left));
                stack.push(new Command("print", command.node));
            }
        }
        return res;
    }

    //教科书中的经典非递归算法 前序代码和中序代码类似 但后序算法有比较大的不同 而上面使用command命令的方法
    //可以很容易的改变成中序后序遍历算法 代码逻辑一样顺序改一下就行 因为这是真正模拟系统栈的方法
    public List<Integer> preorderTraversal2(TreeNode root){
        List<Integer> res=new ArrayList<>();
        Stack<TreeNode> stack=new Stack<>();
        //注意循环结束条件不是&& 刚开始stack肯定是空的 root!=null代表当前要处理的节点 stack不为空也是还有要处理的节点
        //循环里全程都是用root来接收更新 root可看作是考察的节点
        while(root!=null||!stack.isEmpty()){
            while(root!=null){
                res.add(root.val); //前序遍历是一看到该节点即入栈前就打印保存结果 中序是节点出栈了才打印/保存结果
                stack.push(root);
                root=root.left;
            }
            //一个节点出栈就代表该节点左边那一侧的所有节点都已经处理结束 但右边还未处理 所以将root置为root.right
            // 又重复上面的沿着左边节点入栈的操作 root可看做是当前考察的节点
            root=stack.pop();
            root=root.right;
        }
        return res;
    }

    //Command方法的改造 不用额外设立一个类 直接用Pair封装 Integer的1代表go 0代表print
    //这种把节点和指令封装在一起然后让整个命令入栈的方式 就不需要像经典解法那里还需要自己思考一些逻辑写出来 这种就
    //更加类似递归的写法 因为递归本身就是调用函数 一个函数其实也是完成一系列操作指令 每次调用也会入栈
    public List<Integer> pre(TreeNode root){
        List<Integer> res=new ArrayList<>();
        if(root==null)
            return res;
        Stack<Pair<TreeNode,Integer>> stack=new Stack<>();
        Pair<TreeNode,Integer> pair=new Pair<>(root,1);
        stack.push(pair);
        while(!stack.isEmpty()){
            Pair<TreeNode,Integer> command=stack.pop();
            if(command.getValue()==0){
                res.add(command.getKey().val);
            }
            else{
                if(command.getKey().right!=null)
                    stack.push(new Pair<>(command.getKey().right,1));
                stack.push(new Pair<>(command.getKey(),0));
                if(command.getKey().left!=null)
                    stack.push(new Pair<>(command.getKey().left,1));
            }
        }
        return res;


    }

}
