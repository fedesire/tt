import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

/// 145. Binary Tree Postorder Traversal
/// https://leetcode.com/problems/binary-tree-postorder-traversal/description/
/// 非递归的二叉树的后序遍历
/// 时间复杂度: O(n), n为树的节点个数
/// 空间复杂度: O(h), h为树的高度
public class Solution145 {

    // Definition for a binary tree node.
    public class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;
        TreeNode(int x) { val = x; }
    }

    private class Command{
        String s;   // go, print
        TreeNode node;
        Command(String s, TreeNode node){
            this.s = s;
            this.node = node;
        }
    };

    public List<Integer> postorderTraversal(TreeNode root) {

        ArrayList<Integer> res = new ArrayList<Integer>();
        if(root == null)
            return res;

        Stack<Command> stack = new Stack<Command>();
        stack.push(new Command("go", root));
        while(!stack.empty()){
            Command command = stack.pop();

            if(command.s.equals("print"))
                res.add(command.node.val);
            else{
                assert command.s.equals("go");
                stack.push(new Command("print", command.node));
                if(command.node.right != null)
                    stack.push(new Command("go",command.node.right));
                if(command.node.left != null)
                    stack.push(new Command("go",command.node.left));
            }
        }
        return res;
    }

    /*前序中序只是res.add(root.val)这一句的顺序不同 后序遍历有的节点需要二次入栈 而且要设一个pre指针用来表示前一个访问的节点
前序中序遍历节点都是很有规律的入栈出栈各一次 前序是在入栈前就访问该节点（将节点val加入结果集）中序是节点先入栈 之后出栈后就
立马访问该节点（加入结果集）后序遍历无法依据入栈出栈的时刻就决定是否访问 因为后序是左右中 而某个节点出栈只代表他的左子树已经完成访问
右子树有没有访问还未知 如果没有右孩子 则很简单直接打印输出该节点 如果有右孩子且上一个访问节点pre是这个右孩子 则说明现在可以打印输出
该根节点来了 如果上个访问的节点pre不是该右孩子 说明右孩子还没有访问 则当前节点现在不能打印输出 所以现在当前节点需要再次入栈
 并将root置为root.right
后序遍历这里的访问并不是节点入栈或出栈就是访问了 必须是加入结果集后才是访问结束 才更新prev*/

    public static List<Integer> postorderTraversal2(TreeNode root){
        List<Integer> ans=new LinkedList<>();
        Stack<TreeNode> stack=new Stack<>();
        TreeNode prev=null; //prev要初始化
        //主要思想：由于在某颗子树访问完成以后，接着就要回溯到其父节点去
        //因此可以用prev来记录访问历史，在回溯到父节点时，可以由此来判断，上一个访问的节点是否为右子树
        while(root!=null||!stack.isEmpty()){
            while(root!=null){
                stack.push(root);
                root=root.left;
            }
            //从栈中弹出的元素，左子树一定是访问完了的
            root=stack.pop();
            //现在需要确定的是是否有右子树，或者右子树是否访问过
            //如果没有右子树，或者右子树访问完了，也就是上一个访问的节点是右子节点时
            //说明可以访问当前节点
            if(root.right==null||prev==root.right){
                ans.add(root.val);
                //更新历史访问记录，这样回溯的时候父节点可以由此判断右子树是否访问完成
                //prev更新只在一个节点已经确定访问结束即加入结果集后 并不和入栈或出栈挂钩
                prev=root;
                root=null;//root看作是每次考察的节点 每次root赋值null代表的意思就是下一轮要从出栈一个节点作为考察的节点
            }else{
                //如果右子树没有被访问，那么将当前节点压栈，访问右子树
                stack.push(root);
                //赋值为root.right刚刚好 因为如果有右孩子 下一轮考察的就是右孩子 没有右孩子root变成空 下一轮刚好就是从栈顶出栈一个节点来考察
                root=root.right;
            }
        }
        return ans;
    }


}
