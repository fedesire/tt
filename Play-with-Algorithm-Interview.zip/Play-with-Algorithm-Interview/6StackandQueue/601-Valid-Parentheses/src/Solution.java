import sun.misc.Queue;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

// 20. Valid Parentheses
// 给定一个只包括 '('，')'，'{'，'}'，'['，']' 的字符串 s ，判断字符串是否有效。//有效字符串需满足：
//左括号必须用相同类型的右括号闭合。
//左括号必须以正确的顺序闭合。
//每个右括号都有一个对应的相同类型的左括号。
// 时间复杂度: O(n)
// 空间复杂度: O(n)
public class Solution {

    public boolean isValid(String s) {
//栈顶元素反映了在嵌套的层次关系中 最近的需要匹配的元素
        Stack<Character> stack = new Stack<Character>();
        for( int i = 0 ; i < s.length() ; i ++ )
            if( s.charAt(i) == '(' || s.charAt(i) == '{' || s.charAt(i) == '[')
                stack.push(s.charAt(i));
            else{

                if( stack.size() == 0 )
                    return false;

                Character c = stack.pop();
// match代表当当前遍历的元素是右括号时 与之相匹配的左括号是谁
                Character match;
//                if( s.charAt(i) == ')' )
//                    match = '(';
//                else if( s.charAt(i) == ']' )
//                    match = '[';
//                else{
                //这一句没有也可以通过 为啥此时match又不需要初始化了 因为在ifelse这里总会匹配到一个条件给match赋值
//                    assert s.charAt(i) == '}';
//                    match = '{';
//                }
                switch(s.charAt(i)) {
                    case ')':
                        match='(';
                        break;
                    case ']':
                        match='[';
                        break;
                    case '}':
                        match='{';
                        break;
                    default:  //不加这一句下面match就报错 说match需要初始化
                        throw new IllegalStateException("Unexpected value: " + s.charAt(i));
                }
                if(c != match)
                    return false;
            }

        if( stack.size() != 0 )
            return false;

        return true;
    }

    public static boolean isValid1(String s){
        Stack<Character> stack=new Stack<>();
        Map<Character,Character> map=new HashMap<>();
        map.put(')','(');//注意是put进去的是右左
        map.put('}','{');
        map.put(']','[');
        for (int i = 0; i < s.length(); i++) {
            if(!map.containsKey(s.charAt(i)))
                stack.push(s.charAt(i));
            else {
                if(stack.size()==0||stack.pop()!=map.get(s.charAt(i)))
                    return false;
            }
        }
        return stack.size()==0;
    }

    //非常巧妙的用到遇到输入是左括号 就把其对应的右括号入栈 这样就可以让原本需要通过辅助数据结构或者多个if判断来比较是否配对
    // 变成直接比较是否相等就能得到结果了
    public static boolean isValid2(String s){
        Stack<Character> stack=new Stack<>();
        for (char c : s.toCharArray()) {
            if(c=='(')
                stack.push(')');
            else if(c=='{')
                stack.push('}');
            else if(c=='[')
                stack.push(']');
            else if(stack.size()==0||stack.pop()!=c)
                return false;
        }
        return stack.size()==0;
    }

    private static void printBool(boolean b){
        System.out.println(b ? "True" : "False");
    }

    public static void main(String[] args) {

        printBool((new Solution()).isValid("()"));
        printBool((new Solution()).isValid("()[]{}"));
        printBool((new Solution()).isValid("(]"));
        printBool((new Solution()).isValid("([)]"));
    }
}
