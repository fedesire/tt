import java.util.List;
import java.util.ArrayList;
/// 17. Letter Combinations of a Phone Number
///给定一个仅包含数字 2-9 的字符串，返回所有它能表示的字母组合。答案可以按 任意顺序 返回。
//给出数字到字母的映射如下（与电话按键相同）。注意 1 不对应任何字母。
/// 时间复杂度: O(2^len(s))
/// 空间复杂度: O(len(s))
class Solution {  //再看一下我写的实现里的注释

    private String letterMap[] = {
                " ",    //0
                "",     //1  0表示空格 1什么也不是 所以传入的数字不能有1
                "abc",  //2
                "def",  //3
                "ghi",  //4
                "jkl",  //5
                "mno",  //6
                "pqrs", //7
                "tuv",  //8
                "wxyz"  //9
    };

    private ArrayList<String> res;

    public List<String> letterCombinations(String digits) {

        res = new ArrayList<String>();
        if(digits.equals("")) //如果不进行边界判断的话 会进行一次fC调用 进而向res中add一个空字符串 但其实此时的解应该什么都没有
            return res;

        findCombination(digits, 0, ""); //使用递归逐步的一位一位的向后生成所有可能的字符串
        return res;
    }

    // s中保存了此时从digits[0...index-1]翻译得到的一个字母字符串 这里的关键是一个而不是所有 设计递归函数要能想到这一点
    // 寻找和digits[index]匹配的字母, 获得digits[0...index]翻译得到的解
    private void findCombination(String digits, int index, String s){

        System.out.println(index + " : " + s);
        if(index == digits.length()){ //注意是length 而不是length-1 index处的数字此时还未处理 index-1处的数字已处理了
            //是index-1=digits.lenght-1 代表所有数字已处理完毕
            res.add(s); //此时已经获得了一个解
            System.out.println("get " + s + " , return");
            return;
        }

        Character c = digits.charAt(index); //值返回给Character而不是简单的char型 是为了下面能调用compareTo
        assert  c.compareTo('0') >= 0 &&
                c.compareTo('9') <= 0 &&
                c.compareTo('1') != 0 ;
        String letters = letterMap[c - '0'];
        /*像二叉树这种自身就是树结构就可以通过.left .right到达其他节点 在dfs(root)里写dfs(root.left) dfs(root.right）
        就能遍历到整棵树的每个节点  本题这种自身不是树结构的树形问题可以通过递归函数里面有循环 循环里面再调用递归函数 来达到遍历所有的目的
        这样进入到下一层的递归里 还是会经过循环 所以能遍历完所有可能*/
        for(int i = 0 ; i < letters.length() ; i ++){
            System.out.println("digits[" + index + "] = " + c +
                    " , use " + letters.charAt(i));
            findCombination(digits, index+1, s + letters.charAt(i));
        }

        System.out.println("digits[" + index + "] = " + c + " complete, return");

        return;
    }

    private static void printList(List<String> list){
        for(String s: list)
            System.out.println(s);
    }

    public static void main(String[] args) {

        printList((new Solution()).letterCombinations("23"));
    }
}
