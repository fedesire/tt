import java.util.LinkedList;
import java.util.List;
import java.util.ArrayList;
import java.util.ArrayList;
/*给定一个不含重复数字的数组 nums ，返回其 所有可能的全排列 。你可以 按任意顺序 返回答案。*/
public class Solution {
    private ArrayList<List<Integer>> res;
    private boolean[] used;
    public List<List<Integer>> permute(int[] nums) {
        res = new ArrayList<>();
        if(nums == null || nums.length == 0)
            return res;

        used = new boolean[nums.length];
        LinkedList<Integer> p = new LinkedList<Integer>();//这里的linkedlist可看做是当做队列来用的
        generatePermutation(nums, 0, p);
        return res;
    }
    // p中保存了一个有index-1个元素的排列。只有一个
    // 向这个排列的末尾添加第index个元素, 获得一个有index个元素的排列
    /*之所以用LinkedLIst 是因为p要经常删除 如果只用插入用ArrayList也适合 增删都需要的场景用LL AL用不会报错但效率低
    LinkedList提供了removeLast() ArrayList没有 只能remove(index) 其实也可以remove(p.size()-1)就行*/
    private void generatePermutation(int[] nums, int index, LinkedList<Integer> p){
        if(index == nums.length){
            res.add((LinkedList<Integer>)p.clone());
//            res.add(new LinkedList<>(p)); //这种也行
            return;
        }
        for(int i = 0 ; i < nums.length ; i ++)
            if(!used[i]){
                used[i] = true;
                p.add(nums[i]);
                generatePermutation(nums, index + 1, p );
                used[i] = false;
                p.removeLast();
            }
    }

    // 不需要index也可以 直接用path.size()代表当前已经有几个元素了
    void dfs(int[] nums,LinkedList<Integer> path){
        if(path.size()==nums.length){
            res.add(new LinkedList<>(path));
            return ;
        }
        for(int i=0;i<nums.length;i++){
            if(!used[i]){
                path.add(nums[i]);
                used[i]=true;
                dfs(nums,path);
                used[i]=false;
                path.removeLast();
            }

        }
    }

    private static void printList(List<Integer> list){
        for(Integer e: list)
            System.out.print(e + " ");
        System.out.println();
    }

    public static void main(String[] args) {

        int[] nums = {1, 2, 3};
        List<List<Integer>> res = (new Solution()).permute(nums);
        for(List<Integer> list: res)
            printList(list);
    }
}
