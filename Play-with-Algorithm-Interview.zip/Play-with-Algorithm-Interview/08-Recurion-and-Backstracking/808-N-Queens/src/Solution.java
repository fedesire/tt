import java.util.*;

/// 51. N-Queens
/// 按照国际象棋的规则，皇后可以攻击与之处在同一行或同一列或同一斜线上的棋子。
//n 皇后问题 研究的是如何将 n 个皇后放置在 n×n 的棋盘上，并且使皇后彼此之间不能相互攻击。
//给你一个整数 n ，返回所有不同的 n 皇后问题 的解决方案。
//每一种解法包含一个不同的 n 皇后问题 的棋子放置方案，该方案中 'Q' 和 '.' 分别代表了皇后和空位。
/// 时间复杂度: O(n^n)
/// 空间复杂度: O(n)
public class Solution {

    private boolean[] col;
    private boolean[] dia1;
    private boolean[] dia2;
    private ArrayList<List<String>> res;

    public List<List<String>> solveNQueens(int n) {

        res = new ArrayList<List<String>>();
        col = new boolean[n];
        dia1 = new boolean[2 * n - 1];
        dia2 = new boolean[2 * n - 1];

        LinkedList<Integer> row = new LinkedList<Integer>();
        putQueen(n, 0, row);

        return res;
    }

    // 尝试在一个n皇后问题中, 摆放第index行的皇后位置
    private void putQueen(int n, int index, LinkedList<Integer> row){

        if(index == n){
            res.add(generateBoard(n, row));
            return;
        }

        for(int i = 0 ; i < n ; i ++)
            // 尝试将第index行的皇后摆放在第i列
            if(!col[i] && !dia1[index + i] && !dia2[index - i + n - 1]){
                row.addLast(i);
                col[i] = true;
                dia1[index + i] = true;
                dia2[index - i + n - 1] = true;
                putQueen(n, index + 1, row);
                col[i] = false;
                dia1[index + i] = false;
                dia2[index - i + n - 1] = false;
                row.removeLast();
            }

        return;
    }

    private List<String> generateBoard(int n, LinkedList<Integer> row){

        assert row.size() == n;

        ArrayList<String> board = new ArrayList<String>();
        for(int i = 0 ; i < n ; i ++){
            char[] charArray = new char[n];
            Arrays.fill(charArray, '.');
            charArray[row.get(i)] = 'Q';
            board.add(new String(charArray));
        }
        return board;
    }

/*方向一的斜线为从右上到左下方向，同一条斜线上的每个位置满足行下标与列下标之和相等，例如 (3,0)(3,0)(3,0) 和 (1,2)(1,2)(1,2)
在同一条方向二的斜线上。因此使用行下标与列下标之和即可明确表示每一条方向二的斜线。

方向二的斜线为从左上到右下方向，同一条斜线上的每个位置满足行下标与列下标之差相等，例如 (0,0)(0,0)(0,0) 和 (3,3)(3,3)(3,3) 在同一条方向一
的斜线上。因此使用行下标与列下标之差即可明确表示每一条方向一的斜线。*/
    public List<List<String>> solveNQueens1(int n) {
        Set columns=new HashSet<>();
        Set diags1=new HashSet<>();
        Set diags2=new HashSet<>();

        List<Integer> temp=new ArrayList<>();
        List<List<String>> res=new ArrayList<>();
        putQueens(columns,diags1,diags2,n,0,res,temp);
        return res;
    }
    public void putQueens(Set columns, Set diags1, Set diags2, int n, int row, List<List<String>> res, List<Integer> temp){
        if(row==n){
            res.add(generateBoard(temp));
            return ;
        }
        //将第row行的皇后放在第i列
        for(int i=0;i<n;i++){
            if(!columns.contains(i)&&!diags1.contains(row+i)&&!diags2.contains(row-i)){
                columns.add(i);
                diags1.add(row+i);
                diags2.add(row-i);
                temp.add(i);
                putQueens(columns,diags1,diags2,n,row+1,res,temp);
                temp.remove(temp.size()-1);
                columns.remove(i);
                diags1.remove(row+i);
                diags2.remove(row-i);

            }
        }

    }
    public List<String> generateBoard(List<Integer> temp){
        int n=temp.size();
        List<String> res=new ArrayList<>();
        for(int i=0;i<n;i++){
            char[] row=new char[n];
            Arrays.fill(row,'.');
            row[temp.get(i)]='Q';
            res.add(new String(row));
        }
        return res;
    }
    private static void printBoard(List<String> board){
        for(String s: board)
            System.out.println(s);
        System.out.println();
    }

    public static void main(String[] args) {

        int n = 4;
        List<List<String>> res = (new Solution()).solveNQueens(n);
        for(List<String> board: res)
            printBoard(board);
    }
}
