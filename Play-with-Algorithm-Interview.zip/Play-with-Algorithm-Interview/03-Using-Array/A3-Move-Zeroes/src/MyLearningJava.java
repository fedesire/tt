/**
 * @author xqi
 * @version 1.0
 * @description: TODO
 * @date 2023/12/10 9:48
 */
public class MyLearningJava {
    private int modifiedMember;
//alt+insert自动生成构造函数 getter setter
    public MyLearningJava(int member) {
        this.modifiedMember = member;
    }

    public static void main(String[] args) {  //生成main函数：psvm
        short i = 1;
        short j = (short) (i + i); //// 在表达式中，byte、short、char 会自动转成int类型再参与运算的 所以直接写short j=i+i不行 即使只有i一种数据类型

        //idea学习
        System.out.println("ghrighi"); //生成打印日志：sout
        for (int k = 0; k < 4; k++) {
            System.out.println("fori生成for循环");
        }

        int num = 0;
        //输入num==2.if自动出来下面的if语句
        if (num == 2) {

        }
        //输num.fori自动出来下面的for语句
        for (int i1 = 0; i1 < num; i1++) {

        }
        System.out.println("grhighr");
        System.out.println("grhighr");
        System.out.println("grihgro");
        extractedfunc();
    }

    //选中要抽取成一个方法的代码->右键Refactor->Extract抽取
    private static int extractedfunc() {
        System.out.println("grhighr");
        System.out.println("grihgro ghrigh griheorig aohfor ghrihg");
        System.out.println("ghoreihgioe");
        System.out.println("owerighori");
        return 1;
    }

    public int getModifiedMember() {
        return modifiedMember;
    }

    public void setModifiedMember(int modifiedMember) {
        this.modifiedMember = modifiedMember;
    }
}

