// 283. Move Zeroes
// https://leetcode.com/problems/move-zeroes/description/
//
// 原地(in place)解决该问题
// 时间复杂度: O(n)
// 空间复杂度: O(1)
class Solution3 {
    public void moveZeroes(int[] nums) {
        int k = 0; // nums中, [0...k)的元素均为非0元素
        // 遍历到第i个元素后,保证[0...i]中所有非0元素 都按照顺序排列在[0...k)中  同时, [k...i] 为 0
        //这个结论(定义)在初始化的时候以及每一轮循环结束(循环体里代码最后一条执行完 但i还没++ i++看作是下一轮了）都成立
        //之所以出现[0..k)都是非0 【k..i]都是0 是因为刚开始i和k在没遇到0之前都是同步的 直到遇到第一个0 k就不动了 i向后找到
        //第一个非0 numsi numsk交换一下 0挪到后面恰好就能让0在后面连续了
        for(int i = 0 ; i < nums.length ; i ++)
            if(nums[i] != 0){
                swap(nums, k++, i);
                //必须是要完整的swap 下面这种不行 如果数组前面刚开始没有0 i和k一直相等时候 下面这种会直接给nums[i]赋值0
//                nums[k++]=nums[i];
//                nums[i]=0;

            }
    }
    public void moveZeroes2(int[] nums) {

        int k = -1; // nums中, [0...k]的元素均为非0元素
        // 遍历到第i个元素后,保证[0...i]中所有非0元素
        // 都按照顺序排列在[0...k]中
        // 同时, [k+1...i] 为 0
        for(int i = 0 ; i < nums.length ; i ++)
            if(nums[i] != 0)
                swap(nums, ++k, i);
    }

    private void swap(int[] nums, int i, int j){
        int t = nums[i];
        nums[i] = nums[j];
        nums[j] = t;
    }

    public static void main(String args[]){

        int[] arr = {0, 1, 0, 3, 12};

        (new Solution3()).moveZeroes(arr);

        for(int i = 0 ; i < arr.length ; i ++)
            System.out.print(arr[i] + " ");
        System.out.println();
    }
}