// 209. Minimum Size Subarray Sum
// https://leetcode.com/problems/minimum-size-subarray-sum/description/
//
// 滑动窗口的思路
// 时间复杂度: O(n)
// 空间复杂度: O(1)
public class Solution3 {

    public int minSubArrayLen(int s, int[] nums) {

        if(s <= 0 || nums == null)
            throw new IllegalArgumentException("Illigal Arguments");

        int l = 0 , r = -1; // nums[l...r]为我们的滑动窗口
        int sum = 0;
        int res = nums.length + 1;
        // 刚开始l不变 让r一直右移直到让滑动窗口里的和大于等于sum 之后l就可以右移了 l右移滑动窗口里的数变少导致和又小于sum
        // r就又会右移让滑动窗口里的数变多 每次和大于sum之后就会让l右移 这样做的含义其实是剪枝 以当前l为左边界 右边界大于r的那些情况
        // 都不用考虑了 因为虽然满足和大于sum但都不会是最小的结果了 所以l右移继续寻找后面的情况

        while(l < nums.length){   // 窗口的左边界在数组范围内,则循环继续 窗口右边界的限制条件在
            // 下面if里 因为肯定是r先加先到头 所以循环的条件只要控制l就行了

            if(r + 1 < nums.length && sum < s) //一旦有数组用[]取值时就要小心是否会出现数组越界问题 所以if的判断里有r+1<length
                sum += nums[++r];
            else // r已经到头 或者 sum >= s
                sum -= nums[l++];

            if(sum >= s)
                res = Math.min(res, r - l + 1);
        }

        if(res == nums.length + 1)
            return 0;
        return res;
    }

    // 刚开始l不变 让r一直右移直到让滑动窗口里的和大于等于sum 之后l就可以右移了 l右移滑动窗口里的数变少导致和又小于sum
    // r就又会右移让滑动窗口里的数变多 每次和大于sum之后就会让l右移 这样做的含义其实是剪枝 以当前l为左边界 右边界大于r的那些情况
    // 都不用考虑了 因为虽然满足和大于sum但都不会是最小的结果了 所以l右移继续寻找后面的情况
    public int minSubArrayLen1(int s, int[] nums) {
        int res=nums.length+1;
        int l=0,r=0;//nums[l...r)为我们的滑动窗口
        int sum=0,n=nums.length;
        while(l<n){
            if(r<n&&sum<s)
                sum+=nums[r++];
            else{
                sum-=nums[l++];
            }
            if(sum>=s)
                res=Math.min(res,r-l);
        }
        if(res==nums.length+1)
            return 0;
        return res;
    }

    public static void main(String[] args) {

        int[] nums = {2, 3, 1, 2, 4, 3};
        int s = 7;
        System.out.println((new Solution3()).minSubArrayLen(s, nums));
    }
}
