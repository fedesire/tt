// 75. Sort Colors
// https://leetcode.com/problems/sort-colors/description/
// 给定一个包含红色、白色和蓝色，一共 n 个元素的数组，原地对它们进行排序，使得相同颜色的元素相邻，并按照红色、白色、蓝色顺序排列。
// 此题中，我们使用整数 0、 1 和 2 分别表示红色、白色和蓝色。
// 计数排序的思路
// 对整个数组遍历了两遍
// 时间复杂度: O(n)
// 空间复杂度: O(k), k为元素的取值范围
public class Solution1 {

    public void sortColors(int[] nums) {

        int[] count = {0, 0, 0};    // 存放0, 1, 2三个元素的频率
        for(int i = 0 ; i < nums.length ; i ++){
            assert nums[i] >= 0 && nums[i] <= 2;
            count[nums[i]] ++;
        }

//        int index = 0;
//        for(int i = 0 ; i < count[0] ; i ++)
//            nums[index++] = 0;
//        for(int i = 0 ; i < count[1] ; i ++)
//            nums[index++] = 1;
//        for(int i = 0 ; i < count[2] ; i ++)
//            nums[index++] = 2;

        for (int i = 0; i < nums.length; i++) {
            if(i<count[0])
                nums[i]=0;
            else if(i>=count[0]&&i<count[0]+count[1])
                nums[i]=1;
            else nums[i]=2;
        }

        // 小练习: 自学编写计数排序算法
    }

    public static void printArr(int[] nums){
        for(int num: nums)
            System.out.print(num + " ");
        System.out.println();
    }

    public static void main(String[] args) {

        int[] nums = {2, 2, 2, 1, 1, 0};
        (new Solution1()).sortColors(nums);
        printArr(nums);
    }
}
