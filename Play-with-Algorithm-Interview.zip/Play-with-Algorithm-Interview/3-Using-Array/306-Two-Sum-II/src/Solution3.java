// 167. Two Sum II - Input array is sorted
// https://leetcode.com/problems/two-sum-ii-input-array-is-sorted/description/
//对撞指针 时间复杂度: O(n) 空间复杂度: O(1)
//为什么能用对撞指针解决这个问题 因为要求的两个元素一定是在数组中的一左一右 所以就先设定初始值为最左和最右
//而且因为是有序数组 所以可以保证当target<l r位置数值之和时  只要右移l num[l]一定是更大的 所以和也是更大 所以右移r是可行的
//同理 左移r也有用的
public class Solution3 {

    public int[] twoSum(int[] numbers, int target) {

        if(numbers.length < 2 /*|| !isSorted(numbers)*/)
            throw new IllegalArgumentException("Illegal argument numbers");

        int l = 0, r = numbers.length - 1;
        while(l < r){

            if(numbers[l] + numbers[r] == target){
                /*int[] res = {l+1, r+1}; //+1是因为题目要求返回的是数在数组中的位置
                return res;*/
                return new int[]{l + 1, r + 1};//必须要加new int[]
            }
            else if(numbers[l] + numbers[r] < target)
                l ++;
            else // numbers[l] + numbers[r] > target
                r --;
        }

        throw new IllegalStateException("The input has no solution");
        // return new int[]{-1,-1};
    }

    private boolean isSorted(int[] numbers){
        for(int i = 1 ; i < numbers.length ; i ++)
            if(numbers[i] < numbers[i-1])
                return false;
        return true;
    }

    private static void printArr(int[] nums){
        for(int num: nums)
            System.out.print(num + " ");
        System.out.println();
    }

    public static void main(String[] args) {

        int[] nums = {2, 7, 11, 15};
        int target = 9;
        printArr((new Solution3()).twoSum(nums, target));
    }
}
