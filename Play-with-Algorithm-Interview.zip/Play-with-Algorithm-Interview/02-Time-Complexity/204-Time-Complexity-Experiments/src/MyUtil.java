/**
 * Created by liuyubobobo.
 */
public class MyUtil {
//    有一种是工具类, 所有方法都是静态的.构造函数设为私有, 就是这个类不需要实例.
//还有的是类本身很大, 构造多个可能爆内存, 还可能数据不一致. 就单例, 构造函数设为私有.

    private MyUtil(){}

    public static Integer[] generateRandomArray(int n, int rangeL, int rangeR) {

        assert n > 0 && rangeL <= rangeR;

        Integer[] arr = new Integer[n];
        for (int i = 0; i < n; i++)
            arr[i] = (int)(Math.random() * (rangeR - rangeL + 1)) + rangeL; //生成[L,R]范围内的随机数等价于[L,R+1)
        return arr;
    }

    public static Integer[] generateOrderedArray(int n) {

        assert n > 0;

        Integer[] arr = new Integer[n];

        for (int i = 0; i < n; i++)
            arr[i] = i;
        return arr;
    }
}
