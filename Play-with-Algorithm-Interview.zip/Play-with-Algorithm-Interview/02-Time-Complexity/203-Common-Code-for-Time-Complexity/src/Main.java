public class Main {

    // O(1)
    private static void swap(Object[] arr, int i, int j){

        if(i < 0 || i >= arr.length)
            throw new IllegalArgumentException("i is out of bound.");

        if(j < 0 || j >= arr.length)
            throw new IllegalArgumentException("j is out of bound.");

        Object temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    // O(n)
    private static int sum(int n){

        if(n < 0)
            throw new IllegalArgumentException("n should be greater or equal to zero.");

        int ret = 0;
        for(int i = 0 ; i <= n ; i ++)
            ret += i;
        return ret;
    }

    private static void reverse(Object[] arr){

        int n = arr.length;
        for(int i = 0 ; i < n / 2 ; i ++ )
            swap(arr, i, n - 1 - i);
    }

    // O(n^2) Time Complexity
    private static void selectionSort(Comparable[] arr, int n){

        for(int i = 0 ; i < n ; i ++){
            int minIndex = i;
            for(int j = i + 1 ; j < n ; j ++)
                if(arr[j].compareTo(arr[minIndex]) < 0)
                    minIndex = j;

            swap(arr, i, minIndex);
        }
    }

    // O(n) Time Complexity
    private static void printInformation(int n){

        for( int i = 1 ; i <= n ; i ++ )
            for( int j = 1 ; j <= 30 ; j ++ )
                System.out.println("Class " + i + " - " + "No. " + j);
    }

    // O(logn) Time Complexity
    private static int binarySearch(Comparable[] arr, int n, int target){

        int l = 0, r = n-1;
        while( l <= r ){
            int mid = l + (r-l)/2;
            if(arr[mid].compareTo(target) == 0) return mid;
            if(arr[mid].compareTo(target) > 0) r = mid - 1;
            else l = mid + 1;
        }
        return -1;
    }

    //实现的就是Integer.toString(int) String.valueOf(int)的功能
    private static String intToString(int num) {

        StringBuilder s = new StringBuilder("");
        String sign = "+";
        if (num < 0) {
            num = -num;
            sign = "-";
        }

        //为啥要加Character. 感觉直接s.append(num % 10);确实可以  Character.getNumericValue('a')是10是什么原理
        // 说明这个方法的功能就不是转换成ascii码 而是仅适用于表示数字的字符，例如数字'0'-'9'返回0-9 为方便起见，
        // 它还将ASCII字母视为基数为36的数字系统中的数字（因此'A'-'Z'('a'-'z')也是 返回10-35
        while(num != 0){
            s.append( num % 10);
            num /= 10;
        }

        if(s.length() == 0)
            s.append('0');

        s.reverse();
        if(sign == "-")
            return sign + s.toString();
        else
            return s.toString();
    }


    // O(nlogn) sz从1开始乘几次2达到n logn次
    private static void hello(int n){

        for( int sz = 1 ; sz < n ; sz += sz )
            for( int i = 1 ; i < n ; i ++ )
                System.out.println("Hello, Algorithm!");
    }


    // O(sqrt(n)) Time Complexity
    //为什么只需判断到根号n就停止 因为如果小于根号n内没有 就一定能推断出大于根号n的也没有 如果有的话
    //一个大于 另一个也要大于（小于已经没有了） 两个都大于 那乘积一定大于n
    private static boolean isPrime(int num){
        //x从2开始 一直加到根号n就停止
        for(int x = 2 ; x*x <= num ; x ++)
            if( num % x == 0 )
                return false;
        return true;
    }

    private static boolean isPrime2(int num){

        if( num <= 1 ) return false;
        if( num == 2 ) return true;
        if( num % 2 == 0 ) return false;

        for(int x = 3 ; x * x <= num ; x += 2)
            if( num%x == 0 )
                return false;

        return true;
    }

    public static void main(String[] args) {
        System.out.println(Character.getNumericValue('1'));
        System.out.println(intToString(123));
        System.out.println(intToString(0));
        System.out.println(intToString(-123));

        if(isPrime2(137)) System.out.println("137 is a prime.");
        else System.out.println("137 is not a prime.");

        if(isPrime2(121)) System.out.println("121 is a prime.");
        else System.out.println("121 is not a prime.");
        Integer[] arr={12,33,34,56,76,77};
        System.out.println(binarySearch(arr, 6, 34));
        Comparable[] arr2={12,33,34,56,76,77}; //接口竟然也能定义数组 定义一个接口类型的引用变量来引用实现接口的类的实例

    }
}
