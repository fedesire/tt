import java.util.*;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/28 21:28
 */
/*
* A公司准备对他下面的N个产品评选最差奖，评选的方式是首先对每个产品进行评分，然后根据评分区间计算相邻几个产品中最差的产品。评选的标准是依次找到从当前产品开始前M个产品中最差的产品，请给出最差产品的评分序列。

输入描述
第一行，数字M，表示评分区间的长度，取值范围是0<M<10000

第二行，产品的评分序列，比如[12,3,8,6,5]，产品质量N范围是-10000 < N <10000

输出描述
评分区间内最差产品的评分序列

用例1
输入
3
12,3,8,6,5
1
2
输出
3,3,5
1
说明
*/
public class DSWorstProduct {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        scanner.nextLine();
        int[] array = Arrays.stream(scanner.nextLine().split(",")).mapToInt(Integer::parseInt).toArray();
        Deque<Integer> queue = new ArrayDeque<>();
        StringJoiner joiner = new StringJoiner(",");
        // for (int i = 0; i < array.length; i++) {
        //     //i-n+1,i
        //     while(!queue.isEmpty()&&queue.peekFirst()<i-n+1){
        //         queue.pollFirst();
        //     }
        //     while(!queue.isEmpty()&&array[queue.peekLast()]>=array[i]){
        //         queue.pollLast();
        //     }
        //     queue.addLast(i);
        //     if(i>=n-1){
        //         joiner.add(String.valueOf(array[queue.peekFirst()]));
        //     }
        // }
        System.out.println(joiner);
        PriorityQueue<int[]> priorityQueue=new PriorityQueue<>((e1,e2)->e1[1]-e2[1]);
        for (int i = 0; i < array.length; i++) {
            while(!priorityQueue.isEmpty()&&priorityQueue.peek()[0]<i-n+1){
                priorityQueue.poll();
            }
            priorityQueue.add(new int[]{i,array[i]});
            if(i>=n-1){
                joiner.add(String.valueOf(priorityQueue.peek()[1]));
            }
        }
        System.out.println(joiner);

    }
}
