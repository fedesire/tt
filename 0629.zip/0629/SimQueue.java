import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Collectors;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/28 11:31
 */
/*
* 现在有一队小朋友，他们高矮不同，我们以正整数数组表示这一队小朋友的身高，如数组{5,3,1,2,3}。
我们现在希望小朋友排队，以“高”“矮”“高”“矮”顺序排列，每一个“高”位置的小朋友要比相邻的位置高或者相等；每一个“矮”位置的小朋友要比相邻的位置矮或者相等；
要求小朋友们移动的距离和最小，第一个从“高”位开始排，输出最小移动距离即可。
例如，在示范小队{5,3,1,2,3}中，{5, 1, 3, 2, 3}是排序结果。
{5, 2, 3, 1, 3} 虽然也满足“高”“矮”“高”“矮”顺序排列，但小朋友们的移动距离大，所以不是最优结果。
移动距离的定义如下所示：
第二位小朋友移到第三位小朋友后面，移动距离为1，若移动到第四位小朋友后面，移动距离为2；
输入描述
排序前的小朋友，以英文空格的正整数：
4 3 5 7 8
1
注：小朋友<100个
输出描述
排序后的小朋友，以英文空格分割的正整数：4 3 7 5 8
备注：4（高）3（矮）7（高）5（矮）8（高）， 输出结果为最小移动距离，只有5和7交换了位置，移动距离都是1。
示例1
输入
4 1 3 5 2

输出
4 1 5 2 3

示例2
输入
1 1 1 1 1
1
输出
1 1 1 1 1
1
示例3
输入
xxx
1
输出
[ ]
1
说明
出现非法参数情况， 返回空数组。
题解
思路：贪心算法实现
这个题其实有点坑的，要求按照高矮高矮的方式进行排序，并要求移动距离最小，但是根据示例1来看并不是这样。对于这种情况一般是根据示例1来编写代码。
根据示例1的结果来推断，这道题的逻辑排序需要应把前面的人排好，再去考虑后面。
那我们可以使用贪心进行排序，处理逻辑如下，遍历到i位置时
如果ans[i] > ans[i-1] && (i % 2) == 1: 交换ans[i], ans[i-1]元素。
ans[i] < ans[i-1] && (i % 2) == 0: 交换ans[i] < ans[i-1]元素。
不存在异常数据的情况，按照3的逻辑进行排序，排序之后的序列就是结果，直接输出即可。额外需要注意输入异常的情况，对于出现不合法的情况直接输出[].*/
public class SimQueue {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        if(!input.matches("[0-9\\s]+")){
            System.out.println("[ ]");
            return ;
        }
        int[] array = Arrays.stream(input.split(" ")).mapToInt(Integer::parseInt).toArray();
        int i=0,j=1;
        while(i<=array.length-2){
            if(array[i]!=array[j]){
                if(array[i]>array[j]!=(i%2==0)){
                    int temp = array[i];
                    array[i]=array[j];
                    array[j]=temp;
                }
            }
            i++;
            j++;
        }
        System.out.println(Arrays.stream(array).mapToObj(String::valueOf).collect(Collectors.joining(" ")));
    }
}
