import java.util.*;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/28 23:01
 */
/*
* 给定一个整数数组 nums、一个数字k，一个整数目标值 target，请问nums中是否存在k个元素使得其相加结果为target，请输出所有符合条件且不重复的k元组的个数

数据范围如下：

2 ≤ nums.length ≤ 200
-10^9 ≤ nums[i] ≤ 10^9
-10^9 ≤ target ≤ 10^9
2 ≤ k ≤ 100
输入描述
第一行是nums取值：2 7 11 15

第二行是k的取值：2

第三行是target取值：9

输出描述
输出第一行是符合要求的元组个数：1

补充说明：[2,7]满足，输出个数是1

用例1
输入
-1 0 1 2 -1 -4
3
0
1
2
3
输出
2
1
说明
[-1,0,1]，[-1,-1,2]满足条件

用例2
输入
2 7 11 15
2
9
1
2
3
输出
1
1
说明
[2,7]符合条件
*/
public class DBFSTripleCount {
    static int res=0;
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] strNums = sc.nextLine().split(" ");
        int k = sc.nextInt();
        int target = sc.nextInt();

        List<Integer> nums = new ArrayList<>();
        for (String s : strNums) {
            nums.add(Integer.parseInt(s));
        }

        if (nums.size() < k) {
            System.out.println(0);
            return;
        }

        Collections.sort(nums);
        dfs(nums,k,target,0,new LinkedList<Integer>(),0);
        System.out.println(res);
    }

    private static void dfs(List<Integer> nums, int k, int target, int index, LinkedList<Integer> path,int sum) {
        if(path.size()==k){
            if(sum==target){
                res++;
            }
            return ;
        }
        if(index==nums.size()){
            return ;
        }
        if(nums.get(index)>0&&sum>target){
            return ;
        }
        for (int i = index; i < nums.size(); i++) {
            if(i>index&& Objects.equals(nums.get(i), nums.get(i - 1))){
                continue;
            }
            path.add(nums.get(i));
            dfs(nums,k,target,i+1,path,sum+nums.get(i));
            path.removeLast();
        }
    }
}
