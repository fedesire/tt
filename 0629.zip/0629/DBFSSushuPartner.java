import java.util.Arrays;
import java.util.Scanner;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/28 10:03
 */
/*
* 定义两个正整数 a 和 b是“素数伴侣”，当且仅当 a+b 是一个素数。
现在，密码学会邀请你设计一个程序，从给定的 n个正整数 {a1,a2,…,an}中，挑选出最多的“素数伴侣”，你只需要输出挑选出的“素数伴侣”对数。保证 n为偶数，一个数字只能使用一次。
输入描述
第一行输入一个正偶数 n(2≦n≦100)代表数字个数。
第二行输入 n个正整数 a1,a2,…,an(1≦ai≦3×10^4)代表给定的数字。
输出描述
输出一个整数，代表最多可以挑选出的“素数伴侣”的数量。
用例1
输入
4
2 5 6 13

输出
2

说明
在这个样例中，2 和 5 可以组成一对素数伴侣，6 和 13也可以组成一对素数伴侣。因此，最多可以挑选出 2对素数伴侣。
用例2
输入
4
1 2 2 2

输出
1

说明
在这个样例中，1 只能使用一次，与任意一个 2组合均是“素数伴侣”。
题解
思路：匈牙利算法实现
判断是否为素数可以使用经典的算法素数筛实现。
可以将题目转换为图来看待，使用匈牙利算法来进行匹配。定义match[]数组,其中match[i]表示与i位置元素组成伴侣的元素下标。初始全部设置为-1.
循环遍历为每个元素匹配伴侣，定义visited[]在搜寻过程中进行重复探寻去重，当前搜索循环元素的小标为i, 那么i其实可以与剩余其它的元素尝试进行匹配，匹配逻辑如下：
判断ans[i] + ans[j] 是否为素数，不是素数尝试下一个。
判断visisted[j] ，是否重复访问，重复访问直接跳过。
判断match[j]是否为-1
为-1的话说明该元素尚未进行匹配，可以直接让j与当前元素进行匹配match[j] = index
否则递归尝试让match[j]位置的元素尝试与其它进行匹配。如果match[j]能够找到其它元素进行进行匹配的话，那么让match[j] = index。 这个也是匈牙利算法的核心思想， 寻找增广路径
最后统计match[]数组非-1的元素个数 count， 结果为count / 2。*/
public class DBFSSushuPartner {
    static boolean[] isSuShu;
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n = sc.nextInt();
        sc.nextLine();
        int[] array = Arrays.stream(sc.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        // 素数是指大于 1 的自然数中，除了 1 和它本身外，无法被其他自然数整除的数。
        isSuShu=new boolean[60001];
        Arrays.fill(isSuShu,true);
        isSuShu[0]=false;
        isSuShu[1]=false;
        for (int i = 2; i <60001 ; i++) {
            for (int j = 2; j < i; j++) {
                if(i%j==0){
                    isSuShu[i]=false;
                    break;
                }
            }
        }
        int match[]=new int[n];
        Arrays.fill(match,-1);
        int res=0;
        for (int i = 0; i < n; i++) {
            boolean[] visited=new boolean[n];
            if(dfs(array,match,visited,i)){
                res++;
            }
        }
        System.out.println(res/2);
    }

    /*把所有数看作图中的节点。
构建一个无向图，如果两个数 array[i] + array[j] 是素数，则在节点 i 和 j 之间建立一条边。
最终目标是：在这个图中找出最多的边，使得这些边没有公共顶点 —— 即最大匹配。
注意：这不是传统意义上的左右分区的二分图，而是将整个集合视为一个图，进行一般图上的最大匹配。*/
    private static boolean dfs(int[] array, int[] match, boolean[] visited, int index) {
        for (int i = 0; i < array.length; i++) {
            if(i==index||visited[i]){
                continue;
            }
            int value = array[index] + array[i];
            if(isSuShu[value]){
                visited[i]=true;
                // 该元素未进行匹配 或者 与该元素匹配的元素能找到替代品
                if(match[i]==-1||dfs(array,match,visited,match[i])){
                    match[i]=index;
                    return true;
                }
            }

        }
        return false;
    }

    // 素数筛
    static boolean[] sieve(int n) {
        boolean[] isPrime = new boolean[n + 1];
        Arrays.fill(isPrime, true);
        isPrime[0] = isPrime[1] = false;
        for (int i = 2; i * i <= n; i++) {
            // 如果 isPrime[i] 为 false，说明 i 已经是某个更小素数的倍数，因此不是素数，无需再处理它的倍数。
            // 以 i = 4 为例，如果前面已经通过 i = 2 把 4 标记为非素数，则 isPrime[4] == false，无需再次处理 4 的倍数（如 8、12 等）
            // ，因为它们已经被更小的素数（如 2）筛过了
            if (isPrime[i]) {
                // 所有比 i * i 小的 i 的倍数（如 i*2, i*3, ..., i*(i-1)）已经被更小的素数筛过了。
                for (int j = i * i; j <= n; j += i) {
                    isPrime[j] = false;
                }
            }
        }
        return isPrime;
    }

}
