import java.util.Arrays;
import java.util.List;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/28 22:38
 */
import java.util.*;
/*
* 游戏里面，队伍通过匹配实力相近的对手进行对战。但是如果匹配的队伍实力相差太大，对于双方游戏体验都不会太好。

给定n个队伍的实力值，对其进行两两实力匹配，两支队伍实例差距在允许的最大差距d内，则可以匹配。
要求在匹配队伍最多的情况下匹配出的各组实力差距的总和最小。

输入描述
第一行，n，d。队伍个数n。允许的最大实力差距d。

2<=n <=50
0<=d<=100
第二行，n个队伍的实力值空格分割。

0<=各队伍实力值<=100
输出描述
匹配后，各组对战的实力差值的总和。若没有队伍可以匹配，则输出-1。

示例1
输入

6 30
81 87 47 59 81 18
Copy
输出

57
Copy
说明

18与47配对，实力差距29
59与81配对，实力差距22
81与87配对，实力差距6
总实力差距29+22+6=57

示例2
输入

6 20
81 87 47 59 81 18
Copy
输出

12
Copy
说明

最多能匹配成功4支队伍。
47与59配对，实力差距12，
81与81配对，实力差距0。
总实力差距12+0=12

示例3
输入

4 10
40 51 62 73
Copy
输出

-1
Copy
说明

实力差距都在10以上，
没有队伍可以匹配成功。*/
public class SimBestOpposite {
    // 通用 split 函数
    public static List<String> split(String str, String delimiter) {
        return Arrays.asList(str.split(delimiter));
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt(), d = scanner.nextInt();
        scanner.nextLine(); // 处理换行符

        String s = scanner.nextLine();
        List<String> ansStr = split(s, " ");
        int[] ans = new int[n];

        for (int i = 0; i < n; i++) {
            ans[i] = Integer.parseInt(ansStr.get(i));
        }

        // 排序
        Arrays.sort(ans);
        extracted(ans, d);

        // dp[i] 代表 i 个队伍能匹配的队伍数量
        int[] dp = new int[n + 1];
        // minSum[i] i 个队伍匹配之后差值的和
        int[] minSum = new int[n + 1];

        for (int i = 2; i <= n; i++) {
            boolean canMatch = ans[i - 1] - ans[i - 2] <= d;

            if (canMatch) {
                // 优先选择匹配数量多的，匹配数量相等的选择差异值和小的
                if (dp[i - 1] < dp[i - 2] + 1) {
                    dp[i] = dp[i - 2] + 1;
                    minSum[i] = minSum[i - 2] + ans[i - 1] - ans[i - 2];
                } else if (dp[i - 1] > dp[i - 2] + 1) {
                    dp[i] = dp[i - 1];
                    minSum[i] = minSum[i - 1];
                } else {
                    dp[i] = dp[i - 1];
                    minSum[i] = Math.min(minSum[i - 1], minSum[i - 2] + ans[i - 1] - ans[i - 2]);
                }
            } else {
                dp[i] = dp[i - 1];
                minSum[i] = minSum[i - 1];
            }
        }

        System.out.println(dp[n] == 0 ? -1 : minSum[n]);
    }

    // 方法不行
    private static void extracted(int[] ans, int d) {
        int res=0;
        boolean flag = false;
        for (int i = 0; i < ans.length-1; i++) {
            if(ans[i+1]- ans[i]<= d){
                flag=true;
                res+= ans[i+1]- ans[i];
                i++;
            }
        }
        System.out.println(flag==true?res:-1);
    }
}

