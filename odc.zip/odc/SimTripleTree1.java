package odc;

import java.util.*;

class TreeNode {
    int value;
    TreeNode leftNode, midNode, rightNode;

    TreeNode(int value) {
        this.value = value;
        this.leftNode = null;
        this.midNode = null;
        this.rightNode = null;
    }
}

public class SimTripleTree1 {
    // 记录最高层数
    static int res = 0;

    // 节点插入
    static TreeNode insert(TreeNode root, int value, int height) {
        // 到达插入的位置 插入新节点才会涉及高度变更
        if (root == null) {
            // 更新最大高度
            res = Math.max(res, height);
            return new TreeNode(value);
        }

        // 插入右节点
        if (root.value + 500 < value) {
            root.rightNode = insert(root.rightNode, value, height + 1);
        // 插入左节点
        } else if (root.value > value + 500) {
            root.leftNode = insert(root.leftNode, value, height + 1);
        // 中间节点
        } else {
            root.midNode = insert(root.midNode, value, height + 1);
        }

        return root;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] nodeValue = new int[n];

        for (int i = 0; i < n; i++) {
            nodeValue[i] = sc.nextInt();
        }

        // 特判只有1个元素的情况
        if (n == 1) {
            System.out.println(1);
            return;
        }

        TreeNode root = null;
        for (int i = 0; i < n; i++) {
            root = insert(root, nodeValue[i], 1);
        }

        System.out.println(res);
    }
}

