package odc;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/26 9:32
 */
/*
* 定义构造三叉搜索树规则如下：

每个节点都存有一个数，当插入一个新的数时，从根节点向下寻找，直到找到一个合适的空节点插入。查找的规则是：

如果数小于节点的数减去500，则将数插入节点的左子树
如果数大于节点的数加上500，则将数插入节点的右子树
否则，将数插入节点的中子树
给你一系列数，请按以上规则，按顺序将数插入树中，构建出一棵三叉搜索树，最后输出树的高度。

输入描述
第一行为一个数 N，表示有 N 个数，1 ≤ N ≤ 10000

第二行为 N 个空格分隔的整数，每个数的范围为[1,10000]

输出描述
输出树的高度（根节点的高度为1）

示例1
输入
5
5000 2000 5000 8000 1800
1
2
输出
3
————————————————

                            版权声明：本文为博主原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接和本声明。

原文链接：https://blog.csdn.net/qq_45776114/article/details/149547698*/
public class SimTripleTree {
    static int maxHeight=0;
    static class TreeNode{
        int value;

        public TreeNode(int value, int height) {
            this.value = value;
            this.height = height;
        }

        int height;
        TreeNode left;
        TreeNode mid;
        TreeNode right;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n = sc.nextInt();
        sc.nextLine();
        int[] array = Arrays.stream(sc.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        if(n==1){
            System.out.println(1);
            return ;
        }
        TreeNode root = new TreeNode(array[0],1);
        maxHeight=1;
        for (int i = 1; i < n; i++) {
            findPos(array[i],root);
        }
        System.out.println(maxHeight);
    }

    private static void findPos(int v, TreeNode root) {
        if(v<root.value-500){
            if(root.left==null){
                root.left=new TreeNode(v,root.height+1);
                maxHeight=Math.max(maxHeight,root.left.height);
            }else{
                findPos(v,root.left);
            }
        }else if(v>root.value+500){
            if(root.right==null){
                root.right=new TreeNode(v,root.height+1);
                maxHeight=Math.max(maxHeight,root.right.height);

            }else{
                findPos(v,root.right);
            }
        }else{
            if(root.mid==null){
                root.mid=new TreeNode(v,root.height+1);
                maxHeight=Math.max(maxHeight,root.mid.height);

            }else{
                findPos(v,root.mid);
            }
        }
    }
}
