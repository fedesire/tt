package odc;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/26 10:25
 */
/*
* 小王在进行游戏大闯关，有一个关卡需要输入一个密码才能通过，密码获得的条件如下：在一个密码本中，每一页都有一个由 26 个小写字母组成的若干位密码
* ，每一页的密码不同，需要从这个密码本中寻找这样一个最长的密码，从它的末尾开始依次去掉一位得到的新密码也在密码本中存在。请输出符合要求的密码，
* 如果有多个符合要求的密码，则返回字典序最大的密码。若没有符合要求的密码，则返回空字符串。

输入描述
密码本由一个字符串数组组成，不同元素之间使用空格隔开，每一个元素代表密码本每一页的密码

备注
1 ≤ 密码本的页数 ≤ 10^5

1 ≤ 每页密码的长度 ≤ 10^5

输出描述
一个字符串

用例1
输入
h he hel hell hello
1
输出
hello
1
用例2
输入
b ereddred bw bww bwwl bwwlm bwwln
1
输出
bwwln
————————————————

                            版权声明：本文为博主原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接和本声明。

原文链接：https://blog.csdn.net/qq_45776114/article/details/149641194*/
public class SimFindPassword {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] inputData = scanner.nextLine().split(" ");
        HashSet<String> set=new HashSet<>();

        for (int i = 0; i < inputData.length; i++) {
            set.add(inputData[i]);
        }
        Arrays.sort(inputData,(e1,e2)->{
            if(e1.length()==e2.length()){
                return e2.compareTo(e1);
            }
            return e2.length()-e1.length();
        });
        if(inputData[inputData.length - 1].length()!=1){
            System.out.println("");
            return ;
        }
        String res="";
        Set<String> visited=new HashSet<>();
        for (int i = 0; i < inputData.length; i++) {
            String target = inputData[i];
            if(visited.contains(target)){
                continue;
            }
            while(!target.isEmpty()){
                target = target.substring(0, target.length() - 1);
                if (visited.contains(target) || !set.contains(target)) {
                    break;
                }
                visited.add(target);
            }
            if(target.isEmpty()){
                res=inputData[i];
                break;
            }
            // 这样不行 有的案例通过不了 不能是在visited中先加入短的前缀 必须是先加入长的前缀
            // boolean find=true;
            // for (int j = 1; j <= target.length(); j++) {
            //     String temp = target.substring(0, j);
            //     if(visited.contains(temp)||!set.contains(temp)){
            //         find=false;
            //         break;
            //     }
            //     visited.add(temp);
            // }
            // if(find){
            //     res=target;
            //     break;
            // }
        }
        System.out.println(res);
    }
}
