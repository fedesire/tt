package odc;

import java.util.Arrays;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/26 14:35
 */
/*
* 小朋友出操，按学号从小到大排成一列;小明来迟了，请你给小明出个主意，让他尽快找到他应该排的位置。

算法复杂度要求不高于nLog(n);学号为整数类型，队列规模<=10000;

输入描述
1、第一行:输入已排成队列的小朋友的学号 (正整数)，以”,”隔开

​ 例如: 93,95,97,100,102,123,155
2、第二行:小明学号，如110;

输出描述
输出一个数字，代表队列位置 (从1开始)例如:
6*/
import java.util.*;

public class SortQueue {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String line = sc.nextLine();
        int xiaoMingNumber = Integer.parseInt(sc.nextLine());;

        // 将字符串分割成数组并转换为整数
        String[] numbersStr = line.split(",");
        int[] numbers = new int[numbersStr.length];
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = Integer.parseInt(numbersStr[i].trim());
        }

        // 对数组进行排序
        Arrays.sort(numbers);
        int l=0,r=numbers.length-1;
        while(l<=r){
            int mid=(l+r)/2;
            if(xiaoMingNumber==numbers[mid]){
                System.out.println(mid+1);
                return ;
            }
            if(numbers[mid]>xiaoMingNumber){
                r=mid-1;
            }else{
                l=mid+1;
            }
        }
        // 队列位置 (从1开始
        System.out.println(l+1);

        // 使用二分查找找到小明的位置 找到了position就会>=0 没找到position<0
        int position = Arrays.binarySearch(numbers, xiaoMingNumber);
        // binarySearch()方法的返回值为：
        // 1、如果找到关键字，则返回值为关键字在数组中的位置索引，且索引从0开始
        // 2、如果没有找到关键字，返回值为负的插入点值，所谓插入点值就是第一个比关键字大的元素在数组中的位置索引，
        // 而且这个位置索引从1开始。
        // 如果位置是负数，转换为插入位置
        if (position < 0) {
            position = -position - 1;
        }

        // 输出小明应该排的位置，位置从1开始计数
        System.out.println(position + 1);
    }
}
