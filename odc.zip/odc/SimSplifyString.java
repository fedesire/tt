package odc;

import javafx.util.Pair;

import java.util.*;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/26 11:22
 */
/*
* 给定一个输入字符串，字符串只可能由英文字母（ ‘a’ ~ ‘z’、‘A’ ~ ‘Z’ ）和左右小括号（ ‘(’、')’ ）组成。

当字符里存在小括号时，小括号是成对的，可以有一个或多个小括号对，小括号对不会嵌套，小括号对内可以包含1个或多个英文字母，也可以不包含英文字母。

当小括号对内包含多个英文字母时，这些字母之间是相互等效的关系，而且等效关系可以在不同的小括号对之间传递，即当存在 ‘a’ 和 ‘b’ 等效和存在 ‘b’ 和 ‘c’ 等效时，‘a’ 和 ‘c’ 也等效，另外，同一个英文字母的大写字母和小写字母也相互等效（即使它们分布在不同的括号对里）

需要对这个输入字符串做简化，输出一个新的字符串，输出字符串里只需保留输入字符串里的没有被小括号对包含的字符（按照输入字符串里的字符顺序），并将每个字符替换为在小括号对里包含的且字典序最小的等效字符。

如果简化后的字符串为空，请输出为"0"。

示例 :
输入字符串为"never(dont)give(run)up(f)()"，初始等效字符集合为(‘d’, ‘o’, ‘n’, ‘t’)、(‘r’, ‘u’, ‘n’)，
* 由于等效关系可以传递，因此最终等效字符集合为(‘d’, ‘o’, ‘n’, ‘t’, ‘r’, ‘u’)，将输入字符串里的剩余部分按字典序最小的等效字
* 符替换后得到"devedgivedp’

输入描述
input_string 输入为1行，代表输入字符串 输入字符串的长度在1~100000之间

输出描述
output_string 输出为1行，代表输出字符串

用例1
输入
()abd
1
输出
abd
1
说明
输入字符串里没有被小括号包含的子字符串为"abd"，其中每个字符没有等效字符，输出为"abd"

用例2
输入
(abd)demand(fb)()for
1
输出
happwnewwear
————————————————

                            版权声明：本文为博主原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接和本声明。

原文链接：https://blog.csdn.net/qq_45776114/article/details/149641296*/
public class SimSplifyString {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        char[] array = sc.nextLine().toCharArray();
        boolean inPair=false;
        StringBuilder res =new StringBuilder();
        List<Set<Character>> pairList=new ArrayList<>();
        Set<Character> temp=new TreeSet<>();
        for (int i = 0; i < array.length; i++) {
            if(array[i]=='('){
                inPair=true;
            }else if(array[i] == ')'){
                if(!temp.isEmpty()){
                    pairList.add(temp);
                }
                inPair=false;
                temp=new TreeSet<>();
            }else if(inPair){
                temp.add(array[i]);
            }else{
                res.append(array[i]);
            }
        }
        if(!temp.isEmpty()){
            pairList.add(temp);
        }
        boolean merge=true;

        while(merge){
            merge=false;
            for (int i = pairList.size()-1; i>=0; i--) {
                for (int j = i-1; j>=0; j--) {
                    if(containsEqual(pairList.get(i),pairList.get(j))){
                        pairList.get(j).addAll(pairList.get(i));
                        pairList.remove(i);
                        merge=true;
                        break;
                    }
                }
            }
        }
        HashMap<Character, Character> map=new HashMap<>();
        for (int i = 0; i < pairList.size(); i++) {
            Set<Character> current = pairList.get(i);
            Character min = current.stream().findFirst().orElse(null);
            current.forEach(e->map.put(e,min));
        }
        StringBuilder result=new StringBuilder();
        for (int i = 0; i < res.length(); i++) {
            result.append(map.getOrDefault(res.charAt(i),res.charAt(i)));
        }
        System.out.println(result);


    }

    private static boolean containsEqual(Set<Character> set1, Set<Character> set2) {
        for (Character c : set1) {
            if(set2.contains(c)||set2.contains(Character.toLowerCase(c))){
                return true;
            }
        }
        return false;
    }
}
