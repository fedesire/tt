package odc;

import java.util.*;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/26 16:31
 */
/*
* 寿司店周年庆，正在举办[优惠活动]回馈新老客户。
寿司转盘上总共有 n 盘寿司，prices[i] 是第 i 盘寿司的价格，
如果客户选择了第 i 盘寿司，寿司店免费赠送客户距离第 i 盘寿司最近的下一盘寿司 j，前提是 prices[j] < prices[i]，如果没有满足条件的 j，则不赠送寿司。
每个价格的寿司都可无限供应。

输入描述
输入的每一个数字代表每盘寿司的价格，每盘寿司的价格之间使用空格分隔，例如:

3 15 6 14

表示：

第 0 盘寿司价格 prices[0] 为 3
第 1 盘寿司价格 prices[1] 为 15
第 2 盘寿司价格 prices[2] 为 6
第 3 盘寿司价格 prices[3] 为 14
寿司的盘数 n 范围为：1 ≤ n ≤ 500
每盘寿司的价格 price 范围为：1 ≤ price ≤ 1000

输出描述
输出享受优惠后的一组数据，每个值表示客户选择第 i 盘寿司时实际得到的寿司的总价格。使用空格进行分隔，例如：

3 21 9 17

示例1
————————————————

                            版权声明：本文为博主原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接和本声明。

原文链接：https://blog.csdn.net/qq_45776114/article/details/145970994*/
public class DSSushi {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] array = Arrays.stream(scanner.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        int n=array.length;
        int[] newArr=new int[n*2-1];
        System.arraycopy(array,0,newArr,0,n);
        System.arraycopy(array,0,newArr,n,n-1);
        LinkedList<Integer> stack=new LinkedList<>();
        int[] nextValList=new int[array.length];
        // 单调递增栈 求下一个最近的更小值
        for (int i = 0; i < newArr.length; i++) {
            // 栈顶比当前array[i]大的出栈
            while(!stack.isEmpty()&&newArr[stack.peek()]>newArr[i]){
                Integer index = stack.pop();
                nextValList[index]=newArr[i];
            }
            if(i<n){
                stack.push(i);
            }
        }
        StringJoiner joiner=new StringJoiner(" ");
        for (int i = 0; i < n; i++) {
            joiner.add(String.valueOf(nextValList[i]+array[i]));
        }
        System.out.println(joiner);
    }

    // 本题的单调栈是栈底到栈顶是递增的 单调栈保存的是数组元素下标 如果直接保存数组元素值 出栈的时候就不知道这个元素是哪个位置的 就无法向res[]
    // 保存结果 递增的单调栈 用来解决寻找循环数组中每个元素的下一个更小值元素
    public static void getResult() {
        Scanner scanner=new Scanner(System.in);
        int[] prices = Arrays.stream(scanner.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        int n=prices.length;
        int[] res = Arrays.copyOf(prices, n);

        LinkedList<Integer> linkedList=new LinkedList<>();
        // 遍历每个寿司盘的价格，由于寿司盘是循环的，需要遍历两倍长度减一次
        for (int i = 0; i <2*n-1 ; i++) {
            // 新来的元素价格小于栈顶元素价格 说明栈顶元素找到它的最近的下一个小的值
            while(!linkedList.isEmpty()&&prices[i%n]<prices[linkedList.peek()]){
                res[linkedList.pop()]+=prices[i%n];
            }
            // 必须有这个 否则就会多加一次
            if(i<n)
                linkedList.push(i);
        }
//        Arrays.stream(res).forEach(i-> System.out.print(i+" "));
        StringJoiner sj = new StringJoiner(" ");
        for (int num : res) {
            sj.add(num + "");
        }
        System.out.println(sj);

    }
}
