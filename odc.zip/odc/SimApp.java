package odc;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/26 13:55
 */
/*
* 智能手机方便了我们生活的同时，也侵占了我们不少的时间。“手机App防沉迷系统”能够让我们每天合理地规划手机App使用时间，在正确的时间做正确的事。

它的大概原理是这样的：

在一天24小时内，可以注册每个App的允许使用时段
一个时间段只能使用一个App
App有优先级，数值越高，优先级越高。注册使用时段时，如果高优先级的App时间和低优先级的时段有冲突，则系统会自动注销低优先级的时段，如果App的优先级相同，则后添加的App不能注册。
请编程实现，根据输入数据注册App，并根据输入的时间点，返回时间点使用的App名称，如果该时间点没有注册任何App，请返回[字符串]“NA”。

输入描述
第一行表示注册的App数量 N（N ≤ 100）
第二部分包括 N 行，每行表示一条App注册数据
最后一行输入一个时间点，程序即返回该时间点使用的App

2
App1 1 09:00 10:00
App2 2 11:00 11:30
09:30
1
2
3
4
数据说明如下：

N行注册数据以空格分隔，四项数依次表示：App名称、优先级、起始时间、结束时间
优先级1~5，数字越大，优先级越高
时间格式 HH:MM，小时和分钟都是两位，不足两位前面补0
起始时间需小于结束时间，否则注册不上
注册信息中的时间段包含起始时间点，不包含结束时间点
输出描述
输出一个字符串，表示App名称，或NA表示空闲时间

示例1
输入
1
App1 1 09:00 10:00
09:30
1
2
3
输出
App1
1
说明
App1注册在9点到10点间，9点半可用的应用名是App1

示例2
输入
2
App1 1 09:00 10:00
App2 2 09:10 09:30
09:20
1
2
3
4
输出
App2
1
说明
APP1和App2的时段有冲突，App2优先级高，注册App2之后，App1自动注销，因此输出App2。

示例3
输入
2
App1 1 09:00 10:00
App2 2 09:10 09:30
09:50
1
2
3
4
输出
NA
1
题解
思路：模拟

将所有app限制的起始时间和终止时间转换为 int类型，方便进行比较。
创建registeredApps数组用于存储当前情况下能够有效注册的app。
遍历每个app注册请求，查询已认定有效注册app数组中是否存在与当前app注册请求时间范围有冲突并且优先级比自己低的， 有则在有效注册数组移除那个app注册记录，将自己加入有效注册数组中。
根据输入的时间，在有效注册app记录数组中寻找对应的APP。
————————————————

                            版权声明：本文为博主原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接和本声明。

原文链接：https://blog.csdn.net/qq_45776114/article/details/149182801*/
// 定义App类，用于存储App的相关信息
class App {
    String name; // App名称
    int priority; // App优先级
    int startTime; // App允许使用的起始时间（以分钟为单位）
    int endTime; // App允许使用的结束时间（以分钟为单位）

    // App类的构造函数，用于创建App对象
    public App(String name, int priority, int startTime, int endTime) {
        this.name = name;
        this.priority = priority;
        this.startTime = startTime;
        this.endTime = endTime;
    }
}

public class SimApp {
    // 时间转换函数，将时间字符串转换为以分钟为单位的整数
    public static int convertTime(String time) {
        String[] parts = time.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);
        return hours * 60 + minutes;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt(); // 读取App数量
        List<App> apps = new ArrayList<>(); // 创建App列表，用于存储所有App

        for (int i = 0; i < n; i++) {
            // 循环读取每个App的信息，并创建App对象添加到列表中
            String appName = scanner.next();
            int appPriority = scanner.nextInt();
            String startTimeStr = scanner.next();
            String endTimeStr = scanner.next();
            int appStartTime = convertTime(startTimeStr);
            int appEndTime = convertTime(endTimeStr);
            apps.add(new App(appName, appPriority, appStartTime, appEndTime));
        }

        String queryTimeStr = scanner.next();
        int queryTime = convertTime(queryTimeStr); // 读取查询时间，并转换为分钟
        String appAtTime = "NA"; // 初始化查询时间对应的App名称为"NA"

        List<App> registeredApps = new ArrayList<>(); // 创建已注册App列表
        for (App app : apps) {
            boolean canInsert = true;
            List<Integer> needDeletePosition = new ArrayList<>();
            if (app.startTime >= app.endTime) continue; // 如果起始时间不小于结束时间，则跳过

            // 遍历已注册的App列表，检查时间冲突
            for (int i = registeredApps.size() - 1; i >= 0; i--) {
                App registered = registeredApps.get(i);
                if (Math.max(app.startTime, registered.startTime) < Math.min(app.endTime, registered.endTime)) {
                    if (app.priority > registered.priority) {
                        needDeletePosition.add(i); // 记录需要移除的位置
                        // 不能在这里就删 因为必须要等全部判断完后canInsert=true 才代表这条要插入 needDeletePosition里的位置处的元素
                        // 才是真的要删除的 否则如果Insert=false 那needDeletePosition里的位置处的元素实际上是不用删的
                        // registeredApps.remove(i);
                    } else {
                        canInsert = false; // 当前App优先级不够高，无法插入
                        break;
                    }
                }
            }

            if (canInsert) {
                registeredApps.add(app); // 插入当前App
                for (int i = 0; i <= needDeletePosition.size() - 1; i++) {
                    registeredApps.remove((int) needDeletePosition.get(i)); // 移除冲突的App
                }
            }
        }

        // 遍历已注册App列表，找到查询时间对应的App
        for (App app : registeredApps) {
            if (queryTime >= app.startTime && queryTime < app.endTime) {
                appAtTime = app.name; // 更新查询时间对应的App名称
                break; // 找到后退出循环
            }
        }

        System.out.println(appAtTime); // 输出查询时间对应的App名称
    }
}
