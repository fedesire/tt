package odc;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/26 9:52
 */
/*
* 给定一个字符串的摘要算法，请输出给定字符串的摘要值.

去除字符串中非字母的符号。
如果出现连续字符(不区分大小写) ，则输出：该字符 (小写) + 连续出现的次数。
如果是非连续的字符(不区分大小写)，则输出：该字符(小写) + 该字母之后字符串中出现的该字符的次数
对按照以上方式表示后的字符串进行排序：字母和紧随的数字作为一组进行排序，数字大的在前，数字相同的，则按字母进行排序，字母小的在前。
输入描述
一行字符串，长度为[1,200]

输出描述
摘要字符串

用例1
输入
aabbcc
1
输出
a2b2c2
1
说明
无

用例2
输入
bAaAcBb
1
输出
a3b2b2c0
1
说明
bAaAcBb:第一个b非连续字母，该字母之后字符串中还出现了2次(最后的两个Bb) ，所以输出b2,a连续出现3次，输出a3，c非连续，该字母之后字符串再没有出现过c，输出c0,Bb连续2次，输出b2对b2a3c0b2进行排序，最终输出a3b2b2c0。

题解
思路：模拟

字符串中字符去除非字母字符，字母字符全部转换为小写。
使用哈希表统计各个字符出现的数量，用于出现不连续字符的情况下使用。
进行遍历，当 s[i] != s[i-1]作为条件，计算出s[i-1]字符出现的连续个数 size，size =1为 count[s[i-1]] -1, 否则为size 。将{s[i-1], count[s[i-1]] -1}或{s[i-1], size}插入结果数组中
自定义排序， 然后按照顺序输出结果。
*/
public class SimStringSummary {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String s = scanner.nextLine();
        s= s.replaceAll("[^A-Za-z]", "");
        s=s.toLowerCase();
        char[] array = s.toCharArray();
        HashMap<Character, Integer> map = new HashMap<>();
        for (int i = 0; i < array.length; i++) {
            map.put(array[i],map.getOrDefault(array[i],0)+1);
        }
        List<Map.Entry<Character, Integer>> list=new ArrayList<>();
        StringBuilder temp = new StringBuilder();
        for (int i = 0; i < array.length; i++) {
            if(i==0||array[i]==array[i-1]){
                temp.append(array[i]);
            }else{
                if(temp.length()>1){
                    list.add(new AbstractMap.SimpleEntry<>(array[i - 1], temp.length()));
                }else{
                    list.add(new AbstractMap.SimpleEntry<>(array[i - 1], map.get(array[i-1])));
                }
                temp.setLength(0);
                temp.append(array[i]);
            }
            map.put(array[i], map.get(array[i])-1);
        }
        if(temp.length()>1){
            list.add(new AbstractMap.SimpleEntry<>(temp.charAt(0), temp.length()));
        }else{
            list.add(new AbstractMap.SimpleEntry<>(temp.charAt(0), map.get(temp.charAt(0))));
        }
        Collections.sort(list,(e1,e2)->{
            if(e1.getValue().equals(e2.getValue())){
                return e1.getKey().compareTo(e2.getKey());
            }
            return e2.getValue()-e1.getValue();
        });
        String res = list.stream().map(e -> e.getKey() + "" + e.getValue()).collect(Collectors.joining());
        System.out.println(res);
    }
}
