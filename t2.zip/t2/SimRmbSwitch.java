import java.util.Arrays;
import java.util.Scanner;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/6/14 10:56
 */
/*
* 、中文大写金额数字前应标明“人民币”字样。中文大写金额数字应用壹、贰、叁、肆、伍、陆、柒、捌、玖、拾、佰、仟、万、亿、元、角、分、零、
* 整等字样填写。
2、中文大写金额数字到“元”为止的，在“元”之后，应写“整字，如532.00应写成“人民币伍佰叁拾贰元整”。在”角“和”分“后面不写”整字。
3、阿拉伯数字中间有“0”时，中文大写要写“零”字，阿拉伯数字中间连续有几个“0”时，中文大写金额中间只写一个“零”字，如6007.14，
* 应写成“人民币陆仟零柒元壹角肆分“。
4、10应写作“拾”，100应写作“壹佰”。例如，1010.00应写作“人民币壹仟零拾元整”，110.00应写作“人民币壹佰拾元整”
5、十万以上的数字接千不用加“零”，例如，30105000.00应写作“人民币叁仟零拾万伍仟元整”
输入描述
输入一个double数，范围[0, 1000000000000]
输出描述
输出人民币格式
示例一
输入
151121.15
输出
人民币拾伍万壹仟壹佰贰拾壹元壹角伍分
示例二
输入
1010.00
输出
人民币壹仟零拾元整
*
* 思路：模拟

定义中文和数字之间的映射，根据规则定义单位表。
将输入的double数字切割分开处理整数和小数部分。小数部分处理比较简单，重点说说整数部分。
整数部分以四位一组进行处理，重点注意以下几部分
10 转换为拾元而不是壹拾元， 100000 转换为拾万而不是壹拾万，其它的累次类推。这是一个特殊情况。
当一组的四位全是0时，不需要输出单位。
多个连续0出现时只需要输出一个零
当不存在小数时，整数部分需要输出整，当然这部分可以递推小数部分进行处理。
额外考虑零元整的情况。
*/
import java.util.Scanner;

public class SimRmbSwitch {
    static final String[] digitMap = {"零", "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖"};
    static final String[] unitMap = {
            "", "拾", "佰", "仟", "万", "拾", "佰", "仟",
            "亿", "拾", "佰", "仟", "万", "拾", "佰", "仟", "万"
    };

    // 处理整数部分 不对 不满足30105000.00应写作“人民币叁仟零拾万伍仟元整”
    static void readIntegerPart(String integer) {
        if (integer.equals("0")) return;

        int len = integer.length();

        if (!((len - 1) % 4 == 1 && integer.charAt(0) == '1')) {
            System.out.print(digitMap[integer.charAt(0) - '0']);
        }
        System.out.print(unitMap[len - 1]);

        for (int i = 1; i < len; i++) {
            int digit = integer.charAt(i) - '0';
            int unitPos = len - 1 - i;

            if (unitPos % 4 == 0 && digit == 0) {
                if (i >= 4 && unitPos == 4 &&
                        integer.charAt(i - 1) == '0' &&
                        integer.charAt(i - 2) == '0' &&
                        integer.charAt(i - 3) == '0') {
                    continue;
                }
                System.out.print(unitMap[unitPos]);
                continue;
            }

            // 如果当前位数字是0 就跳过 直到再遇到一个非0数字时，前面补零，再输出当前这个非零对应的数字和单位
            if (digit != 0) {
                if (integer.charAt(i - 1) == '0') {
                    System.out.print("零");
                }
                System.out.print(digitMap[digit] + unitMap[unitPos]);
            }
        }
        System.out.print("元");
    }

    // 处理小数部分
    static void readFractionPart(String fraction) {
        if (fraction.equals("00")) {
            System.out.print("整");
            return;
        }
        if (fraction.charAt(0) > '0') {
            System.out.print(digitMap[fraction.charAt(0) - '0'] + "角");
        }
        if (fraction.charAt(1) > '0') {
            System.out.print(digitMap[fraction.charAt(1) - '0'] + "分");
        }
    }

    public static void main(String[] args) {
        go();
        Scanner sc = new Scanner(System.in);
        String money = sc.nextLine();

        if (money.equals("0.00") || money.equals("0") || money.equals("0.0")) {
            System.out.print("人民币零元整");
            return;
        }

        String[] parts = money.split("\\.");
        String integerPart = parts[0];
        String fractionPart = parts[1];

        System.out.print("人民币");
        readIntegerPart(integerPart);
        readFractionPart(fractionPart);
    }

    public static final char[] chNumSet = "零壹贰叁肆伍陆柒捌玖".toCharArray();
    public static final char[] chPowSet = "分角元拾佰仟万拾佰仟亿拾佰仟万".toCharArray();
    private static void go() {
        // 读入一个数值
        Scanner console = new Scanner(System.in);
        while (console.hasNext()) {
            double d = console.nextDouble();
            // 解析该数值为汉字形式
            long l = (long) (d * 100);
            String strRes = parse(l);
            System.out.println("人民币" + strRes);
        }
    }

    private static String parse(long n) {
        if (n == 0) {
            return "零元整";
        }

        StringBuilder sb = new StringBuilder();
        // 将数值解析为单个数值的数组
        int[] nums = toNum(n);
        for (int i = nums.length - 1; i >= 0; i--) {
            sb.append(chNumSet[nums[i]]);
            sb.append(chPowSet[i]);
        }

        String res = sb.toString().replaceAll("零[分角拾佰仟]", "零")
                .replaceAll("零+", "零")
                .replaceAll("零+元", "元")
                .replaceAll("零+万", "万")
                .replaceAll("零+亿", "亿")
                .replaceAll("亿万", "亿");
        if (res.startsWith("壹拾")) {
            res = res.substring(1);
        }

        if (res.endsWith("零")) {
            res = res.substring(0, res.length() - 1);
        }

        if (res.endsWith("元")) {
            res = res + "整";
        }
        return res;
    }

    private static int[] toNum(long n) {
        int[] res = new int[0];
        while (n != 0) {
            int end = (int) (n % 10L);
            // 扩展数组的长度
            res = Arrays.copyOf(res, res.length + 1);
            res[res.length - 1] = end;
            n /= 10L;
        }
        return res;
    }
}


