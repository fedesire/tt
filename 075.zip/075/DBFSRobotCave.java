import java.util.Arrays;
import java.util.Scanner;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/5 10:22
 */
/*
* 房间由XY的方格组成，例如下图为6*4的大小。每一个方格以坐标(x，y)描述。
机器人固定从方格(0，0)出发，只能向东或者向北前进。出口固定为房间的最东北角，如下图的方格(5，3)。用例保证机器人可以从入口走到出口。
房间有些方格是墙壁，如(4，1)，机器人不能经过那儿。
有些地方是一旦到达就无法走到出口的，如标记为B的方格，称之为陷阱方格。
有些地方是机器人无法到达的的，如标记为A的方格，称之为不可达方格，不可达方格不包括墙壁所在的位置。
如下示例图中，陷阱方格有2个，不可达方格有3个。
请为该机器人实现路径规划功能：给定房间大小、墙壁位置，请计算出陷阱方格与不可达方格分别有多少个。


输入描述
第一行为房间的X和Y（0 < X,Y <= 1000）
第二行为房间中墙壁的个数N（0 <= N < X*Y）
接着下面会有N行墙壁的坐标
同一行中如果有多个数据以一个空格隔开，用例保证所有的输入数据均合法。（结尾不带回车换行）

输出描述
陷阱方格与不可达方格数量，两个信息在一行中输出，以一个空格隔开。（结尾不带回车换行）

用例1
输入
6 4
5
0 2
1 2
2 2
4 1
5 1

输出
2 3

说明
该输入对应上图示例中的迷宫，陷阱方格有2个，不可达方格有3个
*/
public class DBFSRobotCave {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        int y = sc.nextInt();
        int n = sc.nextInt();
        int[][] grid = new int[x][y];
        sc.nextLine();
        for (int i = 0; i < n; i++) {
            int[] array = Arrays.stream(sc.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
            grid[array[0]][array[1]]=-1;
        }
        if (grid[x - 1][y - 1] != -1) {
            grid[x - 1][y - 1] = 1; // 终点标记为1
        }
        dfs(0,0,x,y,grid);
        int trapCount=0;
        int unavailableCount=0;
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                if(grid[i][j]==2){
                    trapCount++;
                }else if(grid[i][j]==0){
                    unavailableCount++;
                }
            }
        }
        System.out.print(trapCount+" "+unavailableCount);
    }

    private static boolean dfs(int i, int j,int rows,int cols, int[][] grid) {
        // 只有这个 没有上面初始时先设终点标记为1 这样不行 因为这样dfs结束后终点标记还是0
        // if(i==rows-1&&j==cols-1){
        //     return true;
        // }
        if(i<0||i>=rows||j<0||j>=cols||grid[i][j]==-1||grid[i][j]==2){
            return false;
        }
        if(grid[i][j] == 1){
            return true;
        }
        boolean northFlag=dfs(i+1,j,rows,cols, grid);
        boolean eastFlag=dfs(i,j+1,rows,cols, grid);
        // 可达标记为1
        if(northFlag || eastFlag){
            grid[i][j] = 1;
        }else{
            // 说明可以经过此格子但无法到达终点，标记为2
            grid[i][j] = 2;
        }
        return northFlag || eastFlag;
    }
}
