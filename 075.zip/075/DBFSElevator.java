import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/5 14:33
 */
/*
* 有一座保密大楼，你从0楼到达指定楼层m，必须这样的规则乘坐电梯：

给定一个数字序列，每次根据序列中的数字n，上升n层或者下降n层，前后两次的方向必须相反，规定首次的方向向上，
* 自行组织序列的顺序按规定操作到达指定楼层。

求解到达楼层的序列组合，如果不能到达楼层，给出小于该楼层的最近序列组合。

输入描述
第一行：期望的楼层，取值范围[1,50]; 序列总个数，取值范围[1,23]

第二行：序列，每个值取值范围[1,50]

输出描述
能够达到楼层或者小于该楼层最近的序列

备注
操作电梯时不限定楼层范围。
必须对序列中的每个项进行操作，不能只使用一部分。
用例1
输入
5 3
1 2 6
1
2
输出
6 2 1
1
说明
1 2 6，6 2 1均为可行解，按先处理大值的原则结果为6 2 1

题解
思路：递归回溯

首先确定需要选取上升的数量,规定第一个为上升并且交叉上升和下降，那么选取上升的数量为(n + 1) /2,向上取整。
将输入数组降序排序。
使用递归回溯枚举所有选取exceptCount上升数，记录其中出现上升高度 <= m, 并且最接近m的方案。
将每个候选方案对应的数组构建出来，选取其中字典序最大的数组就是结果。

*
*
* 因为必须对序列中的每个项进行操作，不能只使用一部分。所以这道题看似是一个全排列问题 对全排列后的每一个选项 构造成上升下降交替
* 的候选 选出离目标层最近的候选即可 但是使用全排列算法就无法提前剪枝（只能把每一种path都加入结果集 最后再筛选出离目标层最近的候选）
*  所以这里将问题看成一个组合问题 变成从n个数中选(n+1)/2个数作为上升数 其余就是下降数 dfs里可以剪枝 最终会超过m层的*/
import java.util.*;

public class DBFSElevator {
    static int totalSum;
    static List<Integer> res = new ArrayList<>();
    static int minDiff;
    static int m, n;

    // 比较函数，从大到小排序
    static boolean cmp(int x, int y) {
        return x > y;
    }

    // 递归回溯枚举 选取exceptCount的数
    // ans 当前排序后的输入数组（降序排列）
    // index 当前处理到数组中的哪个位置（索引），防止重复选取元素
    // currentSum 当前已选择的上升数字总和
    // count 当前已经选择了多少个上升项
    // exceptCount 预期要选择的上升项数量（即 (n + 1) / 2）
    // visited 使用位掩码（bitmask）记录哪些元素已被选为上升项
    static void DFS(List<Integer> ans, int index, int currentSum, int count, int exceptCount, int visited) {
        if (count > exceptCount) {
            return;
        }
        if (exceptCount == count) {
            // 净增楼层 currentSum 当前已选择的上升数字总和 totalSum - currentSum就是剩余的下降数字总和
            int diff = currentSum - (totalSum - currentSum);
            // 上升超过m的不考虑
            if (diff > m) {
                return;
            }
            // 找最小差距
            diff = Math.abs(diff - m);
            if (diff < minDiff) {
                res.clear();
                minDiff = diff;
                res.add(visited);
            } else if (diff == minDiff) {
                res.add(visited);
            }
            return;
        }

        for (int i = index; i < n; i++) {
            int num = ans.get(i);
            int nextCurrentSum = currentSum + num;
            // 剪枝 最终会超过m层
            if (nextCurrentSum - (totalSum - nextCurrentSum) > m) {
                continue;
            }
            // 递归回溯 将当前ans.get(i)元素标记为“已选中”作为上升项 在visited中是将从右往左数第n-1-i位置为1
            visited |= 1 << (n - i - 1);
            DFS(ans, i + 1, nextCurrentSum, count + 1, exceptCount, visited);
            // ~(1 << (n - i - 1))：取反，得到一个除了指定位置为 0 其余都为 1 的掩码。
            // &=：按位与赋值。把对应的那一位清 0，表示取消选择。
            visited &= ~(1 << (n - i - 1));
        }
    }

    // 交叉构建结果集
    static List<Integer> buildArr(List<Integer> ans, int num) {
        boolean[] visited = new boolean[n];
        // ans.get(i)元素是否被选为上升元素 取决于num从右往左数第n-1-i位置是否为1 把所有的n-1-i都改成i也行
        for (int i = 0; i < n; i++) {
            visited[i] = (1 & (num >> (n - 1 - i))) == 1;
        }
        List<Integer> s = new ArrayList<>(Collections.nCopies(n, 0));
        int pos = 0;
        for (int i = 0; i < n; i++) {
            if (visited[i]) {
                s.set(pos, ans.get(i));
                pos += 2;
            }
        }
        pos = 1;
        for (int i = 0; i < n; i++) {
            if (!visited[i]) {
                s.set(pos, ans.get(i));
                pos += 2;
            }
        }
        return s;
    }

    // 在所有mask生成的数组中，找出字典序最大的
    static List<Integer> findBestArray(List<Integer> ans) {
        List<Integer> best = new ArrayList<>();
        for (int mask : res) {
            List<Integer> curr = buildArr(ans, mask);
            if (best.isEmpty() || compare(curr, best) > 0) {
                best = curr;
            }
        }
        return best;
    }

    // 手动比较两个列表的字典序
    static int compare(List<Integer> a, List<Integer> b) {
        for (int i = 0; i < a.size(); i++) {
            if (!a.get(i).equals(b.get(i))) {
                return a.get(i) - b.get(i);
            }
        }
        return 0;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        m = sc.nextInt();
        n = sc.nextInt();
        List<Integer> inputData = new ArrayList<>();
        totalSum = 0;
        for (int i = 0; i < n; i++) {
            int x = sc.nextInt();
            inputData.add(x);
            totalSum += x;
        }
        // minDiff初始时要设成一个大数 设为Interger.max也行
        minDiff = totalSum + m;
        // 从大到小排序
        inputData.sort((a, b) -> b - a);

        int exceptUpCount = (n + 1) / 2;
        int status = 0;
        // inputData中找(n + 1) / 2个数（作为上升的数 其余的数自动作为下降的数）
        // 看每种组合是否符合条件加入结果集 所以转变成一个组合问题
        DFS(inputData, 0, 0, 0, exceptUpCount, status);

        List<Integer> answer = findBestArray(inputData);
        for (int i = 0; i < answer.size(); i++) {
            System.out.print(answer.get(i));
            if (i != answer.size() - 1) {
                System.out.print(" ");
            }
        }
    }
}

