import java.util.Arrays;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/5 15:34
 */
/*
* 小明在学习二进制时，发现了一类不含101的数：
将数字用二进制表示，不能出现 101 。
现在给定一个整数区间 [l,r] ，请问这个区间包含了多少个不含 101 的数？
输入描述
输入的唯一一行包含两个正整数 l， r（ 1 ≤ l ≤ r ≤ 10^9）。
输出描述
输出的唯一一行包含一个整数，表示在 [l,r] 区间内一共有几个不含 101 的数。
用例1
输入
1 10
1
输出
8
1
说明
区间 [1,10] 内， 5 的二进制表示为 101 ，10的二进制表示为 1010 ，因此区间 [ 1 , 10 ] 内有 10−2=8 个不含 101的数。
用例2
输入
10 20
1
输出
7
1
说明
区间 [10,20] 内，满足条件的数字有 [12,14,15,16,17,18,19] 因此答案为 7。
题解
思路：数位DP + 记忆化搜索
本题乍看是很简单的题目，直接进制转换，暴力法不就得了。但是你注意看范围是【1 ≤ l ≤ r ≤ 10^9】，暴力肯定会超时。这题使用的是数位DP
数位dp总结 之 从入门到模板_wust_wenhao的博客-CSDN博客
具体思路是从高位到低位逐位枚举，对于每一位，枚举它的取值，并根据前一位和前两位的值来判断是否符合条件。同时，使用记忆化数组来避免重复计算。
具体实现中，可以将数字转换为二进制数，然后递归处理每一位。递归函数中，p表示当前处理到的二进制位，limit表示当前位是否受到上限制，f表示记忆化数组，
* arr表示二进制数，pre表示前一位的值，prepre表示前两位的值。递归结束条件是处理完所有二进制位，此时返回1。在递归过程中，统计符合条件的数的个数，并使用记忆化数组避免重复计算。*/
import java.util.Scanner;
import java.util.Arrays;

import java.util.*;

public class DPNo101 {

    /*
    *    0       1
    *  0   1   0   1
    * 0 1 0 1 0 1 0 1*/
    public static int dp(int num) {
        // 将数字转换为二进制数组
        List<Integer> binaryNums = new ArrayList<>();
        while (num > 0) {
            binaryNums.add(num % 2);  // 将最低位加入列表
            num /= 2;                 // 去掉最低位
        }
        Collections.reverse(binaryNums); // 反转数组，使二进制位从高位到低位排列

        // 初始化记忆化数组 binaryDp，用于存储已计算过的状态结果，避免重复计算
        // binaryDp 数组是整个算法性能优化的核心，它使得原本指数级复杂度的问题降到多项式级别。
        // 第一维 [p]当前处理到的二进制位下标i（从高位到低位）后面两维都是为了用来表示上面搜索树中每一个点的状态 状态和前面两位相关
        int[][][] binaryDp = new int[binaryNums.size()][2][2];
        for (int[][] layer : binaryDp) {
            for (int[] row : layer) {
                // 设为-1是为了表示初始没计算过的结果
                Arrays.fill(row,-1);

            }
        }

        // 调用递归搜索函数开始计算
        return search(0, true, binaryDp, binaryNums, 0, 0);
    }

    // flag == true：表示当前处理到的二进制位受到原始数字的限制，不能随意取值。
    // flag == false：表示前面已经选择了一个比原数字对应位更小的值，后续位可以自由选择（0 或 1）。
    // search用于统计从 0 到 num 的所有数字中，其二进制表示不包含连续子串 "101" 的数量。其实最终返回的是所有合法路径的数量。
    public static int search(int p, boolean flag, int[][][] binaryDp, List<Integer> binaryNums, int pre, int prepre) {
        // 边界条件：如果已经处理完所有二进制位，返回 1，表示找到一个符合条件的数
        if (p == binaryNums.size()) {
            return 1;
        }

        // 如果当前状态已经计算过且没有上界限制，直接返回保存的结果
        if (!flag && binaryDp[p][pre][prepre] != -1) {
            return binaryDp[p][pre][prepre];
        }

        // 当前位的最大值。如果受上界限制，则取 binaryNums[p]；否则为 1
        int index = flag ? binaryNums.get(p) : 1;
        int count = 0;  // 记录符合条件的数的个数

        // 枚举当前位可能的值（0 或 1）
        for (int i = 0; i <= index; i++) {
            // 如果当前位的组合形成 "101" 模式（即 prepre=1, pre=0, 当前位 i=1），则跳过该情况
            if (i == 1 && pre == 0 && prepre == 1) {
                continue;
            }
            // 递归处理下一位，更新 pre 和 prepre
            // 如果当前位是受限的 (flag == true)，并且你选择的值 i == index（即最大允许值），那么下一位仍然受限。
            count += search(p + 1, flag && i == index, binaryDp, binaryNums, i, pre);
        }

        // 如果不受上界限制，将结果保存在记忆化数组 binaryDp 中 因为不受限状态具有通用性，所以可以保存 如果是受限状态此时的值就不具参考价值不能保存
        if (!flag) {
            binaryDp[p][pre][prepre] = count;
        }

        return count;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int left = scanner.nextInt();  // 读取左边界
        int right = scanner.nextInt(); // 读取右边界
        scanner.close();

        // 计算区间 [left, right] 内不包含 "101" 模式的数的个数
        int result = dp(right) - dp(left - 1);
        System.out.println(result);
    }
}


