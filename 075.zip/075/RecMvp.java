import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/5 13:44
 */
/*
* 在星球争霸篮球赛对抗赛中，最大的宇宙战队希望每个人都能拿到MVP，MVP的条件是单场最高分得分获得者，可以并列。所以宇宙战队决定在比赛中尽可能让更多队员上场，并且让所有得分的选手得分都相同， 然而比赛过程中的每1分钟的得分都只能由某一个人包揽。
输入描述
输入第一行为一个数字 t ，表示为有得分的分钟数 1 ≤ t ≤ 50。
第二行为 t 个数字，代表每一分钟的得分 p， 1 ≤ p ≤ 50。
输出描述
输出有得分的队员都是MVP时，最少得MVP得分。
用例1
输入
9
5 2 1 5 2 1 5 2 1
1
2
输出
6
1
说明
样例解释 一共 4 人得分，分别都是 6 分 5 + 1 ， 5 + 1 ， 5 + 1 ， 2 + 2 + 2
题解
思路：递归回溯
暴力枚举允许获得MVP人数可能的情况,可能的情况为[1, t].
根据1的枚举的MVP人数 x ，判断是否可以满足 指定人数的MVP情况，不满足则将x - 1，继续进行判断，判断过程逻辑如下：
首先判断sum(score) % x == 0, 不满足直接返回false.
判断max(score) > (sum(score) / x) , 每一场分数不能进行拆分，肯定不满足所有人都拿sum(score) /x的分数。
使用递归回溯尝试不同组合方案，判断是否能组合出 x 个 分数为 sum(score) / x的方案。其中涉及部门剪枝优化，具体逻辑可参照代码注释。
执行2的逻辑，解决条件为x == 1 或者 在 [1,t]中可以找到一个合法情况。输出最终的x就是答案。*/
public class RecMvp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[] scores=new int[n];
        int sum=0;
        for (int i = 0; i < n; i++) {
            scores[i] = scanner.nextInt();
            sum+=scores[i];
        }
        scores=Arrays.stream(scores).boxed().sorted(Comparator.reverseOrder()).mapToInt(Integer::intValue).toArray();
        int peopleNum=1;
        for (int i = n; i >=1; i--) {
            if(canAverageSplit(i,scores,sum)){
                peopleNum=i;
                break;
            }
        }
        System.out.println(sum/peopleNum);
    }

    private static boolean canAverageSplit(int n, int[] scores,int totalSum) {
        if(totalSum%n!=0){
            return false;
        }

        int eachScore = totalSum / n;
        if(scores[0]>eachScore){
            return false;
        }
        int[] peopleScore=new int[n];
        return dfs(0,peopleScore,scores,eachScore);
    }

    private static boolean dfs(int index,int[] peopleScore, int[] scores, int targetEachScore) {
        if(index==scores.length){
            for (int i = 0; i < peopleScore.length; i++) {
                if(peopleScore[i] != targetEachScore){
                    return false;
                }
            }
            return true;
        }
        for (int i = 0; i < peopleScore.length; i++) {
            if(i>0&&peopleScore[i] ==peopleScore[i-1]){
                continue;
            }
            if(peopleScore[i]+scores[index]>targetEachScore){
                continue;
            }
            peopleScore[i]+=scores[index];
            if(dfs(index+1,peopleScore,scores,targetEachScore)){
                return true;
            }
            peopleScore[i]-=scores[index];
        }
        return false;
    }
}
