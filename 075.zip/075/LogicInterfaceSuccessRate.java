import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/5 9:50
 */
/*
* 服务之间交换的接口成功率作为服务调用关键质量特性，某个时间段内的接口失败率使用一个数组表示，数组中每个元素都是单位时间内失败率数值，数组中的数值为0~100的整数， 给定一个数值(minAverageLost)表示某个时间段内平均失败率容忍值，即平均失败率小于等于minAverageLost，找出数组中最长时间段，如果未找到则直接返回NULL。

输入描述
输入有两行内容，第一行{minAverageLost}，第二行为{数组}，数组元素通过空格(” “)分隔，minAverageLost及数组中元素取值范围为0~100的整数，数组元素的个数不会超过100个。

输出描述
找出平均值小于等于minAverageLost的最长时间段，输出数组下标对，格式{beginIndex}-{endIndx}(下标从0开始)，如果同时存在多个最长时间段，则输出多个下标对且下标对之间使用空格(” “)拼接，多个下标对按下标从小到大排序。

示例1
输入
1
0 1 2 3 4
1
2
输出
0-2
1
说明
输入解释：minAverageLost=1，数组[0, 1, 2, 3, 4]前3个元素的平均值为1，因此数组第一个至第三个数组下标，即0-2

示例2
输入
2
0 0 100 2 2 99 0 2
1
2
输出
0-1 3-4 6-7
1
说明
输入解释：minAverageLost=2，数组[0, 0, 100, 2, 2, 99, 0, 2]通过计算小于等于2的最长时间段为：数组下标为0-1即[0, 0]，数组下标为3-4即[2, 2]，数组下标为6-7即[0, 2]，这三个部分都满足平均值小于等于2的要求，因此输出0-1 3-4 6-7

题解
思路：前缀和 基础算法运用

预计算前缀和数组，使用前缀和数组减少求一个区间和的重复运算。
双for循环从前往后确定两个区间的起点和终点，判断这个区间的是否满足minAverageLost，并且是否为当前遍历过的最长区间？是的话加入结果候选集。
输出最终最长区间的结果的满足条件的区间起点和终点。如果不存在满足条件的区间，输出NULL。
*/
import java.util.*;

public class LogicInterfaceSuccessRate {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int minAverageLost = scanner.nextInt();
        List<Integer> ans = new ArrayList<>();

        while (scanner.hasNextInt()) {
            ans.add(scanner.nextInt());
        }
        int len = ans.size();

        if (len == 0) {
            System.out.println("NULL");
            return;
        }

        // 计算前缀和
        int[] prefix = new int[len + 1];
        for (int i = 1; i <= len; i++) {
            prefix[i] = prefix[i - 1] + ans.get(i - 1);
        }

        int currentLen = 0;
        Map<Integer, List<int[]>> mp = new HashMap<>();

        // 计算最长子区间
        for (int i = 0; i <= len; i++) {
            for (int j = i + 1; j <= len; j++) {
                if (j - i < currentLen) {
                    continue;
                }
                int sum = prefix[j] - prefix[i];
                if ((double) sum / (j - i) <= minAverageLost) {
                    currentLen = Math.max(currentLen, j - i);
                    mp.putIfAbsent(currentLen, new ArrayList<>());
                    mp.get(currentLen).add(new int[]{i, j - 1});
                }
            }
        }

        if (currentLen == 0) {
            System.out.println("NULL");
            return;
        }

        List<int[]> maxLenV = mp.get(currentLen);
        for (int i = 0; i < maxLenV.size(); i++) {
            if (i != 0) System.out.print(" ");
            System.out.print(maxLenV.get(i)[0] + "-" + maxLenV.get(i)[1]);
        }
    }
}

