import java.util.Arrays;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/5 9:57
 */
/*
* 给定两个字符串，分别为字符串A与字符串B。
例如A字符串为ABCABBA，B字符串为CBABAC可以得到下图m*n的二维数组，定义原点为(0, 0)，终点为(m, n)，水平与垂直的每一条边距离为1，映射成坐标系如下图。
从原点(0, 0)到(0, A)为水平边，距离为1，从(0, A)到(A, C)为垂直边，距离为1；
假设两个字符串同一位置的两个字符相同则可以作一个斜边，如(A, C)到(B, B)最短距离为斜边，距离同样为1。
作出所有的斜边如下图，(0, 0)到(B, B)的距离为 1个水平边 + 1个垂直边 + 1个斜边 = 3。
根据定义可知，原点到终点的最短距离路径如下图红线标记，最短距离为：9
输入描述
空格分割的两个字符串A与字符串B，字符串不为“空串”，字符格式满足正则规则:[A-Z]，字符串长度<10000
输出描述
原点到终点的最短距离
用例1
输入
ABC ABC
1
输出
3
1
用例2
输入
ABCABBA CBABAC
1
输出
9
1
题解
思路：动态规划。
定义一个二维数组dp[m][n],代表到达(m,n)位置最短距离。初始设置dp[0][0] = 1.
初始化边界条件,设置第一行和第一列的最短距离。
使用双层循环遍历A和B的每个字符更新dp数组。
如果A[i] != B[j]时,dp[i+1][j+1] = min(dp[i+1][j], dp[i][j+1]))+1
如果A[i] == B[j]时，dp[i+1][j+1] = min(dp[i+1][j] ,dp[i][j+1]), dp[i][j])+1
最后输出dp[m][n]就是结果。
上述是解决这个题目的基本逻辑。但是本题数据量可以达到10000 * 10000 = 1e8,很容易爆内存。所以必须想办法压缩内存，可以观察到状态转义方程只涉及到两行，由此定义两个一维数组进行滚动更新，压缩内存。*/
import java.util.*;

public class DPMinPath {
    public static void main(String[] args) {
        getResult1();
        Scanner sc = new Scanner(System.in);
        String A = sc.next();
        String B = sc.next();
        int m = A.length(), n = B.length();

        // 使用两个数组压缩空间
        int[] dp = new int[m + 1];
        int[] pre = new int[m + 1];

        // 初始化 pre 数组
        for (int i = 0; i <= m; i++) {
            pre[i] = i;
        }

        for (int i = 1; i <= n; i++) {
            // 重新初始化 dp 没有这一步也行 因为下面dp[j] = Math.min(pre[j], dp[j - 1]) + 1;只用到了dp[j-1]都是这一轮已经计算过的
            Arrays.fill(dp, Integer.MAX_VALUE);
            // (i, 0) 到 (0, 0) 的距离
            dp[0] = i;
            for (int j = 1; j <= m; j++) {
                dp[j] = Math.min(pre[j], dp[j - 1]) + 1;
                if (A.charAt(j - 1) == B.charAt(i - 1)) {
                    dp[j] = Math.min(dp[j], pre[j - 1] + 1);
                }
            }
            // 注意是深拷贝
            pre = Arrays.copyOf(dp, dp.length);
        }

        System.out.println(dp[m]);
    }

    public static void getResult() {
        Scanner sc = new Scanner(System.in);
        String A = sc.next();
        String B = sc.next();
        int m = A.length(), n = B.length();

        // dp[i][j]到达ij的最短距离
        int[][] dp = new int[m + 1][n+1];

        for (int i = 0; i <= m; i++) {
            dp[i][0]=i;
        }
        for (int i = 0; i <= n; i++) {
            dp[0][i]=i;
        }

        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                dp[i][j]=Math.min(dp[i-1][j],dp[i][j-1])+1;
                if(A.charAt(i-1)==B.charAt(j-1)){
                    dp[i][j]=Math.min(dp[i][j],dp[i-1][j-1]+1);
                }
            }
        }

        System.out.println(dp[m][n]);
    }

    public static void getResult1() {
        Scanner sc = new Scanner(System.in);
        String A = sc.next();
        String B = sc.next();
        int m = A.length(), n = B.length();

        // dp[i][j]到达ij的最短距离
        int[][] dp = new int[2][n+1];

        for (int i = 0; i <= n; i++) {
            dp[0][i]=i;
        }


        for (int i = 1; i <= m; i++) {
            dp[i%2][0]=i;
            for (int j = 1; j <= n; j++) {
                dp[i%2][j]=Math.min(dp[(i-1)%2][j],dp[i%2][j-1])+1;
                if(A.charAt(i-1)==B.charAt(j-1)){
                    dp[i%2][j]=Math.min(dp[i%2][j],dp[(i-1)%2][j-1]+1);
                }
            }
        }

        System.out.println(dp[m%2][n]);
    }
}

