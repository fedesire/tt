import java.util.*;

/**
 * @author xqi
 * @version 1.0
 * @description TODO
 * @date 2025/7/5 11:03
 */
/*
* 有一组区间[a0，b0]，[a1，b1]，…（a，b表示起点，终点），区间有可能重叠、相邻，重叠或相邻则可以合并为更大的区间；
给定一组连接器[x1，x2，x3，…]（x表示连接器的最大可连接长度，即x>=gap），可用于将分离的区间连接起来，但两个分离区间之间只能使用1个连接器；
请编程实现使用连接器后，最少的区间数结果。
备注：
区间数量<10000，a,b均 <=10000
连接器数量<10000；x <= 10000
输入描述
无
输出描述
无
用例1
输入
[1,10],[15,20],[18,30],[33,40]
[5,4,3,2]
1
2
输出
1
1
说明
合并后：[1,10], [15,30], [33,40]，使用5, 3两个连接器连接后只剩下[1,40]。
用例2
输入
[1,2],[3,5],[7,10],[15,20],[30,100]
[5,4,3,2,1]
1
2
输出
2
1
说明
无重叠和相邻，使用1，2，5三个连接器连接后只剩下[1,20]，[30,100]
题解
思路：合并区间 + 贪心分配
合并输入的区间,得到一组不重叠的区间。得到按照起始值升序排序不重叠的区间merge数组。
计算相邻区间中间存在空闲距离，存入dist数组。将dist数组进行排序。
贪心将连接器距离大 贪心 分配给 dist中大的间隔，使用count统计可以分配的数量。
结果就为merge.size() - count*/
public class IntervalJoin {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        input = input.substring(1,input.length()-1);
        String[] temp = input.split("\\],\\[");
        int n=temp.length;
        int[][] intervals=new int[n][2];
        for (int i = 0; i < n; i++) {
            intervals[i]=Arrays.stream(temp[i].split(",")).mapToInt(Integer::parseInt).toArray();
        }
        Arrays.sort(intervals,(a,b)->(a[0]-b[0]));
        String s = sc.nextLine();
        int[] joiner = Arrays.stream(s.substring(1, s.length() - 1).split(",")).mapToInt(Integer::parseInt).toArray();

        List<int[]> mergedIntervals = new ArrayList<>();
        mergedIntervals.add(intervals[0]);
        for (int i = 1; i < n; i++) {
            int[] last=mergedIntervals.get(mergedIntervals.size()-1);
            int[] current = intervals[i];
            if(last[1]>=current[0]){
                last[1]=Math.max(last[1],current[1]);
            }else{
                mergedIntervals.add(current);
            }
        }
        int[] diff=new int[mergedIntervals.size()-1];
        for (int i = 1; i < mergedIntervals.size(); i++) {
            diff[i-1]=mergedIntervals.get(i)[0]-mergedIntervals.get(i-1)[1];
        }
        Arrays.sort(diff);
        Arrays.sort(joiner);
        int i=diff.length-1;
        int j=joiner.length-1;
        int joinCount = 0;
        while(i>=0&&j>=0){
            if(joiner[j]>=diff[i]){
                j--;
                joinCount++;
            }
            i--;
        }

        System.out.println(mergedIntervals.size()-joinCount);
    }
}
